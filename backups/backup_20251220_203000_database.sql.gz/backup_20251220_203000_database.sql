--
-- PostgreSQL database dump
--

\restrict GMqOo6N1wC7EXNaFn6mDHtTG0Md5xqsz9qVahfst47a5mFHUJznZD9TajJmFPXp

-- Dumped from database version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: application_actions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.application_actions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    officer_id character varying NOT NULL,
    action character varying(50) NOT NULL,
    previous_status character varying(50),
    new_status character varying(50),
    feedback text,
    issues_found jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.application_actions OWNER TO postgres;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying,
    action character varying(100) NOT NULL,
    details jsonb,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: certificates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.certificates (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    certificate_number character varying(50) NOT NULL,
    certificate_type character varying(50) DEFAULT 'homestay_registration'::character varying,
    issued_date timestamp without time zone NOT NULL,
    valid_from timestamp without time zone NOT NULL,
    valid_upto timestamp without time zone NOT NULL,
    property_name character varying(255) NOT NULL,
    category character varying(20) NOT NULL,
    address text NOT NULL,
    district character varying(100) NOT NULL,
    owner_name character varying(255) NOT NULL,
    owner_mobile character varying(15) NOT NULL,
    certificate_pdf_url text,
    qr_code_data text,
    digital_signature text,
    issued_by character varying,
    status character varying(50) DEFAULT 'active'::character varying,
    revocation_reason text,
    revoked_by character varying,
    revoked_date timestamp without time zone,
    renewal_reminder_sent boolean DEFAULT false,
    renewal_application_id character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.certificates OWNER TO postgres;

--
-- Name: clarifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clarifications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    objection_id character varying NOT NULL,
    application_id character varying NOT NULL,
    submitted_by character varying NOT NULL,
    submitted_date timestamp without time zone NOT NULL,
    clarification_text text NOT NULL,
    supporting_documents jsonb,
    reviewed_by character varying,
    reviewed_date timestamp without time zone,
    review_status character varying(50),
    review_notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.clarifications OWNER TO postgres;

--
-- Name: ddo_codes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ddo_codes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    district character varying(100) NOT NULL,
    ddo_code character varying(20) NOT NULL,
    ddo_description text NOT NULL,
    treasury_code character varying(10) NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ddo_codes OWNER TO postgres;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.documents (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    document_type character varying(100) NOT NULL,
    file_name character varying(255) NOT NULL,
    file_path text NOT NULL,
    file_size integer NOT NULL,
    mime_type character varying(100) NOT NULL,
    upload_date timestamp without time zone DEFAULT now(),
    ai_verification_status character varying(50),
    ai_confidence_score numeric(5,2),
    ai_notes text,
    is_verified boolean DEFAULT false,
    verification_status character varying(50) DEFAULT 'pending'::character varying,
    verified_by character varying,
    verification_date timestamp without time zone,
    verification_notes text
);


ALTER TABLE public.documents OWNER TO postgres;

--
-- Name: himkosh_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.himkosh_transactions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    dept_ref_no character varying(45) NOT NULL,
    app_ref_no character varying(20) NOT NULL,
    total_amount integer NOT NULL,
    tender_by character varying(70) NOT NULL,
    merchant_code character varying(15),
    dept_id character varying(10),
    service_code character varying(5),
    ddo character varying(12),
    head1 character varying(14),
    amount1 integer,
    head2 character varying(14),
    amount2 integer,
    head3 character varying(14),
    amount3 integer,
    head4 character varying(14),
    amount4 integer,
    head10 character varying(50),
    amount10 integer,
    period_from character varying(10),
    period_to character varying(10),
    encrypted_request text,
    request_checksum character varying(32),
    ech_txn_id character varying(10),
    bank_cin character varying(20),
    bank_name character varying(10),
    payment_date character varying(14),
    status character varying(70),
    status_cd character varying(1),
    response_checksum character varying(32),
    is_double_verified boolean DEFAULT false,
    double_verification_date timestamp without time zone,
    double_verification_data jsonb,
    challan_print_url text,
    portal_base_url text,
    transaction_status character varying(50) DEFAULT 'initiated'::character varying,
    initiated_at timestamp without time zone DEFAULT now(),
    responded_at timestamp without time zone,
    verified_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.himkosh_transactions OWNER TO postgres;

--
-- Name: homestay_applications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.homestay_applications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    application_number character varying(50) NOT NULL,
    application_kind character varying(30) DEFAULT 'new_registration'::character varying NOT NULL,
    parent_application_id character varying,
    parent_application_number character varying(50),
    parent_certificate_number character varying(50),
    inherited_certificate_valid_upto timestamp without time zone,
    service_context jsonb,
    service_notes text,
    service_requested_at timestamp without time zone,
    property_name character varying(255) NOT NULL,
    category character varying(20) NOT NULL,
    location_type character varying(10) NOT NULL,
    total_rooms integer NOT NULL,
    district character varying(100) NOT NULL,
    district_other character varying(100),
    tehsil character varying(100) NOT NULL,
    tehsil_other character varying(100),
    block character varying(100),
    block_other character varying(100),
    gram_panchayat character varying(100),
    gram_panchayat_other character varying(100),
    urban_body character varying(200),
    urban_body_other character varying(200),
    ward character varying(50),
    address text NOT NULL,
    pincode character varying(10) NOT NULL,
    telephone character varying(20),
    fax character varying(20),
    latitude numeric(10,8),
    longitude numeric(11,8),
    owner_name character varying(255) NOT NULL,
    owner_gender character varying(10) NOT NULL,
    owner_mobile character varying(15) NOT NULL,
    owner_email character varying(255),
    guardian_name character varying(255),
    owner_aadhaar character varying(12) NOT NULL,
    property_ownership character varying(10) DEFAULT 'owned'::character varying NOT NULL,
    proposed_room_rate numeric(10,2),
    project_type character varying(20) NOT NULL,
    property_area numeric(10,2) NOT NULL,
    single_bed_rooms integer DEFAULT 0,
    single_bed_beds integer DEFAULT 1,
    single_bed_room_size numeric(10,2),
    single_bed_room_rate numeric(10,2),
    double_bed_rooms integer DEFAULT 0,
    double_bed_beds integer DEFAULT 2,
    double_bed_room_size numeric(10,2),
    double_bed_room_rate numeric(10,2),
    family_suites integer DEFAULT 0,
    family_suite_beds integer DEFAULT 4,
    family_suite_size numeric(10,2),
    family_suite_rate numeric(10,2),
    attached_washrooms integer NOT NULL,
    gstin character varying(15),
    selected_category character varying(20),
    average_room_rate numeric(10,2),
    highest_room_rate numeric(10,2),
    lowest_room_rate numeric(10,2),
    certificate_validity_years integer DEFAULT 1,
    is_pangi_sub_division boolean DEFAULT false,
    distance_airport numeric(10,2),
    distance_railway numeric(10,2),
    distance_city_center numeric(10,2),
    distance_shopping numeric(10,2),
    distance_bus_stand numeric(10,2),
    lobby_area numeric(10,2),
    dining_area numeric(10,2),
    parking_area text,
    eco_friendly_facilities text,
    differently_abled_facilities text,
    fire_equipment_details text,
    nearest_hospital character varying(255),
    amenities jsonb,
    rooms jsonb,
    base_fee numeric(10,2),
    total_before_discounts numeric(10,2),
    validity_discount numeric(10,2) DEFAULT '0'::numeric,
    female_owner_discount numeric(10,2) DEFAULT '0'::numeric,
    pangi_discount numeric(10,2) DEFAULT '0'::numeric,
    total_discount numeric(10,2) DEFAULT '0'::numeric,
    total_fee numeric(10,2),
    per_room_fee numeric(10,2),
    gst_amount numeric(10,2),
    status character varying(50) DEFAULT 'draft'::character varying,
    current_stage character varying(50),
    current_page integer DEFAULT 1,
    district_officer_id character varying,
    district_review_date timestamp without time zone,
    district_notes text,
    da_id character varying,
    da_review_date timestamp without time zone,
    da_forwarded_date timestamp without time zone,
    da_remarks text,
    state_officer_id character varying,
    state_review_date timestamp without time zone,
    state_notes text,
    dtdo_id character varying,
    dtdo_review_date timestamp without time zone,
    correction_submission_count integer DEFAULT 0 NOT NULL,
    dtdo_remarks text,
    rejection_reason text,
    clarification_requested text,
    site_inspection_scheduled_date timestamp without time zone,
    site_inspection_completed_date timestamp without time zone,
    site_inspection_officer_id character varying,
    site_inspection_notes text,
    site_inspection_outcome character varying(50),
    site_inspection_findings jsonb,
    ownership_proof_url text,
    aadhaar_card_url text,
    pan_card_url text,
    gst_certificate_url text,
    fire_safety_noc_url text,
    pollution_clearance_url text,
    building_plan_url text,
    property_photos_urls jsonb,
    documents jsonb,
    certificate_number character varying(50),
    certificate_issued_date timestamp without time zone,
    certificate_expiry_date timestamp without time zone,
    submitted_at timestamp without time zone,
    approved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    payment_status character varying(20) DEFAULT 'pending'::character varying,
    payment_id character varying(100),
    payment_amount numeric(10,2),
    payment_date timestamp without time zone,
    refund_date timestamp without time zone,
    refund_reason text,
    nearby_attractions jsonb,
    revert_count integer DEFAULT 0 NOT NULL,
    adventure_sports_data jsonb,
    water_sports_data jsonb,
    application_type character varying(50) DEFAULT 'homestay'::character varying
);


ALTER TABLE public.homestay_applications OWNER TO postgres;

--
-- Name: inspection_orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inspection_orders (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    scheduled_by character varying NOT NULL,
    scheduled_date timestamp without time zone NOT NULL,
    assigned_to character varying NOT NULL,
    assigned_date timestamp without time zone NOT NULL,
    inspection_date timestamp without time zone NOT NULL,
    inspection_address text NOT NULL,
    special_instructions text,
    status character varying(50) DEFAULT 'scheduled'::character varying,
    dtdo_notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.inspection_orders OWNER TO postgres;

--
-- Name: inspection_reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inspection_reports (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    inspection_order_id character varying NOT NULL,
    application_id character varying NOT NULL,
    submitted_by character varying NOT NULL,
    submitted_date timestamp without time zone NOT NULL,
    actual_inspection_date timestamp without time zone NOT NULL,
    room_count_verified boolean NOT NULL,
    actual_room_count integer,
    category_meets_standards boolean NOT NULL,
    recommended_category character varying(20),
    mandatory_checklist jsonb,
    mandatory_remarks text,
    desirable_checklist jsonb,
    desirable_remarks text,
    amenities_verified jsonb,
    amenities_issues text,
    fire_safety_compliant boolean,
    fire_safety_issues text,
    structural_safety boolean,
    structural_issues text,
    overall_satisfactory boolean NOT NULL,
    recommendation character varying(50) NOT NULL,
    detailed_findings text NOT NULL,
    inspection_photos jsonb,
    report_document_url text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.inspection_reports OWNER TO postgres;

--
-- Name: lgd_blocks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lgd_blocks (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    block_name character varying(100) NOT NULL,
    district_id character varying NOT NULL,
    tehsil_id character varying,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_blocks OWNER TO postgres;

--
-- Name: lgd_districts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lgd_districts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    district_name character varying(100) NOT NULL,
    division_name character varying(100),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_districts OWNER TO postgres;

--
-- Name: lgd_gram_panchayats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lgd_gram_panchayats (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    gram_panchayat_name character varying(100) NOT NULL,
    district_id character varying NOT NULL,
    block_id character varying,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_gram_panchayats OWNER TO postgres;

--
-- Name: lgd_tehsils; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lgd_tehsils (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    tehsil_name character varying(100) NOT NULL,
    district_id character varying NOT NULL,
    tehsil_type character varying(50) DEFAULT 'tehsil'::character varying,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_tehsils OWNER TO postgres;

--
-- Name: lgd_urban_bodies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lgd_urban_bodies (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    urban_body_name character varying(200) NOT NULL,
    district_id character varying NOT NULL,
    body_type character varying(50) NOT NULL,
    number_of_wards integer,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_urban_bodies OWNER TO postgres;

--
-- Name: login_otp_challenges; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.login_otp_challenges (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    otp_hash character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    consumed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.login_otp_challenges OWNER TO postgres;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    application_id character varying,
    type character varying(100) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    channels jsonb,
    is_read boolean DEFAULT false,
    read_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: objections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.objections (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    inspection_report_id character varying,
    raised_by character varying NOT NULL,
    raised_date timestamp without time zone NOT NULL,
    objection_type character varying(50) NOT NULL,
    objection_title character varying(255) NOT NULL,
    objection_description text NOT NULL,
    severity character varying(20) NOT NULL,
    response_deadline timestamp without time zone,
    status character varying(50) DEFAULT 'pending'::character varying,
    resolution_notes text,
    resolved_by character varying,
    resolved_date timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.objections OWNER TO postgres;

--
-- Name: password_reset_challenges; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.password_reset_challenges (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    channel character varying(32) NOT NULL,
    recipient character varying(255),
    otp_hash character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    consumed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.password_reset_challenges OWNER TO postgres;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    payment_type character varying(50) NOT NULL,
    amount numeric(10,2) NOT NULL,
    payment_gateway character varying(50),
    gateway_transaction_id character varying(255),
    payment_method character varying(50),
    payment_status character varying(50) DEFAULT 'pending'::character varying,
    payment_link text,
    qr_code_url text,
    payment_link_expiry_date timestamp without time zone,
    initiated_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone,
    receipt_number character varying(100),
    receipt_url text
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: production_stats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.production_stats (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    total_applications integer NOT NULL,
    approved_applications integer NOT NULL,
    rejected_applications integer NOT NULL,
    pending_applications integer NOT NULL,
    scraped_at timestamp without time zone DEFAULT now(),
    source_url text
);


ALTER TABLE public.production_stats OWNER TO postgres;

--
-- Name: reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reviews (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    user_id character varying NOT NULL,
    rating integer NOT NULL,
    review_text text,
    is_verified_stay boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.reviews OWNER TO postgres;

--
-- Name: session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.session (
    sid character varying NOT NULL,
    sess json NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.session OWNER TO postgres;

--
-- Name: storage_objects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.storage_objects (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    object_key text NOT NULL,
    storage_provider character varying(20) DEFAULT 'local'::character varying NOT NULL,
    file_type character varying(100) NOT NULL,
    category character varying(100) DEFAULT 'general'::character varying,
    mime_type character varying(100) DEFAULT 'application/octet-stream'::character varying,
    size_bytes integer DEFAULT 0 NOT NULL,
    checksum_sha256 character varying(128),
    uploaded_by character varying,
    application_id character varying,
    document_id character varying,
    created_at timestamp without time zone DEFAULT now(),
    last_accessed_at timestamp without time zone
);


ALTER TABLE public.storage_objects OWNER TO postgres;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_settings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    setting_key character varying(100) NOT NULL,
    setting_value jsonb NOT NULL,
    description text,
    category character varying(50) DEFAULT 'general'::character varying,
    updated_by character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.system_settings OWNER TO postgres;

--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_profiles (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    full_name character varying(255) NOT NULL,
    gender character varying(10) NOT NULL,
    aadhaar_number character varying(12),
    mobile character varying(15) NOT NULL,
    email character varying(255),
    district character varying(100),
    tehsil character varying(100),
    block character varying(100),
    gram_panchayat character varying(100),
    urban_body character varying(200),
    ward character varying(50),
    address text,
    pincode character varying(10),
    telephone character varying(20),
    fax character varying(20),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_profiles OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    mobile character varying(15) NOT NULL,
    full_name text NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    username character varying(50),
    email character varying(255),
    alternate_phone character varying(15),
    designation character varying(100),
    department character varying(100),
    employee_id character varying(50),
    office_address text,
    office_phone character varying(15),
    role character varying(50) DEFAULT 'property_owner'::character varying NOT NULL,
    aadhaar_number character varying(12),
    district character varying(100),
    password text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    sso_id character varying(50)
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: application_actions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.application_actions (id, application_id, officer_id, action, previous_status, new_status, feedback, issues_found, created_at) FROM stdin;
6a4b187f-31e8-43d7-9c47-5d6f120d8515	6ba7d780-bae2-49a2-814d-e8ed785e3fd6	2c41a160-de2a-4141-910e-4021bdeac7c4	payment_verified	draft	submitted	Registration fee paid via HimKosh (CIN: A25L280757). Application submitted.	\N	2025-12-20 10:20:16.06185
6de4ff71-3f57-474c-8096-c678356a21cd	6ba7d780-bae2-49a2-814d-e8ed785e3fd6	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	start_scrutiny	submitted	under_scrutiny	\N	\N	2025-12-20 10:21:06.840539
f97bc261-8167-4c9e-b315-57a78f36ec19	6ba7d780-bae2-49a2-814d-e8ed785e3fd6	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Forward to DTDO\nAdd your overall scrutiny remarks before forwarding this application to the District Tourism Development Officer.	\N	2025-12-20 10:21:20.705201
b0001166-ad4b-4fb0-93ae-81e692f5319e	6ba7d780-bae2-49a2-814d-e8ed785e3fd6	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	dtdo_revert	forwarded_to_dtdo	reverted_by_dtdo	Revert to Applicant\n\nThis will send the application back to the applicant for corrections. Please provide details.	\N	2025-12-20 10:22:03.961685
f41dde1c-bb3a-47e9-901a-317cac63951c	6ba7d780-bae2-49a2-814d-e8ed785e3fd6	2c41a160-de2a-4141-910e-4021bdeac7c4	correction_resubmitted	reverted_by_dtdo	dtdo_review	I confirm that every issue highlighted by DA/DTDO has been fully addressed. I understand that my application may be rejected if the corrections remain unsatisfactory. (cycle 1)	\N	2025-12-20 10:22:31.875326
d0d02e68-6444-46c0-8844-395f7dea7f8a	6ba7d780-bae2-49a2-814d-e8ed785e3fd6	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	dtdo_accept	dtdo_review	dtdo_review	Accept Application\n\nThis will schedule an inspection for the property.\nInspection Remarks (Required)	\N	2025-12-20 10:23:17.100829
9de257e2-b3e5-4c18-a7b0-9cd52dd03ceb	6ba7d780-bae2-49a2-814d-e8ed785e3fd6	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	inspection_scheduled	dtdo_review	inspection_scheduled	Inspection scheduled for 2025-12-23T04:30:00.000Z by DA Shimla	\N	2025-12-20 10:23:29.265732
d60b94d4-9ab0-452c-94c1-562b54124ff5	6ba7d780-bae2-49a2-814d-e8ed785e3fd6	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	inspection_acknowledged	inspection_scheduled	inspection_scheduled	Auto-acknowledged after inspection completion.	\N	2025-12-20 10:24:39.445921
053fdfb1-c137-4782-a038-0e22ec6cd5c9	6ba7d780-bae2-49a2-814d-e8ed785e3fd6	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	inspection_completed	inspection_scheduled	inspection_under_review	Findings & Recommendation\nOverall Inspection Summary *\nCapture the key highlights of this visit (minimum 20 characters). This summary is stored with the RC.	\N	2025-12-20 10:24:39.453688
59eee77c-3991-4e68-8b24-edd333a75b24	6ba7d780-bae2-49a2-814d-e8ed785e3fd6	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	approved	inspection_under_review	approved	Certificate HP-HST-2025-65788 issued. Payment was already completed upfront.	\N	2025-12-20 10:25:12.640649
f1ff0c06-4ce9-4cc2-8f3f-74560d53ed65	ad83de55-95aa-46dd-b687-b9119d0c277b	2c41a160-de2a-4141-910e-4021bdeac7c4	payment_verified	draft	submitted	Registration fee paid via HimKosh (CIN: A25L280888). Application submitted.	\N	2025-12-20 10:28:04.48003
f11f93df-d6c0-49c3-9e1f-daaafaa639f7	ad83de55-95aa-46dd-b687-b9119d0c277b	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	start_scrutiny	submitted	under_scrutiny	\N	\N	2025-12-20 10:28:48.850138
23be6a0b-7e6b-48c8-970b-12d3e04c620b	ad83de55-95aa-46dd-b687-b9119d0c277b	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Forward to DTDO\nAdd your overall scrutiny remarks before forwarding this application to the District Tourism Development Officer.	\N	2025-12-20 10:28:58.189015
2ea159c5-3dc5-43ae-96e6-02340d9e3026	ad83de55-95aa-46dd-b687-b9119d0c277b	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	dtdo_accept	forwarded_to_dtdo	dtdo_review	Accept Application\n\nThis will schedule an inspection for the property.\nInspection Remarks (Required)	\N	2025-12-20 10:29:26.074928
8ec7cdd7-8c20-47d7-983a-95b26668e9de	ad83de55-95aa-46dd-b687-b9119d0c277b	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	inspection_scheduled	dtdo_review	inspection_scheduled	Inspection scheduled for 2025-12-22T04:30:00.000Z by DA Shimla	\N	2025-12-20 10:29:55.360361
64065f23-5825-4f83-a5f9-0f5a5745946d	ad83de55-95aa-46dd-b687-b9119d0c277b	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	inspection_acknowledged	inspection_scheduled	inspection_scheduled	Auto-acknowledged after inspection completion.	\N	2025-12-20 10:30:54.459579
bf7b84df-e432-4654-9985-f626398d109b	ad83de55-95aa-46dd-b687-b9119d0c277b	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	inspection_completed	inspection_scheduled	inspection_under_review	Findings & Recommendation\nOverall Inspection Summary *\nCapture the key highlights of this visit (minimum 20 characters). This summary is stored with the RC.	\N	2025-12-20 10:30:54.46621
a4cd7b77-4630-40da-a5b6-c6ac8b26cf0c	ad83de55-95aa-46dd-b687-b9119d0c277b	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	approved	inspection_under_review	approved	Certificate HP-HST-2025-58398 issued. Payment was already completed upfront.	\N	2025-12-20 10:31:29.311196
fcd202f7-822f-4ea3-966f-a5caf538b61f	9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	2c41a160-de2a-4141-910e-4021bdeac7c4	owner_submitted	draft	submitted	Existing application finalized and submitted.	\N	2025-12-20 10:32:25.757011
65c6a082-5a48-4692-bdd2-71d650d70a9d	9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	start_scrutiny	submitted	under_scrutiny	\N	\N	2025-12-20 10:32:44.168285
086f4cf9-6fb4-412b-b3ae-5700a210d517	9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Forward to DTDO\nAdd your overall scrutiny remarks before forwarding this application to the District Tourism Development Officer.	\N	2025-12-20 10:32:57.285698
a3d57cbc-6681-4bec-91c4-a854c599ab2c	9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	dtdo_accept	forwarded_to_dtdo	dtdo_review	Accept Application\n\nThis will schedule an inspection for the property.\nInspection Remarks (Required)	\N	2025-12-20 10:33:23.360895
2fed2368-c420-4990-9d78-6910cd348bf1	9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	inspection_scheduled	dtdo_review	inspection_scheduled	Inspection scheduled for 2025-12-23T04:30:00.000Z by DA Shimla	\N	2025-12-20 10:33:35.121732
8d90dd25-1c05-43cf-bb6f-7a93e545c3b3	9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	inspection_acknowledged	inspection_scheduled	inspection_scheduled	Auto-acknowledged after inspection completion.	\N	2025-12-20 10:34:15.973915
122fb44c-03ca-49aa-b4cd-bc772b9f03fb	9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	inspection_completed	inspection_scheduled	inspection_under_review	Log Earlier Visit\nEnable if the physical inspection happened up to 7 days before the scheduled date.	\N	2025-12-20 10:34:15.982784
dd6f6731-5db3-4fa2-8a6d-8334bb2974ac	9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	approved	inspection_under_review	approved	Certificate HP-HST-2025-71713 issued. Payment was already completed upfront.	\N	2025-12-20 10:34:37.610781
5bcfe655-cba6-4e46-9a46-ec803c1bc5aa	09c5e455-992c-4d37-9969-f6aa25cfaa6f	587e43ed-d70b-4184-aac9-0aa54c657bfb	payment_verified	draft	submitted	Registration fee paid via HimKosh (CIN: A25L281850). Application submitted.	\N	2025-12-20 11:34:18.607053
71accc09-f0e3-47ad-89e7-d31876babbe0	6f9c9053-bc93-49d4-9eb4-794fe4ef0251	6ee216be-e615-4730-96ec-776f7a244776	payment_verified	draft	submitted	Registration fee paid via HimKosh (CIN: A25L281980). Application submitted.	\N	2025-12-20 11:43:09.665016
292c0eef-4a39-4204-b017-49dcf116d8cb	c87cfa30-8571-4f49-96bb-0bec168caa9d	6e592576-d816-4354-8455-0ddb22fd8e79	payment_verified	draft	submitted	Registration fee paid via HimKosh (CIN: A25L282608). Application submitted.	\N	2025-12-20 12:54:43.349859
a6dbdf99-9a76-4f68-8c25-e9a5e471ab22	a54137e0-d281-417f-a28f-ee4750f431ad	04ac9697-6f79-42ce-8c9e-a7c6e40064e8	payment_verified	draft	submitted	Registration fee paid via HimKosh (CIN: A25L282660). Application submitted.	\N	2025-12-20 13:03:45.036576
abd6578e-92a9-4224-90ed-df2e73e7ea11	79d13cf0-3180-49a0-8dd6-d1b5cddc372b	0bbe93ff-cac5-4e91-b2f2-686669d01d05	payment_verified	draft	submitted	Registration fee paid via HimKosh (CIN: A25L282685). Application submitted.	\N	2025-12-20 13:08:04.922817
402c0cc8-e1ac-4154-ae85-927c08e528ce	7635bcb1-e2d7-4c43-be05-483729892224	bdebfe2d-dc2f-4968-a4fd-b4329227d92d	payment_verified	draft	submitted	Registration fee paid via HimKosh (CIN: A25L282736). Application submitted.	\N	2025-12-20 13:15:13.086902
e7fe1e24-760d-4af8-b6a1-a187980ddb5f	977e5c74-4447-4282-bb7b-35b401b1db6f	3a61a143-319b-4b43-a591-b4e9612a8356	payment_verified	draft	submitted	Registration fee paid via HimKosh (CIN: A25L283542). Application submitted.	\N	2025-12-20 17:15:22.559627
65d1d7c2-7e1f-49ed-bc38-8bea3d4bf36c	977e5c74-4447-4282-bb7b-35b401b1db6f	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	start_scrutiny	submitted	under_scrutiny	\N	\N	2025-12-20 17:17:06.286533
ed2777d7-52c9-4fcd-9bb7-fa7ddb4aaea1	977e5c74-4447-4282-bb7b-35b401b1db6f	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Forward to DTDO\nAdd your overall scrutiny remarks before forwarding this application to the District Tourism Development Officer.\n\nOverall Scrutiny Remarks (Optional)	\N	2025-12-20 17:17:18.008715
03c91fc0-2dd8-481b-a541-3249f30cc82a	d8839c8d-2219-4fdd-89f8-aaee7681ad84	2c41a160-de2a-4141-910e-4021bdeac7c4	payment_verified	draft	submitted	Registration fee paid via HimKosh (CIN: A25L283579). Application submitted.	\N	2025-12-20 17:49:42.537519
de322f13-f84f-49e4-a23d-80dc02c1e580	d8839c8d-2219-4fdd-89f8-aaee7681ad84	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	start_scrutiny	submitted	under_scrutiny	\N	\N	2025-12-20 17:50:37.053764
7a5e567c-06a6-476c-ba3e-92e6cf16c2cf	d8839c8d-2219-4fdd-89f8-aaee7681ad84	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Forward to DTDO\nAdd your overall scrutiny remarks before forwarding this application to the District Tourism Development Officer.	\N	2025-12-20 17:50:55.954174
5745ba5a-db95-4e3e-945e-3c99599c9943	d8839c8d-2219-4fdd-89f8-aaee7681ad84	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	auto_rejected	forwarded_to_dtdo	rejected	Auto-rejected on 2nd revert. Reason: Revert to Applicant\nThis will send the application back to the applicant for corrections. Please provide details.	\N	2025-12-20 17:51:41.401501
b4266642-9def-4ba9-ba9b-e1a51a0ed299	445059d3-940e-47d5-b73c-41026472af81	033bb139-19cf-45a0-a191-01986b65449f	payment_verified	draft	submitted	Registration fee paid via HimKosh (CIN: A25L283621). Application submitted.	\N	2025-12-20 18:51:39.833773
cc188921-c8c8-4490-bae4-0d10e55e7c19	445059d3-940e-47d5-b73c-41026472af81	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	start_scrutiny	submitted	under_scrutiny	\N	\N	2025-12-20 18:53:58.867993
227a5c27-6d73-44a1-8dee-d12b9665e4e7	445059d3-940e-47d5-b73c-41026472af81	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	hgfgh	\N	2025-12-20 18:54:31.6742
0ac953cc-d94a-4bc0-88ba-04cb4978d802	445059d3-940e-47d5-b73c-41026472af81	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	dtdo_accept	forwarded_to_dtdo	dtdo_review	hgju	\N	2025-12-20 18:56:14.867579
ab85c064-96a7-4212-ab36-490169da0e6f	445059d3-940e-47d5-b73c-41026472af81	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	inspection_scheduled	dtdo_review	inspection_scheduled	Inspection scheduled for 2025-12-24T04:30:00.000Z by DA Shimla	\N	2025-12-20 18:57:34.013959
70de35e9-d991-43a0-887b-a17302b6571b	445059d3-940e-47d5-b73c-41026472af81	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	inspection_acknowledged	inspection_scheduled	inspection_scheduled	Auto-acknowledged after inspection completion.	\N	2025-12-20 18:59:15.094944
5137cba6-2878-42d6-b482-0a6272d996c7	445059d3-940e-47d5-b73c-41026472af81	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	inspection_completed	inspection_scheduled	inspection_under_review	gcbgcbbjghg  gyjgjhasfdsf	\N	2025-12-20 18:59:15.1008
ed1d4618-a100-4627-9bc8-9fd60cc15e95	445059d3-940e-47d5-b73c-41026472af81	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	approved	inspection_under_review	approved	Certificate HP-HST-2025-79538 issued. Payment was already completed upfront.	\N	2025-12-20 18:59:43.391925
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, user_id, action, details, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: certificates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.certificates (id, application_id, certificate_number, certificate_type, issued_date, valid_from, valid_upto, property_name, category, address, district, owner_name, owner_mobile, certificate_pdf_url, qr_code_data, digital_signature, issued_by, status, revocation_reason, revoked_by, revoked_date, renewal_reminder_sent, renewal_application_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: clarifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clarifications (id, objection_id, application_id, submitted_by, submitted_date, clarification_text, supporting_documents, reviewed_by, reviewed_date, review_status, review_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ddo_codes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ddo_codes (id, district, ddo_code, ddo_description, treasury_code, is_active, created_at, updated_at) FROM stdin;
aa2e868a-014f-4c97-bad0-89c4de8670a2	Chamba	CHM00-532	D.T.D.O. CHAMBA	CHM00	t	2025-12-11 10:57:28.124346	2025-12-11 10:57:28.124346
18c2d373-80d8-40ad-9221-7fc642b404c7	Bharmour	CHM01-001	S.D.O.(CIVIL) BHARMOUR	CHM01	t	2025-12-11 10:57:28.128671	2025-12-11 10:57:28.128671
159565d8-d46e-4c20-a0df-12bedd30844b	Shimla (Central)	CTO00-068	A.C. (TOURISM) SHIMLA	CTO00	t	2025-12-11 10:57:28.132006	2025-12-11 10:57:28.132006
e9881bd0-380f-4cd7-8f2f-0e36a69f37c4	Hamirpur	HMR00-053	DISTRICT TOURISM DEVELOPMENT OFFICE HAMIRPUR (UNA)	HMR00	t	2025-12-11 10:57:28.13585	2025-12-11 10:57:28.13585
62398392-43cf-4db4-9f89-49b26e6a8152	Una	HMR00-053	DISTRICT TOURISM DEVELOPMENT OFFICE HAMIRPUR (UNA)	HMR00	t	2025-12-11 10:57:28.138309	2025-12-11 10:57:28.138309
200f4d2d-1e3a-44e7-bfe6-4b588a83d1d5	Kullu (Dhalpur)	KLU00-532	DEPUTY DIRECTOR TOURISM AND CIVIL AVIATION KULLU DHALPUR	KLU00	t	2025-12-11 10:57:28.140323	2025-12-11 10:57:28.140323
9527bd00-c182-4a23-8eac-f2b77a4ef95a	Kangra	KNG00-532	DIV.TOURISM DEV.OFFICER(DTDO) DHARAMSALA	KNG00	t	2025-12-11 10:57:28.142095	2025-12-11 10:57:28.142095
236f96eb-5833-47c0-bd61-199ec84e65ef	Kinnaur	KNR00-031	DISTRICT TOURISM DEVELOPMENT OFFICER KINNAUR AT RECKONG PEO	KNR00	t	2025-12-11 10:57:28.145343	2025-12-11 10:57:28.145343
3e700356-e31b-492c-9094-78253eab1ef8	Lahaul-Spiti (Kaza)	KZA00-011	PO ITDP KAZA	KZA00	t	2025-12-11 10:57:28.147757	2025-12-11 10:57:28.147757
cc8a66de-0be6-44e3-a45b-943a48cb37ec	Lahaul	LHL00-017	DISTRICT TOURISM DEVELOPMENT OFFICER	LHL00	t	2025-12-11 10:57:28.149534	2025-12-11 10:57:28.149534
2ad67dc9-b983-4354-919c-436e41636a74	Mandi	MDI00-532	DIV. TOURISM DEV. OFFICER MANDI	MDI00	t	2025-12-11 10:57:28.151818	2025-12-11 10:57:28.151818
9be6480d-03ac-44a1-bd0f-1c9d7b9bd501	Pangi	PNG00-003	PROJECT OFFICER ITDP PANGI	PNG00	t	2025-12-11 10:57:28.153916	2025-12-11 10:57:28.153916
583743e9-67b6-4e40-ab53-f05fcb3ce379	Shimla	SML00-532	DIVISIONAL TOURISM OFFICER SHIMLA	SML00	t	2025-12-11 10:57:28.156174	2025-12-11 10:57:28.156174
ab932954-8e96-46d7-bc85-02548bf473d9	Sirmour	SMR00-055	DISTRICT TOURISM DEVELOPMENT OFFICE NAHAN	SMR00	t	2025-12-11 10:57:28.159049	2025-12-11 10:57:28.159049
6cd1529a-cfc2-426a-81ad-6d6a5df6b498	Solan	SOL00-046	DTDO SOLAN	SOL00	t	2025-12-11 10:57:28.161421	2025-12-11 10:57:28.161421
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.documents (id, application_id, document_type, file_name, file_path, file_size, mime_type, upload_date, ai_verification_status, ai_confidence_score, ai_notes, is_verified, verification_status, verified_by, verification_date, verification_notes) FROM stdin;
494012de-0836-430b-b432-24bd160ad27e	6ba7d780-bae2-49a2-814d-e8ed785e3fd6	property_photo	519109575.jpg	/api/local-object/download/f3b6895c-af36-4ed6-b5a8-7237ef6cfcee?type=property-photo	96524	image/jpeg	2025-12-20 10:22:31.909638	\N	\N	\N	f	pending	\N	\N	\N
2b275dd7-d851-4159-9cf2-a975f3e72d42	ad83de55-95aa-46dd-b687-b9119d0c277b	property_photo	529253340.jpg	/api/local-object/download/dcb8ba3b-7b99-42ab-800a-f1b75244d56a?type=property-photo	13584	image/jpeg	2025-12-20 10:28:04.487979	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 10:28:51.483	\N
b344eb74-c325-4d17-98c3-9fd7e2688fc9	6ba7d780-bae2-49a2-814d-e8ed785e3fd6	revenue_papers	Test_Doc01-Hindi.pdf	/api/local-object/download/996697b3-7964-4399-a70e-8c56eeebc94f?type=revenue-papers	61398	application/pdf	2025-12-20 10:22:31.881276	\N	\N	\N	f	pending	\N	\N	\N
d0e52def-d4fd-41d7-8655-b4eaa1e33dc7	6ba7d780-bae2-49a2-814d-e8ed785e3fd6	affidavit_section_29	Test_Doc01-Hindi.pdf	/api/local-object/download/493f71d0-b40a-4520-986e-75955b7be301?type=affidavit-section29	61398	application/pdf	2025-12-20 10:22:31.886205	\N	\N	\N	f	pending	\N	\N	\N
a0b6ee4d-1793-43fc-883d-393450791f9e	6ba7d780-bae2-49a2-814d-e8ed785e3fd6	undertaking_form_c	Test_Doc01-Hindi.pdf	/api/local-object/download/88f7cc2b-bdc1-420f-b703-e7449c648c94?type=undertaking-form-c	61398	application/pdf	2025-12-20 10:22:31.890848	\N	\N	\N	f	pending	\N	\N	\N
ee53e9d8-d5fb-4761-8062-6c9a53adf6cb	6ba7d780-bae2-49a2-814d-e8ed785e3fd6	property_photo	519109575.jpg	/api/local-object/download/71908a6f-b712-48a8-94c3-bea4759bb856?type=property-photo	96524	image/jpeg	2025-12-20 10:22:31.896105	\N	\N	\N	f	pending	\N	\N	\N
f3714072-4f69-4c32-8eeb-449f4dc1b65b	6ba7d780-bae2-49a2-814d-e8ed785e3fd6	property_photo	529253340.jpg	/api/local-object/download/dcb8ba3b-7b99-42ab-800a-f1b75244d56a?type=property-photo	13584	image/jpeg	2025-12-20 10:22:31.900393	\N	\N	\N	f	pending	\N	\N	\N
273b57a4-6395-4826-b118-88027f9b435a	6ba7d780-bae2-49a2-814d-e8ed785e3fd6	property_photo	529253372.jpg	/api/local-object/download/cbcaef9e-39f1-4594-9c05-38aa2c47e725?type=property-photo	98782	image/jpeg	2025-12-20 10:22:31.905481	\N	\N	\N	f	pending	\N	\N	\N
575ce612-8f35-4282-acab-12793d02c97d	ad83de55-95aa-46dd-b687-b9119d0c277b	property_photo	529253372.jpg	/api/local-object/download/cbcaef9e-39f1-4594-9c05-38aa2c47e725?type=property-photo	98782	image/jpeg	2025-12-20 10:28:04.487979	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 10:28:51.485	\N
7acfdd8b-5154-4881-b84d-920887026f5c	ad83de55-95aa-46dd-b687-b9119d0c277b	property_photo	519109575.jpg	/api/local-object/download/f3b6895c-af36-4ed6-b5a8-7237ef6cfcee?type=property-photo	96524	image/jpeg	2025-12-20 10:28:04.487979	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 10:28:51.487	\N
ffb96859-ac7e-427c-9094-54ee397a763b	9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	property_photo	519109575.jpg	/api/local-object/download/f3b6895c-af36-4ed6-b5a8-7237ef6cfcee?type=property-photo	96524	image/jpeg	2025-12-20 10:32:25.750124	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 10:32:46.77	\N
ce22db37-110f-453e-8723-edaa85bd7ec7	9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	property_photo	529253372.jpg	/api/local-object/download/cbcaef9e-39f1-4594-9c05-38aa2c47e725?type=property-photo	98782	image/jpeg	2025-12-20 10:32:25.74553	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 10:32:46.773	\N
64777f3b-9e22-48cb-8efd-664392553389	9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	property_photo	529253340.jpg	/api/local-object/download/dcb8ba3b-7b99-42ab-800a-f1b75244d56a?type=property-photo	13584	image/jpeg	2025-12-20 10:32:25.741346	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 10:32:46.776	\N
91d46c90-3bf1-40c5-99f4-c42a79ebc160	9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	property_photo	519109575.jpg	/api/local-object/download/71908a6f-b712-48a8-94c3-bea4759bb856?type=property-photo	96524	image/jpeg	2025-12-20 10:32:25.73744	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 10:32:46.779	\N
e80395ed-a521-4caf-ba82-c2a613da96a6	9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	undertaking_form_c	Test_Doc01-Hindi.pdf	/api/local-object/download/88f7cc2b-bdc1-420f-b703-e7449c648c94?type=undertaking-form-c	61398	application/pdf	2025-12-20 10:32:25.733742	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 10:32:46.781	\N
ce8363f1-962e-4784-8b49-12a3b3764398	9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	affidavit_section_29	Test_Doc01-Hindi.pdf	/api/local-object/download/493f71d0-b40a-4520-986e-75955b7be301?type=affidavit-section29	61398	application/pdf	2025-12-20 10:32:25.730206	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 10:32:46.784	\N
dd4c5072-4e67-4583-aef2-84dec22fdcfa	9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	revenue_papers	Test_Doc01-Hindi.pdf	/api/local-object/download/996697b3-7964-4399-a70e-8c56eeebc94f?type=revenue-papers	61398	application/pdf	2025-12-20 10:32:25.72507	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 10:32:46.788	\N
6f54bf86-acbd-49fa-989b-a6dcd31fe13e	09c5e455-992c-4d37-9969-f6aa25cfaa6f	revenue_papers	basic-text.pdf	/api/local-object/download/dfacd531-dad0-4ebf-8a92-98a716077302?type=revenue-papers	74656	application/pdf	2025-12-20 11:34:18.614218	\N	\N	\N	f	pending	\N	\N	\N
842bcf5b-0b5a-44eb-a37c-8ffbcedd342d	09c5e455-992c-4d37-9969-f6aa25cfaa6f	affidavit_section_29	basic-text.pdf	/api/local-object/download/b2fabce1-86c9-4dd8-993a-0e01000370a7?type=affidavit-section29	74656	application/pdf	2025-12-20 11:34:18.614218	\N	\N	\N	f	pending	\N	\N	\N
31e3b071-3436-4473-baa0-8a9612d883a8	09c5e455-992c-4d37-9969-f6aa25cfaa6f	undertaking_form_c	basic-text.pdf	/api/local-object/download/81a96eec-e3c5-41ce-9768-31f1df11de1b?type=undertaking-form-c	74656	application/pdf	2025-12-20 11:34:18.614218	\N	\N	\N	f	pending	\N	\N	\N
29986eb9-4ea8-449e-8e13-f38487024b5a	09c5e455-992c-4d37-9969-f6aa25cfaa6f	property_photo	basic-text.pdf	/api/local-object/download/88c04f3c-6337-4aea-8b27-b59e6dd47bae?type=property-photo	74656	application/pdf	2025-12-20 11:34:18.614218	\N	\N	\N	f	pending	\N	\N	\N
9fe9ff22-93c4-479f-a067-4599564553a4	09c5e455-992c-4d37-9969-f6aa25cfaa6f	property_photo	basic-text.pdf	/api/local-object/download/4e7732a1-5abb-46d2-8eb5-faed3e1e7484?type=property-photo	74656	application/pdf	2025-12-20 11:34:18.614218	\N	\N	\N	f	pending	\N	\N	\N
bf32198c-3003-4038-85c9-a847ed9ed486	6f9c9053-bc93-49d4-9eb4-794fe4ef0251	revenue_papers	basic-text.pdf	/api/local-object/download/2c61cdfa-6edf-432e-8a71-e4fe24ec5d73?type=revenue-papers	74656	application/pdf	2025-12-20 11:43:09.672751	\N	\N	\N	f	pending	\N	\N	\N
1f4a9d23-dc5d-4a2d-b391-e6b39d47c605	6f9c9053-bc93-49d4-9eb4-794fe4ef0251	affidavit_section_29	basic-text.pdf	/api/local-object/download/49ddf5ee-7c6e-47da-9110-73132b1f2816?type=affidavit-section29	74656	application/pdf	2025-12-20 11:43:09.672751	\N	\N	\N	f	pending	\N	\N	\N
b9e40f40-0ca2-4c66-ad2a-5d52b63972cb	6f9c9053-bc93-49d4-9eb4-794fe4ef0251	undertaking_form_c	basic-text.pdf	/api/local-object/download/21da7f3c-ed3f-4bad-80ea-b6135342ad87?type=undertaking-form-c	74656	application/pdf	2025-12-20 11:43:09.672751	\N	\N	\N	f	pending	\N	\N	\N
3a832002-0de4-4226-a632-a76617ab610a	6f9c9053-bc93-49d4-9eb4-794fe4ef0251	property_photo	basic-text.pdf	/api/local-object/download/fd5a6f9b-649a-47ba-b5d8-14567a2e4409?type=property-photo	74656	application/pdf	2025-12-20 11:43:09.672751	\N	\N	\N	f	pending	\N	\N	\N
bf33e9b4-4201-4ef3-a02c-f80c10819610	6f9c9053-bc93-49d4-9eb4-794fe4ef0251	property_photo	basic-text.pdf	/api/local-object/download/62b77ba5-feb3-4877-b51d-757c04873772?type=property-photo	74656	application/pdf	2025-12-20 11:43:09.672751	\N	\N	\N	f	pending	\N	\N	\N
65be8558-f201-4391-bf16-e92872a54b83	c87cfa30-8571-4f49-96bb-0bec168caa9d	revenue_papers	basic-text.pdf	/api/local-object/download/f58e0a00-cd22-4fcd-82f3-6fe2de2744de?type=revenue-papers	74656	application/pdf	2025-12-20 12:54:43.358075	\N	\N	\N	f	pending	\N	\N	\N
30896eb7-7ea4-42e2-aebb-292aaeb6aae9	ad83de55-95aa-46dd-b687-b9119d0c277b	revenue_papers	Test_Doc01-Hindi.pdf	/api/local-object/download/996697b3-7964-4399-a70e-8c56eeebc94f?type=revenue-papers	61398	application/pdf	2025-12-20 10:28:04.487979	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 10:28:51.49	\N
7c31d951-fa13-4eb7-bd5a-8cc5ee7deb3e	ad83de55-95aa-46dd-b687-b9119d0c277b	affidavit_section_29	Test_Doc01-Hindi.pdf	/api/local-object/download/493f71d0-b40a-4520-986e-75955b7be301?type=affidavit-section29	61398	application/pdf	2025-12-20 10:28:04.487979	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 10:28:51.492	\N
19644ad1-f533-42d5-9dc8-6029893fce74	ad83de55-95aa-46dd-b687-b9119d0c277b	undertaking_form_c	Test_Doc01-Hindi.pdf	/api/local-object/download/88f7cc2b-bdc1-420f-b703-e7449c648c94?type=undertaking-form-c	61398	application/pdf	2025-12-20 10:28:04.487979	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 10:28:51.493	\N
6274594c-37fb-45a3-a0d7-48136f08e62b	ad83de55-95aa-46dd-b687-b9119d0c277b	property_photo	519109575.jpg	/api/local-object/download/71908a6f-b712-48a8-94c3-bea4759bb856?type=property-photo	96524	image/jpeg	2025-12-20 10:28:04.487979	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 10:28:51.496	\N
af1bab4a-e18a-4c3a-8e5f-16c4e9d8298f	c87cfa30-8571-4f49-96bb-0bec168caa9d	affidavit_section_29	basic-text.pdf	/api/local-object/download/f2dbdd3c-2a5a-4202-a426-7ffbdc465f54?type=affidavit-section29	74656	application/pdf	2025-12-20 12:54:43.358075	\N	\N	\N	f	pending	\N	\N	\N
e4b57f5a-b33b-4db4-b93e-bfe7b1038ea4	c87cfa30-8571-4f49-96bb-0bec168caa9d	undertaking_form_c	basic-text.pdf	/api/local-object/download/80f70218-e8ae-4aa8-a424-f55de3d40075?type=undertaking-form-c	74656	application/pdf	2025-12-20 12:54:43.358075	\N	\N	\N	f	pending	\N	\N	\N
0b5b8796-2ca9-4988-996f-4cd7e2a51316	c87cfa30-8571-4f49-96bb-0bec168caa9d	property_photo	basic-text.pdf	/api/local-object/download/b8355a3a-2cbe-4d2f-9a70-2222a77c3f62?type=property-photo	74656	application/pdf	2025-12-20 12:54:43.358075	\N	\N	\N	f	pending	\N	\N	\N
6489cf83-645f-4f68-8d65-1e2697e2723a	c87cfa30-8571-4f49-96bb-0bec168caa9d	property_photo	basic-text.pdf	/api/local-object/download/b6357610-135b-493e-8a11-dd05ec22c6ee?type=property-photo	74656	application/pdf	2025-12-20 12:54:43.358075	\N	\N	\N	f	pending	\N	\N	\N
39411574-e96b-4cbe-876b-8a5ff59a14f1	a54137e0-d281-417f-a28f-ee4750f431ad	revenue_papers	basic-text.pdf	/api/local-object/download/2205a088-16ac-4873-a082-c01fc3696d51?type=revenue-papers	74656	application/pdf	2025-12-20 13:03:45.04461	\N	\N	\N	f	pending	\N	\N	\N
5955e212-1d8b-48e5-bfcd-8382ad77b3b0	a54137e0-d281-417f-a28f-ee4750f431ad	affidavit_section_29	basic-text.pdf	/api/local-object/download/b8b6e9e8-48ae-4bf1-a0dd-0d2cf630315d?type=affidavit-section29	74656	application/pdf	2025-12-20 13:03:45.04461	\N	\N	\N	f	pending	\N	\N	\N
aaa9f05f-47cd-4666-84ca-2178c9b332e7	a54137e0-d281-417f-a28f-ee4750f431ad	undertaking_form_c	basic-text.pdf	/api/local-object/download/3a79c870-7da6-47e3-af9c-2cde0e2ddbd9?type=undertaking-form-c	74656	application/pdf	2025-12-20 13:03:45.04461	\N	\N	\N	f	pending	\N	\N	\N
95ce1f8f-660f-43b5-bae0-1f650356d08b	a54137e0-d281-417f-a28f-ee4750f431ad	property_photo	basic-text.pdf	/api/local-object/download/02b42e85-db7b-4073-aeb0-108284deb4f1?type=property-photo	74656	application/pdf	2025-12-20 13:03:45.04461	\N	\N	\N	f	pending	\N	\N	\N
f4b3b716-6bf8-42dc-98c3-51e9305f74ec	a54137e0-d281-417f-a28f-ee4750f431ad	property_photo	basic-text.pdf	/api/local-object/download/61fb9275-1c9e-48c9-9409-f0e3029b1935?type=property-photo	74656	application/pdf	2025-12-20 13:03:45.04461	\N	\N	\N	f	pending	\N	\N	\N
09e9668d-730e-4ba1-943f-bd63d7807bad	79d13cf0-3180-49a0-8dd6-d1b5cddc372b	revenue_papers	basic-text.pdf	/api/local-object/download/37cc2615-92be-400b-ba84-c8fe4fc82673?type=revenue-papers	74656	application/pdf	2025-12-20 13:08:04.929806	\N	\N	\N	f	pending	\N	\N	\N
26e7e42b-f629-430a-9bd0-46c9cc9c0321	79d13cf0-3180-49a0-8dd6-d1b5cddc372b	affidavit_section_29	basic-text.pdf	/api/local-object/download/58a0903b-c927-47d6-85b9-49829303ad06?type=affidavit-section29	74656	application/pdf	2025-12-20 13:08:04.929806	\N	\N	\N	f	pending	\N	\N	\N
8498ff9a-a998-44fe-ab32-eef28c600c51	79d13cf0-3180-49a0-8dd6-d1b5cddc372b	undertaking_form_c	basic-text.pdf	/api/local-object/download/aaec5845-9c76-4681-b5ea-eef038218553?type=undertaking-form-c	74656	application/pdf	2025-12-20 13:08:04.929806	\N	\N	\N	f	pending	\N	\N	\N
6a44dcb6-bcfc-46f7-848f-731169757c3b	79d13cf0-3180-49a0-8dd6-d1b5cddc372b	property_photo	basic-text.pdf	/api/local-object/download/fa91f752-9a32-4b0a-a16c-786a897c12a9?type=property-photo	74656	application/pdf	2025-12-20 13:08:04.929806	\N	\N	\N	f	pending	\N	\N	\N
d8079eef-bb03-478d-bbe8-f75059a601fc	79d13cf0-3180-49a0-8dd6-d1b5cddc372b	property_photo	basic-text.pdf	/api/local-object/download/c2e506e4-6c2c-4250-94ae-275cc5db8a16?type=property-photo	74656	application/pdf	2025-12-20 13:08:04.929806	\N	\N	\N	f	pending	\N	\N	\N
61c3288f-f0d5-42d8-9d49-5306760ca35e	7635bcb1-e2d7-4c43-be05-483729892224	revenue_papers	basic-text.pdf	/api/local-object/download/2a100282-67f8-4ff0-95bb-bfffd438f35a?type=revenue-papers	74656	application/pdf	2025-12-20 13:15:13.095959	\N	\N	\N	f	pending	\N	\N	\N
043f7705-8f3d-475d-980f-4d9b5e9e9580	7635bcb1-e2d7-4c43-be05-483729892224	affidavit_section_29	basic-text.pdf	/api/local-object/download/d9970c55-7c34-419f-8bf5-8e97a9b10de9?type=affidavit-section29	74656	application/pdf	2025-12-20 13:15:13.095959	\N	\N	\N	f	pending	\N	\N	\N
6f12a466-6554-4a84-8fb7-29245e6a1bdc	7635bcb1-e2d7-4c43-be05-483729892224	undertaking_form_c	basic-text.pdf	/api/local-object/download/696464d0-5a19-48bf-8920-363d9de53219?type=undertaking-form-c	74656	application/pdf	2025-12-20 13:15:13.095959	\N	\N	\N	f	pending	\N	\N	\N
8b8e6a7e-ce9e-4048-b371-bda68df4fe2c	7635bcb1-e2d7-4c43-be05-483729892224	property_photo	basic-text.pdf	/api/local-object/download/cc682cbe-d9f4-4f8c-a0d8-d1f922ae573f?type=property-photo	74656	application/pdf	2025-12-20 13:15:13.095959	\N	\N	\N	f	pending	\N	\N	\N
1a857013-bffc-44da-82ce-2194a1b745e7	7635bcb1-e2d7-4c43-be05-483729892224	property_photo	basic-text.pdf	/api/local-object/download/d7c8d090-8d80-4344-a779-6fe801d37c5f?type=property-photo	74656	application/pdf	2025-12-20 13:15:13.095959	\N	\N	\N	f	pending	\N	\N	\N
997dfb4d-943d-4db7-922e-5ea09787c55a	977e5c74-4447-4282-bb7b-35b401b1db6f	revenue_papers	Test_Doc01-Hindi.pdf	/api/local-object/download/758854ee-4e49-4fff-aa34-4ea33ef90b50?type=revenue-papers	61398	application/pdf	2025-12-20 17:15:22.56802	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 17:17:09.582	\N
65dd5d7b-e199-4c51-ab67-5584a0d48f3f	977e5c74-4447-4282-bb7b-35b401b1db6f	affidavit_section_29	Test_Doc01-Hindi.pdf	/api/local-object/download/83e404fd-e9ac-459e-94d7-5c66990263b3?type=affidavit-section29	61398	application/pdf	2025-12-20 17:15:22.56802	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 17:17:09.585	\N
151a7a14-4b7d-49a1-aefb-f349249d3a9f	977e5c74-4447-4282-bb7b-35b401b1db6f	undertaking_form_c	Test_Doc01-Hindi.pdf	/api/local-object/download/275cd3f9-73ae-47d3-8be1-e18b358d9ad5?type=undertaking-form-c	61398	application/pdf	2025-12-20 17:15:22.56802	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 17:17:09.587	\N
ccf91dd6-e1b7-4199-ab84-301357a42c20	977e5c74-4447-4282-bb7b-35b401b1db6f	property_photo	519109575.jpg	/api/local-object/download/384e9d8e-bba3-49b3-8c7b-af35599e01b9?type=property-photo	96524	image/jpeg	2025-12-20 17:15:22.56802	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 17:17:09.59	\N
5fdb992d-fba1-4515-a1c8-562aec6a12ee	977e5c74-4447-4282-bb7b-35b401b1db6f	property_photo	529253340.jpg	/api/local-object/download/82764aa3-9f87-49f0-b5a0-a3d71ab5d19c?type=property-photo	13584	image/jpeg	2025-12-20 17:15:22.56802	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 17:17:09.592	\N
4a4cc021-6fa6-4735-92fd-3101391ddb52	977e5c74-4447-4282-bb7b-35b401b1db6f	property_photo	529253372.jpg	/api/local-object/download/b025cbf1-b63c-46f1-82d7-17e74ad075ad?type=property-photo	98782	image/jpeg	2025-12-20 17:15:22.56802	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 17:17:09.594	\N
1808e5c9-a995-44ea-9d98-4a2013e47ea8	d8839c8d-2219-4fdd-89f8-aaee7681ad84	affidavit_section_29	Test_Doc01-Hindi.pdf	/api/local-object/download/493f71d0-b40a-4520-986e-75955b7be301?type=affidavit-section29	61398	application/pdf	2025-12-20 17:49:42.546392	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 17:50:41.206	\N
e828be84-8a25-4070-80cf-a21b83ca92c8	d8839c8d-2219-4fdd-89f8-aaee7681ad84	undertaking_form_c	Test_Doc01-Hindi.pdf	/api/local-object/download/88f7cc2b-bdc1-420f-b703-e7449c648c94?type=undertaking-form-c	61398	application/pdf	2025-12-20 17:49:42.546392	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 17:50:41.208	\N
a5049d1b-d33f-4a7b-8ee6-8a61b33bf163	d8839c8d-2219-4fdd-89f8-aaee7681ad84	revenue_papers	Test_Doc01-Hindi.pdf	/api/local-object/download/996697b3-7964-4399-a70e-8c56eeebc94f?type=revenue-papers	61398	application/pdf	2025-12-20 17:49:42.546392	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 17:50:41.204	\N
120d5135-db16-4736-b003-b821ab1d8ed0	d8839c8d-2219-4fdd-89f8-aaee7681ad84	commercial_electricity_bill	Test_Doc01-Hindi.pdf	/api/local-object/download/6bf3f636-c399-4810-a09a-5eb7c7345d94?type=commercial-electricity-bill	61398	application/pdf	2025-12-20 17:49:42.546392	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 17:50:41.21	\N
5c296b77-ed1c-4130-8fce-19298d4760f9	d8839c8d-2219-4fdd-89f8-aaee7681ad84	commercial_water_bill	Test_Doc01-Hindi.pdf	/api/local-object/download/6d8872a9-09a8-4650-ad02-c0c0d35812b7?type=commercial-water-bill	61398	application/pdf	2025-12-20 17:49:42.546392	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 17:50:41.212	\N
00f5fc94-e5af-4456-a8cc-f730b659b8bf	d8839c8d-2219-4fdd-89f8-aaee7681ad84	property_photo	519109575.jpg	/api/local-object/download/71908a6f-b712-48a8-94c3-bea4759bb856?type=property-photo	96524	image/jpeg	2025-12-20 17:49:42.546392	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 17:50:41.214	\N
fe46b5b8-3f8c-4133-901f-33bb9d1fd1cb	d8839c8d-2219-4fdd-89f8-aaee7681ad84	property_photo	529253340.jpg	/api/local-object/download/dcb8ba3b-7b99-42ab-800a-f1b75244d56a?type=property-photo	13584	image/jpeg	2025-12-20 17:49:42.546392	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 17:50:41.216	\N
e7e95392-5b3f-45b9-8373-ef1ef059151d	d8839c8d-2219-4fdd-89f8-aaee7681ad84	property_photo	529253372.jpg	/api/local-object/download/cbcaef9e-39f1-4594-9c05-38aa2c47e725?type=property-photo	98782	image/jpeg	2025-12-20 17:49:42.546392	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 17:50:41.217	\N
248c3914-a8bc-4468-acfd-0c9508bf2cb7	d8839c8d-2219-4fdd-89f8-aaee7681ad84	property_photo	519109575.jpg	/api/local-object/download/f3b6895c-af36-4ed6-b5a8-7237ef6cfcee?type=property-photo	96524	image/jpeg	2025-12-20 17:49:42.546392	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 17:50:41.218	\N
2f692a4c-5472-44bf-b60e-d1f3eb442ba2	d8839c8d-2219-4fdd-89f8-aaee7681ad84	property_photo	Test_Doc01-Hindi.pdf	/api/local-object/download/44f404ed-03b0-4f2e-9feb-38e483d90c28?type=property-photo	61398	application/pdf	2025-12-20 17:49:42.546392	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 17:50:41.22	\N
fd0bd130-dd8a-4812-90df-6e4a2b175585	445059d3-940e-47d5-b73c-41026472af81	property_photo	basic-text.pdf	/api/local-object/download/7e244c9d-9158-4dab-9f13-a439c7d07432?type=property-photo	74656	application/pdf	2025-12-20 18:51:39.841082	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 18:54:23.144	\N
f5fe7fb1-a541-472f-a654-a7e79770be4c	445059d3-940e-47d5-b73c-41026472af81	property_photo	basic-text.pdf	/api/local-object/download/76d5edc4-c43f-4b8c-a0df-394f09daeecd?type=property-photo	74656	application/pdf	2025-12-20 18:51:39.841082	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 18:54:23.146	\N
003bb50b-3d7b-4737-a6ce-f43469ce1cfe	445059d3-940e-47d5-b73c-41026472af81	affidavit_section_29	basic-text.pdf	/api/local-object/download/26a47646-276a-465b-8e21-a81f95236e95?type=affidavit-section29	74656	application/pdf	2025-12-20 18:51:39.841082	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 18:54:23.139	\N
9c7304ec-3ef7-4b1b-9abe-688a93ca490e	445059d3-940e-47d5-b73c-41026472af81	revenue_papers	basic-text.pdf	/api/local-object/download/c0973134-d7b5-49ec-befb-149cfa1a8351?type=revenue-papers	74656	application/pdf	2025-12-20 18:51:39.841082	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 18:54:23.14	\N
b7e4f287-295b-449e-af72-b09cd0ab900b	445059d3-940e-47d5-b73c-41026472af81	undertaking_form_c	basic-text.pdf	/api/local-object/download/bceb06ae-6227-4719-a086-d030510dab8b?type=undertaking-form-c	74656	application/pdf	2025-12-20 18:51:39.841082	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 18:54:23.142	\N
\.


--
-- Data for Name: himkosh_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.himkosh_transactions (id, application_id, dept_ref_no, app_ref_no, total_amount, tender_by, merchant_code, dept_id, service_code, ddo, head1, amount1, head2, amount2, head3, amount3, head4, amount4, head10, amount10, period_from, period_to, encrypted_request, request_checksum, ech_txn_id, bank_cin, bank_name, payment_date, status, status_cd, response_checksum, is_double_verified, double_verification_date, double_verification_data, challan_print_url, portal_base_url, transaction_status, initiated_at, responded_at, verified_at, created_at, updated_at) FROM stdin;
d273942c-1c71-4110-81b5-41a819e1f715	ad83de55-95aa-46dd-b687-b9119d0c277b	HP-HS-2025-SML-000002	HPT1766226409606qn1h	1	Test AAA	HIMKOSH230	230	TSM	SML00-532	1452-00-800-01	1	\N	\N	\N	\N	\N	\N	\N	\N	20-12-2025	20-12-2025	FdkGGiidekvpm0UUibJM5FgEEJcR9UfPa9WuxgDsr2r/37yM5ai2Pyi+c4ASucch0dCF/FhYjhslDjaLnZ+Adw9uBRKKhR+ZiqyGtDZme3f2qkm7XIEaT4/x4vAhAKg5028EbbQ+xgylaQ3tGVeaPjrl2anFtKNMlAbTv0dRboYc12kQhUBh3fr79EXGlxhh7mrLWkWBZ6ufloVef3CA0C+O7z1xQVNU0Izg3QJLrbJH26zLogD6rBFiKApUbKinmK996hj4qAMvlFeqD3SS4Jq98OupRpjpzmCVvSs5kCjp+kDnlR+94pz+QjpptpQWZegv6RXVXmiaZ90Nctyy2Of9d6ZbDztUEWMNh5wMyZIeR/9ueEkdm2Z5hyQbkyn7q1xAaOE0tEDfG09hmEGLeegNTxZvD4equxuE0+h5D/4=	290846b08685b44ce4283c289e1caac8	A25L280888	CPAGBABPY3	SBI	20122025155804	Completed successfully.	1	a60d7d3d759aa6f507574e254d85f150	f	\N	\N	https://himkosh.hp.nic.in/eChallan/challan_reports/reportViewer.aspx?reportName=PaidChallan&TransId=A25L280888	https://dev.osipl.dev	success	2025-12-20 10:26:49.611049	2025-12-20 10:28:04.465	\N	2025-12-20 10:26:49.611049	2025-12-20 10:26:49.611049
5a017bdb-3c7c-4fa9-aa76-6e5b99451694	8ee8d468-e56c-406e-a7e6-fa3c5ae8b2c4	HP-HS-2025-CHM-000007	HPT1766235404627EKpb	1	dfs fds	HIMKOSH230	230	TSM	CHM00-532	1452-00-800-01	1	\N	\N	\N	\N	\N	\N	\N	\N	20-12-2025	20-12-2025	FdkGGiidekvpm0UUibJM5FgEEJcR9UfPa9WuxgDsr2oYlQsttxKGW0eieyGd/lQV++jSCtQ+s8exDOKDF7k0UkIdHBbqQ5/YWQssNoA8/x4DXD1ak8mNtA98+8p69LdtpqPYXmqKF3C/zsA7u7RRzvawmEOa4A+rQ/85FMr6Ep9hQecrbFzOSSRBoSCqMRox5Q/ZIs2QCNDa4RQnofSG4+8TUOKjlR8VjWUW7WuEb5qNKLw7XJdpkI4QU47cTNf+MPfs40bJxGLs+4bb8c+C8cyl3FiyNot9ycsMxZ47mwqPXItU6jecf/dSek1WOqy2XNlsmAM55b+NZBftVhxxhkhsB2S9GdIPhqZUmwOc6kbry52x0VefVj5tI4HfzIFdAWEmkAaNlHeHo87bU5I9wA==	9413e0129608789d4d2ebcb16257703f	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	https://dev.osipl.dev	initiated	2025-12-20 12:56:44.630297	\N	\N	2025-12-20 12:56:44.630297	2025-12-20 12:56:44.630297
e41a495a-19a1-46a8-a7b1-1b97827250de	7635bcb1-e2d7-4c43-be05-483729892224	HP-HS-2025-SML-000011	HPT1766236408469bYLP	1	HHJ JKKJ	HIMKOSH230	230	TSM	SML00-532	1452-00-800-01	1	\N	\N	\N	\N	\N	\N	\N	\N	20-12-2025	20-12-2025	FdkGGiidekvpm0UUibJM5FgEEJcR9UfPa9WuxgDsr2qPxkv5C8RAYn2SrlPz0TPpWAlP7gY7rjFJP0Czvup7/remec25xe5Ps1GJyRsH7tUVC4k7SU95q15VccwkpQAkGZW6st/VkgQhAc9EAhXwLgiIX5mN0rWheHfeRIeDY/BidWJvLfWIpMLOF45l4CApeg1mZTUGxeTCOMuApH6gZS1o8JQtdad6Lv3eUQMBPD1R25so+mcrBMLHg2Xy5cAaYclfuYxYJwI9vwIkJQiDZQK3Zby9MGX2BrOvygCHgqVGCpWCfeN3yjUdMp9H758AEIr8in/JMxsZR0SbMopVJB6ISFeKiX2T6Z8ytXWGaDmRseqoKM77MyFXqkkdqjfO/Cei+yz3WSPh71DIsp0SiP0HCZ7JuQHI/gP4LqO0OPg=	4100459d2fa42041aafd25912ff3b203	A25L282736	CPAGBAVJL4	MOP	20122025184512	Completed successfully.	1	9567db8c7d3507cdbcc9e48378d74628	f	\N	\N	https://himkosh.hp.nic.in/eChallan/challan_reports/reportViewer.aspx?reportName=PaidChallan&TransId=A25L282736	https://dev.osipl.dev	success	2025-12-20 13:13:28.471679	2025-12-20 13:15:13.076	\N	2025-12-20 13:13:28.471679	2025-12-20 13:13:28.471679
0cc71449-5b18-4590-9790-c53b5d3009e0	09c5e455-992c-4d37-9969-f6aa25cfaa6f	HP-HS-2025-HMP-000004	HPT17662303193458iFh	1	Avi THaakur	HIMKOSH230	230	TSM	HMR00-053	1452-00-800-01	1	\N	\N	\N	\N	\N	\N	\N	\N	20-12-2025	20-12-2025	FdkGGiidekvpm0UUibJM5FgEEJcR9UfPa9WuxgDsr2oxTU3jVzLxNiYDUh1tzBiTSc3T9nwlK5XTv6VxQijfKJOazOaTOLsTRSgnEr/ZV5+jgjBzGTkqa9WEIdVHg5H7/1wuWg2o1zHdkoOQDwMZXjMrzCild6bMk2/BpyNOMpTDNyFrmY4+F+MxuCwbamJX4XSXnlJC68oX6ixFyksB9caerloR5zszGl7LwZSCoq5IFl5YHUJ5gI0otHYsZpEMLDML3+xmL1kMmaT7hMQfTS2oVC2OHui1+RvvI4dHY42RoVMbBZNrNsOsm4cbeoCe+rtyunb16ovlLNt/47AqtJUx+en4UbGWLjfoqaj0I8hEfYI+Zj9sO8njuRzBi4ATpAcr/WuJQCkJQH8SwkrvGRwyRaVhqX/UNXx4Ycdhk0o=	5b4fd36700b28f74223029c241e9056f	A25L281850	CPAGBAJXN5	MOP	20122025170418	Completed successfully.	1	61603f0070352e8929a77c4005efd717	f	\N	\N	https://himkosh.hp.nic.in/eChallan/challan_reports/reportViewer.aspx?reportName=PaidChallan&TransId=A25L281850	https://dev.osipl.dev	success	2025-12-20 11:31:59.349396	2025-12-20 11:34:18.592	\N	2025-12-20 11:31:59.349396	2025-12-20 11:31:59.349396
9e492dc0-d5b4-4e82-ab10-775e807e5b28	a54137e0-d281-417f-a28f-ee4750f431ad	HP-HS-2025-HMP-000008	HPT1766235691328QRSL	1	gh aedf	HIMKOSH230	230	TSM	HMR00-053	1452-00-800-01	1	\N	\N	\N	\N	\N	\N	\N	\N	20-12-2025	20-12-2025	FdkGGiidekvpm0UUibJM5FgEEJcR9UfPa9WuxgDsr2o/Cw8eOWfdx1ORYfiONsBQWIJQAXSI2ME+iopa9H11oLya4gKNSDSeZw6fGhwVAEZa69y/CjHy2q3IMGK3lhHOVgMAY1XhX4XY9K5nWBCM10anNVdf85ivVhO/BKbbIuDypT2lNs+oMxWl86LYQOtD1+qWgFMLawKWoIdOYxxntqyZrEQBfRlPSqFN1wU0BVCtRQy+qnKnJBKqTBM2IOQnRIWhQibekL9oN8wwBo4iBJS8yxAH35VzY7449EjbP/rbM62r+SrzD7KnuWazJLBFSMigMc8SDmQEJS+OKDxQfx/0N814TH1WSpOrGaPKXDYLMY3pSgmXXAGcG3hqk8H/FulOrR1OygkXB2bZiFu8qA==	4543a27db8a6185729cf33a237ff1ffb	A25L282660	CPAGBAUIN7	MOP	20122025183344	Completed successfully.	1	8aed441be9fec747516516f6575ff26d	f	\N	\N	https://himkosh.hp.nic.in/eChallan/challan_reports/reportViewer.aspx?reportName=PaidChallan&TransId=A25L282660	https://dev.osipl.dev	success	2025-12-20 13:01:31.330427	2025-12-20 13:03:45.025	\N	2025-12-20 13:01:31.330427	2025-12-20 13:01:31.330427
a4093cfd-e7da-498f-8e2d-61e9140bfc2e	977e5c74-4447-4282-bb7b-35b401b1db6f	HP-HS-2025-SML-000014	HPT17662508539480jS3	1	Test AAA	HIMKOSH230	230	TSM	SML00-532	1452-00-800-01	1	\N	\N	\N	\N	\N	\N	\N	\N	20-12-2025	20-12-2025	FdkGGiidekvpm0UUibJM5FgEEJcR9UfPa9WuxgDsr2oNcONqjtJB0b1EIyA06VRKf0KaqxMYso+5k/g6iqFxMVm7xK0Yk3zG6xseJWNMIcbGSeLhr4pBb82wuN9AwUSy+UFo77EjDktMDsEG/V/DHujda0Kt/T7pwXpNUtxXST54AK9rTdA+bQCy1h/e0l9TQSbIcHrKrtTISPjZRgIk15lyZZLJepSYdJMUZufzsCIP0uPECxHiMmGBe/4XGHxjwMGJgTdggJ5kIdvOxMO3ghn00TJoTm3TaFPXomLmkYjf4zc91ek9KvvtleTfQ9iemiidrS/LNJmHVoK3rb79gU2CdY0R+pY7yZlbCYYorf6+aknwO9N9deTVMB0hPk9xPv4kFiEbUwYADOTIYQlfsb+m3BzTiI1yW+uuNlozOTw=	51e60f3ab36713caa1c5c438bd693342	A25L283542	CPAGBBJDB1	SBI	20122025224521	Completed successfully.	1	2fe47409dba44d2a06131aa4888b0fae	f	\N	\N	https://himkosh.hp.nic.in/eChallan/challan_reports/reportViewer.aspx?reportName=PaidChallan&TransId=A25L283542	https://dev.osipl.dev	success	2025-12-20 17:14:13.952162	2025-12-20 17:15:22.548	\N	2025-12-20 17:14:13.952162	2025-12-20 17:14:13.952162
ca05edac-a836-4849-a7cc-62ae0203c742	6ba7d780-bae2-49a2-814d-e8ed785e3fd6	HP-HS-2025-SML-000001	HPT1766225372177z47N	1	Test AAA	HIMKOSH230	230	TSM	SML00-532	1452-00-800-01	1	\N	\N	\N	\N	\N	\N	\N	\N	20-12-2025	20-12-2025	FdkGGiidekvpm0UUibJM5FgEEJcR9UfPa9WuxgDsr2pIaC6AQljy0Ght98ImRA3kJI4eDx4WbkFFTi5PvSI1FypvC4Qsokw0YDO8wUxHHlIDHQD6cjvouBzEg0Tk/Zv/OscpPKw2xRPtiARuiCkJsEy4YJ4kdEGqzXUS0kWsAmwm0zk9+TO7t97kyANRl11aLeaCyGls1/EmieLwm77liz7rLOr2K81Qqokwl92brLwDACA4eOSD9UaUaihTG7YMmpDUEfp9w2WbN62AZva7CkOqjYMxCfbyIFvliwX5uZcYk4KLHpqD2IbaQvyS3N4ZIzvvpp+Naf3RXQ2Wy4NYe0f2go+RjBfSfx3+lPG83gfoN/R9XrP5AUXjcGtZePNooa11QJLVyf5hc1k9A7t163FYQTaljH9vrl8XB4S1W/I=	9852f155540691882394e427f682c4f8	\N	\N	\N	\N	Cancelled by applicant	0	\N	f	\N	\N	\N	https://dev.osipl.dev	failed	2025-12-20 10:09:32.18438	2025-12-20 10:19:07.217	\N	2025-12-20 10:09:32.18438	2025-12-20 10:19:07.217
60705797-9c0a-4f30-8734-47431ff0fcfa	6f9c9053-bc93-49d4-9eb4-794fe4ef0251	HP-HS-2025-KNG-000005	HPT1766230921219hTB_	1	fafsd adsfds	HIMKOSH230	230	TSM	KNG00-532	1452-00-800-01	1	\N	\N	\N	\N	\N	\N	\N	\N	20-12-2025	20-12-2025	FdkGGiidekvpm0UUibJM5FgEEJcR9UfPa9WuxgDsr2ocK+OvQZ5YJvRDUPuihHFPBTUvsdPuxbWutvPo929yDfA4Ex5JPtpGjr59DTm5z2/CP0xaoYrf5ffIIpC7DOpnX1LkEAeNbqHb6N/PnXDg0QVHVQPLfv9Vo4Vxcf4FAsnVNdb6tBCF6Fj/4HrijFumE8VoNIo5uO4OelyRKFoYLqc9pIRpbxf9RR7hswkyWVcRQJj30HiItAQOpapGujRTvE8CBXhdC5arvRWi7CG8I21VhiyecXvIvG9vHop8WrmQn+Y1IFRIuFm4CySBOhYOoMpRHOJy8xn0XnGoeYWbC6Qk5Q6A1AnXaRLMI75w+sqK3AHpgvFJXXxfdYcGCfNYOb+gCvkc61sIxv9uOUl7ugdt6fpFcVIT+wpcwD8mkpE=	3163319c9e50252271183dfe546652fc	A25L281980	CPAGBAKZJ3	MOP	20122025171309	Completed successfully.	1	8deb54b388962b26264ec1449aeb0cb4	f	\N	\N	https://himkosh.hp.nic.in/eChallan/challan_reports/reportViewer.aspx?reportName=PaidChallan&TransId=A25L281980	https://dev.osipl.dev	success	2025-12-20 11:42:01.222111	2025-12-20 11:43:09.653	\N	2025-12-20 11:42:01.222111	2025-12-20 11:42:01.222111
9005f81e-69ad-4ec8-b1b8-120713ca2d6b	79d13cf0-3180-49a0-8dd6-d1b5cddc372b	HP-HS-2025-CHM-000009	HPT1766235994006VHfE	1	DSFAS FDSGE	HIMKOSH230	230	TSM	CHM00-532	1452-00-800-01	1	\N	\N	\N	\N	\N	\N	\N	\N	20-12-2025	20-12-2025	FdkGGiidekvpm0UUibJM5FgEEJcR9UfPa9WuxgDsr2oVNWw9o3iqHW3+UzmODbLXk/uUzclWM6YLmpEpBteyTDCvWdFOQZ47p6LGLQ2sgUCBnBFNwZ5QMpGr9L7AKT83QSF0Jck72uFQx/K+JbCiXp4ICqKxASnHGnNUJfC9lFHdITC81AzeOYvkTDNfvesD73CRaNu21GSCjZlPUxhveP6FR4FCmrYsAzHMDQ1UZ8QE/sHiTBOGg5OWTeAxgjYETzcKZwldYJZccBjbkJrTCw4AOri48DYkMKaqrbUvkeBi7ecOIWfPuKIEWHqNmKCwyYbGeRayiLyELS4BOjuWPC/1Lm3sjcpK8i+ZDRC8FyrKt94XjcYxNdrB5bKo01UjtgKBiF0wTQ8IEqqvXl/+1JfXkxHXOMV0tlc9gx1QjAo=	701f15c784c60461cced5e4064f19881	A25L282685	CPAGBAURM7	MOP	20122025183804	Completed successfully.	1	dd2cf73a0f13341e187ba928af8fb1f3	f	\N	\N	https://himkosh.hp.nic.in/eChallan/challan_reports/reportViewer.aspx?reportName=PaidChallan&TransId=A25L282685	https://dev.osipl.dev	success	2025-12-20 13:06:34.00956	2025-12-20 13:08:04.909	\N	2025-12-20 13:06:34.00956	2025-12-20 13:06:34.00956
b65ef4e3-aa68-4b2c-98aa-d36190541360	d8839c8d-2219-4fdd-89f8-aaee7681ad84	HP-HS-2025-SML-000015	HPT1766252907986ed9n	1	Test AAA	HIMKOSH230	230	TSM	SML00-532	1452-00-800-01	1	\N	\N	\N	\N	\N	\N	\N	\N	20-12-2025	20-12-2025	FdkGGiidekvpm0UUibJM5FgEEJcR9UfPa9WuxgDsr2oJXA67U3n/D47ADxWK9pDfGx7Y7+sAV8qqb0osJXhxD4cUznb2pIJBwUj8qlwGUjon3+2hYAqIMPTd9IyJIIkgYvDxyJbD/W5YhhMx5+7g3tGoxqTxKeS/RRSRHT1ZlFLAnfj494+gYLeAYGdyQBWUQlEXsQYS2za7fihZXtsrC/HIDXjbgjzwesdXlWZcaxeVUzhD5fUdhWZJ+mObXH7iZzycFstpRzYEfmTJrbingTUy0MBiGU871UCj2IBVJ1PjJIMMgDqsZt0rvHxhR6oN+Qqc5Bnd0ei+Bbmjv4UehM3lc9yK1sJ1zZSB567AtheVntDrCo6Y0DEHP9tNqFHs0vm4jv5hjbxwSTsaKfasPZIB0KxZ5OfC2YACTA6nveI=	0869f0cb38006e3529d513f17cbf9aa7	A25L283579	CPAGBBJQS0	SBI	20122025231942	Completed successfully.	1	4ad07ceac133735b05e4881da7691c68	f	\N	\N	https://himkosh.hp.nic.in/eChallan/challan_reports/reportViewer.aspx?reportName=PaidChallan&TransId=A25L283579	https://dev.osipl.dev	success	2025-12-20 17:48:27.988478	2025-12-20 17:49:42.525	\N	2025-12-20 17:48:27.988478	2025-12-20 17:48:27.988478
a7bedfdb-effa-432b-9440-608fc32ec294	6ba7d780-bae2-49a2-814d-e8ed785e3fd6	HP-HS-2025-SML-000001	HPT1766225948388mY62	1	Test AAA	HIMKOSH230	230	TSM	SML00-532	1452-00-800-01	1	\N	\N	\N	\N	\N	\N	\N	\N	20-12-2025	20-12-2025	FdkGGiidekvpm0UUibJM5FgEEJcR9UfPa9WuxgDsr2pIaC6AQljy0Ght98ImRA3kJI4eDx4WbkFFTi5PvSI1FypvC4Qsokw0YDO8wUxHHlKTzbDAulEHLXREh2PFsj9hPCrqnbz/aeNza0E6p6knbeEwgWnEI7ylCgVPTBWz0nwovdYSdhdOC6RdIRrDAciS1DZACiJ2Jodu3FBmd6Wo2pmtyKqFNb01e2L/WIt0TA25h5o6I0umFfuHhsLY+G7zwn8Eiwl+7ZyWxEtR7hJWmBz9Gk+dwEOsJa3byrPFv2Y7nsHhZewk2LKg/Odp8Km4hNZHMclKEz7RYA5liK90LsHTpcEljWe2/9WQEPMT9Qjc+OTkCZ58DQ32WCcFv6T4FtWSKE+vdeE7FP0apP4oaT+b7aICZ2w4qYySD6+NwKY=	d3f3f09d457635bb8a6d9e1a6381e722	A25L280757	CPAGBAAQI0	SBI	20122025155015	Completed successfully.	1	7e2c81e74cfb8765e22f4aa7eb010860	f	\N	\N	https://himkosh.hp.nic.in/eChallan/challan_reports/reportViewer.aspx?reportName=PaidChallan&TransId=A25L280757	https://dev.osipl.dev	success	2025-12-20 10:19:08.392116	2025-12-20 10:20:16.048	\N	2025-12-20 10:19:08.392116	2025-12-20 10:19:08.392116
51f35a03-6fc1-48c2-b904-edebc2faadbe	c87cfa30-8571-4f49-96bb-0bec168caa9d	HP-HS-2025-CHM-000006	HPT1766235205850YFs-	1	Avi THaakur	HIMKOSH230	230	TSM	CHM00-532	1452-00-800-01	1	\N	\N	\N	\N	\N	\N	\N	\N	20-12-2025	20-12-2025	FdkGGiidekvpm0UUibJM5FgEEJcR9UfPa9WuxgDsr2rvsCWwzhz6AGRwAPPuR7/oaETCP8/nYBovWgXOqqkH4ee/znjix9FPLDEuczUA6+CQF5yX7GrSpG0RGPQ0ekscGFa54rc8QK8IMyRjyElMCwHx4+k3rvEnrVmmVO4arpOao9L/nXGTq7PiIybPlFSIxmRTZnT9D+66u6PRaqo8cdjtP/e5ZvkTtEtnl2e3Srdyt2+9VXPgeRNniOD0nlYLqqkjY2Y7dNYMjltlAt2iXcODXacmZExr6xw8esKeXW7jgTaPrtu78SQ6Fckr8shx2T3u3lTgZD3g9E3+oRh2A9s/xA/ATd5Q0NiAsbhtnAgOSLTy1uwwXF01ey1sU/QF5yxrnA5ZtBiG5E6eDTbWOVCkdJcdvlHP9CGgPakNKL4=	49631fb4ddfbcd9c0156b38705513151	A25L282608	CPAGBATMV5	MOP	20122025182443	Completed successfully.	1	977538efb624f354d9bf7c1f01751a57	f	\N	\N	https://himkosh.hp.nic.in/eChallan/challan_reports/reportViewer.aspx?reportName=PaidChallan&TransId=A25L282608	https://dev.osipl.dev	success	2025-12-20 12:53:25.853751	2025-12-20 12:54:43.339	\N	2025-12-20 12:53:25.853751	2025-12-20 12:53:25.853751
8c5a21d9-3e31-4b00-a9b1-34d1f83963d4	560c4628-24ea-405e-907b-c80e738b86fb	HP-HS-2025-SML-000010	HPT17662362285755yqt	1	DS DFD	HIMKOSH230	230	TSM	SML00-532	1452-00-800-01	1	\N	\N	\N	\N	\N	\N	\N	\N	20-12-2025	20-12-2025	FdkGGiidekvpm0UUibJM5FgEEJcR9UfPa9WuxgDsr2ounroXHcaaA8w23VC5wqK5wc+4lQlStow923LWZ7wXkaFrg3Kj+7bk6vS3ejDTmx48/nJ/03PFR8kMWbTt+6yQf9+BUqtM3tOqZ10ciqr3sl+vTUE0r4XQ0727uscZ1UCtbSeTO1jhpFsCPdx8oqd0jbo5NjW8zeh+KJg3aNVHQVF77Mgut6UykeTz8W21Nm+n0QDhxdEnck1pkAB+vnFZGHVJyGo0xE8bCyyMnl/Z/ORq9Y+niFzbyLCvCy3NyBbLQDsfPoyG99JSy9/dPS2oRNlLtOYbukgI2gKqdwhJJRpL+ZHds64/XbHZ9vlhQWEkynebe/GhIDC5amaPXgBJ6e8mMXmWoJFaBMVv2fK3NA==	521a9a77c04408f5c50ac6776e95094a	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	https://dev.osipl.dev	initiated	2025-12-20 13:10:28.577345	\N	\N	2025-12-20 13:10:28.577345	2025-12-20 13:10:28.577345
0042eaaf-0200-4d3b-b7cd-2271cd90b774	445059d3-940e-47d5-b73c-41026472af81	HP-HS-2025-SML-000012	HPT1766256629104hwTo	1	DSF fvb	HIMKOSH230	230	TSM	SML00-532	1452-00-800-01	1	\N	\N	\N	\N	\N	\N	\N	\N	20-12-2025	20-12-2025	FdkGGiidekvpm0UUibJM5FgEEJcR9UfPa9WuxgDsr2pa+U1GWuJu9clb8KhEB/KQrI4HSqwbyC1erbkPeroDFeD1p4uTm9PpV94xuYzB+NanO1mVnn+6yN90LiS5NzkIK/cwsF0KQ2BvSLEU5zZQmlezSIF4CsojiO9I4EArN8fXakFUaVkfpSQBwCX401aY0ecdDdLB/+Ld5puU5gjILLhETu/5h6+xhvIoaMT+kYcg33wHk/ukx1y/tGmudrZDX48GelWp/bWpKbDUEyLNEIQJsuiXaeNOiG4DLu1pNJjqSFKSi9Vi7ri3M/CzaKBFtpQFXnuoAO3XZsh2BCOMQQ9M8T/l7404pmW4jA060EkB2IssSUAJrG36/wLLjs+uChlnAQD4igFOb3ip65U5gA==	94dc2b7e3bf03584b40c84b9fa598e5a	A25L283621	CPAGBBKGK9	MOP	21122025002139	Completed successfully.	1	8d3155a5490c686ad1e47fd8da53c4bf	f	\N	\N	https://himkosh.hp.nic.in/eChallan/challan_reports/reportViewer.aspx?reportName=PaidChallan&TransId=A25L283621	https://dev.osipl.dev	success	2025-12-20 18:50:29.106984	2025-12-20 18:51:39.82	\N	2025-12-20 18:50:29.106984	2025-12-20 18:50:29.106984
\.


--
-- Data for Name: homestay_applications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.homestay_applications (id, user_id, application_number, application_kind, parent_application_id, parent_application_number, parent_certificate_number, inherited_certificate_valid_upto, service_context, service_notes, service_requested_at, property_name, category, location_type, total_rooms, district, district_other, tehsil, tehsil_other, block, block_other, gram_panchayat, gram_panchayat_other, urban_body, urban_body_other, ward, address, pincode, telephone, fax, latitude, longitude, owner_name, owner_gender, owner_mobile, owner_email, guardian_name, owner_aadhaar, property_ownership, proposed_room_rate, project_type, property_area, single_bed_rooms, single_bed_beds, single_bed_room_size, single_bed_room_rate, double_bed_rooms, double_bed_beds, double_bed_room_size, double_bed_room_rate, family_suites, family_suite_beds, family_suite_size, family_suite_rate, attached_washrooms, gstin, selected_category, average_room_rate, highest_room_rate, lowest_room_rate, certificate_validity_years, is_pangi_sub_division, distance_airport, distance_railway, distance_city_center, distance_shopping, distance_bus_stand, lobby_area, dining_area, parking_area, eco_friendly_facilities, differently_abled_facilities, fire_equipment_details, nearest_hospital, amenities, rooms, base_fee, total_before_discounts, validity_discount, female_owner_discount, pangi_discount, total_discount, total_fee, per_room_fee, gst_amount, status, current_stage, current_page, district_officer_id, district_review_date, district_notes, da_id, da_review_date, da_forwarded_date, da_remarks, state_officer_id, state_review_date, state_notes, dtdo_id, dtdo_review_date, correction_submission_count, dtdo_remarks, rejection_reason, clarification_requested, site_inspection_scheduled_date, site_inspection_completed_date, site_inspection_officer_id, site_inspection_notes, site_inspection_outcome, site_inspection_findings, ownership_proof_url, aadhaar_card_url, pan_card_url, gst_certificate_url, fire_safety_noc_url, pollution_clearance_url, building_plan_url, property_photos_urls, documents, certificate_number, certificate_issued_date, certificate_expiry_date, submitted_at, approved_at, created_at, updated_at, payment_status, payment_id, payment_amount, payment_date, refund_date, refund_reason, nearby_attractions, revert_count, adventure_sports_data, water_sports_data, application_type) FROM stdin;
09c5e455-992c-4d37-9969-f6aa25cfaa6f	587e43ed-d70b-4184-aac9-0aa54c657bfb	HP-HS-2025-HMP-000004	new_registration	\N	\N	\N	\N	\N	\N	\N	Waterloo	silver	tcp	1	Hamirpur	\N	Bhoranj	\N	\N	\N		\N	lkdsfjlsdkfl	\N		123 baller street	170072	777777700	\N	\N	\N	Avi THaakur	male	7777777700	a@gmail.cpm	\N	111111111100	owned	0.00	new_project	0.00	1	1	\N	1.00	0	2	\N	0.00	0	4	\N	0.00	1		silver	\N	\N	\N	1	f	232.00	32.00	32.00	434.00	324233.00	\N	\N	Good					{"cctv": true, "fireSafety": true}	\N	5000.00	5000.00	0.00	0.00	0.00	0.00	5000.00	0.00	0.00	submitted	\N	6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "6f124b93-998f-4909-bdbc-c0a49880fc9c", "url": "/api/local-object/download/dfacd531-dad0-4ebf-8a92-98a716077302?type=revenue-papers", "name": "basic-text.pdf", "type": "revenue_papers", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/dfacd531-dad0-4ebf-8a92-98a716077302?type=revenue-papers", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "a0edf9cf-f80d-4a79-b32c-2bf2d6007426", "url": "/api/local-object/download/b2fabce1-86c9-4dd8-993a-0e01000370a7?type=affidavit-section29", "name": "basic-text.pdf", "type": "affidavit_section_29", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/b2fabce1-86c9-4dd8-993a-0e01000370a7?type=affidavit-section29", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "fb7d7dec-e10b-494d-af4e-caa1e70b24d8", "url": "/api/local-object/download/81a96eec-e3c5-41ce-9768-31f1df11de1b?type=undertaking-form-c", "name": "basic-text.pdf", "type": "undertaking_form_c", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/81a96eec-e3c5-41ce-9768-31f1df11de1b?type=undertaking-form-c", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "0854a42c-afec-4da7-801f-12eb69d80248", "url": "/api/local-object/download/88c04f3c-6337-4aea-8b27-b59e6dd47bae?type=property-photo", "name": "basic-text.pdf", "type": "property_photo", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/88c04f3c-6337-4aea-8b27-b59e6dd47bae?type=property-photo", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "property_photo"}, {"id": "c421f356-8a73-4472-9dab-3b313522f9ef", "url": "/api/local-object/download/4e7732a1-5abb-46d2-8eb5-faed3e1e7484?type=property-photo", "name": "basic-text.pdf", "type": "property_photo", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/4e7732a1-5abb-46d2-8eb5-faed3e1e7484?type=property-photo", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "property_photo"}]	\N	\N	\N	2025-12-20 11:34:18.603	\N	2025-12-20 11:24:39.10281	2025-12-20 11:34:18.603	paid	A25L281850	1.00	2025-12-20 00:00:00	\N	\N	{"waterfall": true, "hikingTrail": true, "riverStream": true, "campingGround": true, "mountainBiking": true, "paraglidingSite": true}	0	\N	\N	homestay
7635bcb1-e2d7-4c43-be05-483729892224	bdebfe2d-dc2f-4968-a4fd-b4329227d92d	HP-HS-2025-SML-000011	new_registration	\N	\N	\N	\N	\N	\N	\N	A	silver	mc	1	Shimla	\N	Chaupal	\N	\N	\N		\N	DSF	\N		23	175435		\N	\N	\N	HHJ JKKJ	male	7777777709	a4@gmail.cpm	\N	111111111109	owned	0.00	new_project	0.00	1	1	\N	1.00	0	2	\N	0.00	0	4	\N	0.00	1		silver	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N						{"cctv": true, "fireSafety": true}	\N	8000.00	8000.00	0.00	0.00	0.00	0.00	8000.00	0.00	0.00	submitted	\N	6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "495d482a-3c60-4b45-83a0-d04bc9fc9fe6", "url": "/api/local-object/download/2a100282-67f8-4ff0-95bb-bfffd438f35a?type=revenue-papers", "name": "basic-text.pdf", "type": "revenue_papers", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/2a100282-67f8-4ff0-95bb-bfffd438f35a?type=revenue-papers", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "672fd316-35d5-42e8-bb7d-4b76a128a5b7", "url": "/api/local-object/download/d9970c55-7c34-419f-8bf5-8e97a9b10de9?type=affidavit-section29", "name": "basic-text.pdf", "type": "affidavit_section_29", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/d9970c55-7c34-419f-8bf5-8e97a9b10de9?type=affidavit-section29", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "7e4555ac-34d8-4faf-a6b8-5d3f961dc97e", "url": "/api/local-object/download/696464d0-5a19-48bf-8920-363d9de53219?type=undertaking-form-c", "name": "basic-text.pdf", "type": "undertaking_form_c", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/696464d0-5a19-48bf-8920-363d9de53219?type=undertaking-form-c", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "59d0cf0f-0935-47b9-9834-2af754dc66ad", "url": "/api/local-object/download/cc682cbe-d9f4-4f8c-a0d8-d1f922ae573f?type=property-photo", "name": "basic-text.pdf", "type": "property_photo", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/cc682cbe-d9f4-4f8c-a0d8-d1f922ae573f?type=property-photo", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "property_photo"}, {"id": "ea8cadca-8c61-423a-8055-a27c5edbf815", "url": "/api/local-object/download/d7c8d090-8d80-4344-a779-6fe801d37c5f?type=property-photo", "name": "basic-text.pdf", "type": "property_photo", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/d7c8d090-8d80-4344-a779-6fe801d37c5f?type=property-photo", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "property_photo"}]	\N	\N	\N	2025-12-20 13:15:13.083	\N	2025-12-20 13:12:44.812289	2025-12-20 13:15:13.083	paid	A25L282736	1.00	2025-12-20 00:00:00	\N	\N	{}	0	\N	\N	homestay
560c4628-24ea-405e-907b-c80e738b86fb	b1f5eca1-f3d7-4df2-914b-f3d67010a00b	HP-HS-2025-SML-000010	new_registration	\N	\N	\N	\N	\N	\N	\N	D	silver	mc	1	Shimla	\N	Chaupal	\N	\N	\N		\N	DFSD	\N	DSF	34324	173424		\N	\N	\N	DS DFD	male	7777777707	a4@gmail.cpm	\N	111111111108	owned	0.00	new_project	0.00	1	1	\N	1.00	0	2	\N	0.00	0	4	\N	0.00	1		silver	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N						{"cctv": true, "fireSafety": true}	\N	8000.00	8000.00	0.00	0.00	0.00	0.00	8000.00	0.00	0.00	draft	\N	6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "fbaf12b7-6bd8-4d24-8e6d-9b898e51f256", "url": "/api/local-object/download/8b645a94-fa62-4376-a8fe-c9d33ea6aeba?type=revenue-papers", "name": "basic-text.pdf", "type": "revenue_papers", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/8b645a94-fa62-4376-a8fe-c9d33ea6aeba?type=revenue-papers", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "8d33da02-5eb6-4d1b-a785-7b9cf45688c0", "url": "/api/local-object/download/b1222556-afc2-4ff3-b1da-67e632b79f92?type=affidavit-section29", "name": "basic-text.pdf", "type": "affidavit_section_29", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/b1222556-afc2-4ff3-b1da-67e632b79f92?type=affidavit-section29", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "464fca78-6302-45e8-b5a6-05fcfaade7ad", "url": "/api/local-object/download/4725ac10-7b3d-4151-a639-d47e84108e03?type=undertaking-form-c", "name": "basic-text.pdf", "type": "undertaking_form_c", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/4725ac10-7b3d-4151-a639-d47e84108e03?type=undertaking-form-c", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "2a4dd593-4ee4-4491-a5a5-cf093abfa5d6", "url": "/api/local-object/download/4015d88f-26aa-4921-a598-43e7ab5c9b3c?type=property-photo", "name": "basic-text.pdf", "type": "property_photo", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/4015d88f-26aa-4921-a598-43e7ab5c9b3c?type=property-photo", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "property_photo"}, {"id": "503ef770-cc48-4a8d-aa24-161b6429cb85", "url": "/api/local-object/download/a203ab8b-be71-42f8-ab84-5f3d18350e5d?type=property-photo", "name": "basic-text.pdf", "type": "property_photo", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/a203ab8b-be71-42f8-ab84-5f3d18350e5d?type=property-photo", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "property_photo"}]	\N	\N	\N	\N	\N	2025-12-20 13:09:09.218117	2025-12-20 13:10:22.578	pending	\N	\N	\N	\N	\N	{}	0	\N	\N	homestay
445059d3-940e-47d5-b73c-41026472af81	033bb139-19cf-45a0-a191-01986b65449f	HP-HS-2025-SML-000012	new_registration	\N	\N	\N	\N	\N	\N	\N	sd	silver	mc	1	Shimla	\N	Chaupal	\N	\N	\N		\N	dfsf	\N		dfsd	178787		\N	\N	\N	DSF fvb	male	7777777710	a4@gmail.cpm	\N	111111111110	owned	0.00	new_project	0.00	1	1	\N	1.00	0	2	\N	0.00	0	4	\N	0.00	1		silver	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N						{"cctv": true, "fireSafety": true}	\N	8000.00	8000.00	0.00	0.00	0.00	0.00	8000.00	0.00	0.00	approved	inspection_completed	6	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	2025-12-20 18:59:43.387	bjm	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 18:54:31.669	2025-12-20 18:54:31.669	hgfgh	\N	\N	\N	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	2025-12-20 18:56:14.861	0	hgju	\N	\N	2025-12-24 04:30:00	2025-12-20 18:59:15.096	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	gcbgcbbjghg  gyjgjhasfdsf	recommended	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "676aecfb-1950-4985-ab61-b7098cf72c02", "url": "/api/local-object/download/c0973134-d7b5-49ec-befb-149cfa1a8351?type=revenue-papers", "name": "basic-text.pdf", "type": "revenue_papers", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/c0973134-d7b5-49ec-befb-149cfa1a8351?type=revenue-papers", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "7c4c677d-f2c5-4bbf-8461-32c5105d2b2c", "url": "/api/local-object/download/26a47646-276a-465b-8e21-a81f95236e95?type=affidavit-section29", "name": "basic-text.pdf", "type": "affidavit_section_29", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/26a47646-276a-465b-8e21-a81f95236e95?type=affidavit-section29", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "90af9c33-a436-4cbc-a734-dec98d2d8b1d", "url": "/api/local-object/download/bceb06ae-6227-4719-a086-d030510dab8b?type=undertaking-form-c", "name": "basic-text.pdf", "type": "undertaking_form_c", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/bceb06ae-6227-4719-a086-d030510dab8b?type=undertaking-form-c", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "c7ae095f-5a72-4fbc-8e6c-7aa4716ed516", "url": "/api/local-object/download/7e244c9d-9158-4dab-9f13-a439c7d07432?type=property-photo", "name": "basic-text.pdf", "type": "property_photo", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/7e244c9d-9158-4dab-9f13-a439c7d07432?type=property-photo", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "property_photo"}, {"id": "51b09036-4e4f-4d59-9d99-3d3a8dbd1cc7", "url": "/api/local-object/download/76d5edc4-c43f-4b8c-a0df-394f09daeecd?type=property-photo", "name": "basic-text.pdf", "type": "property_photo", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/76d5edc4-c43f-4b8c-a0df-394f09daeecd?type=property-photo", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "property_photo"}]	HP-HST-2025-79538	2025-12-20 18:59:43.387	2026-12-20 18:59:43.387	2025-12-20 18:51:39.829	2025-12-20 18:59:43.387	2025-12-20 13:24:34.235113	2025-12-20 18:59:43.387	paid	A25L283621	1.00	2025-12-21 00:00:00	\N	\N	{}	0	\N	\N	homestay
6ba7d780-bae2-49a2-814d-e8ed785e3fd6	2c41a160-de2a-4141-910e-4021bdeac7c4	HP-HS-2025-SML-000001	new_registration	\N	\N	\N	\N	\N	\N	\N	Draft Homestay	silver	gp	1	Shimla	\N	Chaupal	\N	\N	\N	Village AAA					Test Property  \nAddress	171001	08091441005	\N	\N	\N	Test AAA	male	6666666610	test@test.com	\N	666666666610	owned	0.00	new_project	0.00	1	1	\N	2500.00	0	2	\N	0.00	0	4	\N	0.00	1		silver	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N						{}	\N	3000.00	3000.00	0.00	0.00	0.00	0.00	3000.00	0.00	0.00	superseded	inspection_completed	6	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	2025-12-20 10:25:12.635	Superseded by application HP-HS-2025-SML-000002	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 10:21:20.7	2025-12-20 10:21:20.7	Forward to DTDO\nAdd your overall scrutiny remarks before forwarding this application to the District Tourism Development Officer.	\N	\N	\N	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	2025-12-20 10:23:17.094	1	Accept Application\n\nThis will schedule an inspection for the property.\nInspection Remarks (Required)	\N	\N	2025-12-23 04:30:00	2025-12-20 10:24:39.448	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	Findings & Recommendation\nOverall Inspection Summary *\nCapture the key highlights of this visit (minimum 20 characters). This summary is stored with the RC.	recommended	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "7cb43682-433d-413e-9e8a-cdd4eb437b8d", "url": "/api/local-object/download/996697b3-7964-4399-a70e-8c56eeebc94f?type=revenue-papers", "name": "Test_Doc01-Hindi.pdf", "type": "revenue_papers", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/996697b3-7964-4399-a70e-8c56eeebc94f?type=revenue-papers", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "5ce29db3-ac5a-4064-8ead-9a86eaa037a7", "url": "/api/local-object/download/493f71d0-b40a-4520-986e-75955b7be301?type=affidavit-section29", "name": "Test_Doc01-Hindi.pdf", "type": "affidavit_section_29", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/493f71d0-b40a-4520-986e-75955b7be301?type=affidavit-section29", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "68ae1b3b-54b9-4a0d-a026-962f4bec021b", "url": "/api/local-object/download/88f7cc2b-bdc1-420f-b703-e7449c648c94?type=undertaking-form-c", "name": "Test_Doc01-Hindi.pdf", "type": "undertaking_form_c", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/88f7cc2b-bdc1-420f-b703-e7449c648c94?type=undertaking-form-c", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "0602d0f6-989a-4a3b-9b57-8dd2afe5b005", "url": "/api/local-object/download/71908a6f-b712-48a8-94c3-bea4759bb856?type=property-photo", "name": "519109575.jpg", "type": "property_photo", "fileName": "519109575.jpg", "filePath": "/api/local-object/download/71908a6f-b712-48a8-94c3-bea4759bb856?type=property-photo", "fileSize": 96524, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "4c28e883-51c2-453d-81e8-678bd304429f", "url": "/api/local-object/download/dcb8ba3b-7b99-42ab-800a-f1b75244d56a?type=property-photo", "name": "529253340.jpg", "type": "property_photo", "fileName": "529253340.jpg", "filePath": "/api/local-object/download/dcb8ba3b-7b99-42ab-800a-f1b75244d56a?type=property-photo", "fileSize": 13584, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "f3b0313d-37de-4bd2-9907-55632b88038c", "url": "/api/local-object/download/cbcaef9e-39f1-4594-9c05-38aa2c47e725?type=property-photo", "name": "529253372.jpg", "type": "property_photo", "fileName": "529253372.jpg", "filePath": "/api/local-object/download/cbcaef9e-39f1-4594-9c05-38aa2c47e725?type=property-photo", "fileSize": 98782, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "81248476-320e-4bc5-91f8-b6e4feeb4e42", "url": "/api/local-object/download/f3b6895c-af36-4ed6-b5a8-7237ef6cfcee?type=property-photo", "name": "519109575.jpg", "type": "property_photo", "fileName": "519109575.jpg", "filePath": "/api/local-object/download/f3b6895c-af36-4ed6-b5a8-7237ef6cfcee?type=property-photo", "fileSize": 96524, "mimeType": "image/jpeg", "documentType": "property_photo"}]	HP-HST-2025-65788	2025-12-20 10:25:12.635	2026-12-20 10:25:12.635	2025-12-20 10:22:31.869	2025-12-20 10:25:12.635	2025-12-20 10:07:52.555882	2025-12-20 10:31:29.303	paid	A25L280757	1.00	2025-12-20 00:00:00	\N	\N	{"hotSprings": true, "riverStream": true, "appleOrchards": true, "campingGround": true, "historicTemple": true, "heritageVillage": true, "buddhistMonastery": true, "wildlifeSanctuary": true}	1	\N	\N	homestay
6f9c9053-bc93-49d4-9eb4-794fe4ef0251	6ee216be-e615-4730-96ec-776f7a244776	HP-HS-2025-KNG-000005	new_registration	\N	\N	\N	\N	\N	\N	\N	Pupu	silver	mc	1	Kangra	\N	Alampur	\N	\N	\N		\N	Theog	\N	123	1233	174839		\N	\N	\N	fafsd adsfds	male	7777777701	b@gmail.com	\N	111111111101	owned	0.00	new_project	0.00	1	1	\N	1.00	0	2	\N	0.00	0	4	\N	0.00	1		silver	\N	\N	\N	1	f	1.00	324234.00	324.00	32423.00	3423.00	\N	\N	dsfjksldfja;l					{"cctv": true, "fireSafety": true}	\N	8000.00	8000.00	0.00	0.00	0.00	0.00	8000.00	0.00	0.00	submitted	\N	6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "bd1a68e5-7784-400f-ac2e-d4ea3313afcb", "url": "/api/local-object/download/2c61cdfa-6edf-432e-8a71-e4fe24ec5d73?type=revenue-papers", "name": "basic-text.pdf", "type": "revenue_papers", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/2c61cdfa-6edf-432e-8a71-e4fe24ec5d73?type=revenue-papers", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "06bd134e-53fe-4e40-aae3-a6cbcd59b7e0", "url": "/api/local-object/download/49ddf5ee-7c6e-47da-9110-73132b1f2816?type=affidavit-section29", "name": "basic-text.pdf", "type": "affidavit_section_29", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/49ddf5ee-7c6e-47da-9110-73132b1f2816?type=affidavit-section29", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "d3b7b5ac-2deb-4140-b204-cdd0568595bf", "url": "/api/local-object/download/21da7f3c-ed3f-4bad-80ea-b6135342ad87?type=undertaking-form-c", "name": "basic-text.pdf", "type": "undertaking_form_c", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/21da7f3c-ed3f-4bad-80ea-b6135342ad87?type=undertaking-form-c", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "6fb100b6-f516-487f-9e2c-58d7a2cb7e7b", "url": "/api/local-object/download/fd5a6f9b-649a-47ba-b5d8-14567a2e4409?type=property-photo", "name": "basic-text.pdf", "type": "property_photo", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/fd5a6f9b-649a-47ba-b5d8-14567a2e4409?type=property-photo", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "property_photo"}, {"id": "d711b0ed-0f79-42c4-80f1-4f0b8861d6c7", "url": "/api/local-object/download/62b77ba5-feb3-4877-b51d-757c04873772?type=property-photo", "name": "basic-text.pdf", "type": "property_photo", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/62b77ba5-feb3-4877-b51d-757c04873772?type=property-photo", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "property_photo"}]	\N	\N	\N	2025-12-20 11:43:09.661	\N	2025-12-20 11:39:27.468876	2025-12-20 11:43:09.661	paid	A25L281980	1.00	2025-12-20 00:00:00	\N	\N	{"hikingTrail": true, "riverStream": true, "buddhistMonastery": true}	0	\N	\N	homestay
b1cd633e-b66b-4145-9056-39e80f13cdfb	08ee781b-8d0f-44d4-8c0f-218b70984ee8	HP-HS-2025-KUL-000013	new_registration	\N	\N	\N	\N	\N	\N	\N	sdf	silver	mc	1	Kullu	\N	Anni	\N	\N	\N		\N	dsf	\N		sdf	177897		\N	\N	\N	dsf sdf	male	7777777711	\N	\N	666666666690	owned	0.00	new_project	0.00	1	1	\N	\N	0	2	\N	0.00	0	4	\N	0.00	1		silver	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N						{"cctv": false, "fireSafety": false}	\N	8000.00	8000.00	0.00	0.00	0.00	0.00	8000.00	0.00	0.00	draft	\N	3	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[]	\N	\N	\N	\N	\N	2025-12-20 13:34:00.377914	2025-12-20 13:34:04.772	pending	\N	\N	\N	\N	\N	{}	0	\N	\N	homestay
c87cfa30-8571-4f49-96bb-0bec168caa9d	6e592576-d816-4354-8455-0ddb22fd8e79	HP-HS-2025-CHM-000006	new_registration	\N	\N	\N	\N	\N	\N	\N	dsfas	silver	mc	1	Chamba	\N	Bhalai	\N	\N	\N		\N		\N		dsfasd	174324		\N	\N	\N	Avi THaakur	male	7777777702	a4@gmail.cpm	\N	111111111103	owned	0.00	new_project	0.00	1	1	\N	1.00	0	2	\N	0.00	0	4	\N	0.00	1		silver	\N	\N	\N	1	f	1.00	1.00	1.00	1.00	1.00	\N	\N	cvc					{"cctv": true, "fireSafety": true}	\N	8000.00	8000.00	0.00	0.00	0.00	0.00	8000.00	0.00	0.00	submitted	\N	6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "b120301b-20de-4a2e-ae33-dbb780866ffe", "url": "/api/local-object/download/f58e0a00-cd22-4fcd-82f3-6fe2de2744de?type=revenue-papers", "name": "basic-text.pdf", "type": "revenue_papers", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/f58e0a00-cd22-4fcd-82f3-6fe2de2744de?type=revenue-papers", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "c8457f3b-421f-4a9e-962e-cd6f6caddfa0", "url": "/api/local-object/download/f2dbdd3c-2a5a-4202-a426-7ffbdc465f54?type=affidavit-section29", "name": "basic-text.pdf", "type": "affidavit_section_29", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/f2dbdd3c-2a5a-4202-a426-7ffbdc465f54?type=affidavit-section29", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "37794823-9811-47a2-94b6-fdaa690ed12b", "url": "/api/local-object/download/80f70218-e8ae-4aa8-a424-f55de3d40075?type=undertaking-form-c", "name": "basic-text.pdf", "type": "undertaking_form_c", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/80f70218-e8ae-4aa8-a424-f55de3d40075?type=undertaking-form-c", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "39224d65-7d68-4add-aab3-dacbb299b611", "url": "/api/local-object/download/b8355a3a-2cbe-4d2f-9a70-2222a77c3f62?type=property-photo", "name": "basic-text.pdf", "type": "property_photo", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/b8355a3a-2cbe-4d2f-9a70-2222a77c3f62?type=property-photo", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "property_photo"}, {"id": "69744c75-3a31-42df-82a9-97a0bb63ed31", "url": "/api/local-object/download/b6357610-135b-493e-8a11-dd05ec22c6ee?type=property-photo", "name": "basic-text.pdf", "type": "property_photo", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/b6357610-135b-493e-8a11-dd05ec22c6ee?type=property-photo", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "property_photo"}]	\N	\N	\N	2025-12-20 12:54:43.346	\N	2025-12-20 12:51:44.269157	2025-12-20 12:54:43.346	paid	A25L282608	1.00	2025-12-20 00:00:00	\N	\N	{"hikingTrail": true, "campingGround": true}	0	\N	\N	homestay
ad83de55-95aa-46dd-b687-b9119d0c277b	2c41a160-de2a-4141-910e-4021bdeac7c4	HP-HS-2025-SML-000002	add_rooms	6ba7d780-bae2-49a2-814d-e8ed785e3fd6	HP-HS-2025-SML-000001	HP-HST-2025-65788	2026-12-20 10:25:12.635	{"renewalWindow": {"end": "2026-12-20T10:25:12.635Z", "start": "2026-09-21T10:25:12.635Z"}, "requestedRooms": {"total": 3, "double": 0, "family": 0, "single": 3}, "requiresPayment": true, "requestedRoomDelta": 2, "inheritsCertificateExpiry": "2026-12-20T10:25:12.635Z"}	\N	2025-12-20 10:26:19.535	Draft Homestay	silver	gp	3	Shimla	\N	Chaupal	\N	\N	\N	Village AAA					Test Property  \nAddress	171001	08091441005	\N	\N	\N	Test AAA	male	6666666610	test@test.com	\N	666666666610	owned	0.00	new_project	0.00	3	1	\N	2500.00	0	2	\N	0.00	0	4	\N	0.00	3		silver	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N						{"cctv": true, "fireSafety": true}	\N	3000.00	3000.00	0.00	0.00	0.00	0.00	3000.00	0.00	0.00	superseded	inspection_completed	6	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	2025-12-20 10:31:29.296	Superseded by application HP-HS-2025-SML-000003	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 10:28:58.184	2025-12-20 10:28:58.184	Forward to DTDO\nAdd your overall scrutiny remarks before forwarding this application to the District Tourism Development Officer.	\N	\N	\N	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	2025-12-20 10:29:26.069	1	Accept Application\n\nThis will schedule an inspection for the property.\nInspection Remarks (Required)	\N	\N	2025-12-22 04:30:00	2025-12-20 10:30:54.461	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	Findings & Recommendation\nOverall Inspection Summary *\nCapture the key highlights of this visit (minimum 20 characters). This summary is stored with the RC.	recommended	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "7cb43682-433d-413e-9e8a-cdd4eb437b8d", "url": "/api/local-object/download/996697b3-7964-4399-a70e-8c56eeebc94f?type=revenue-papers", "name": "Test_Doc01-Hindi.pdf", "type": "revenue_papers", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/996697b3-7964-4399-a70e-8c56eeebc94f?type=revenue-papers", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "5ce29db3-ac5a-4064-8ead-9a86eaa037a7", "url": "/api/local-object/download/493f71d0-b40a-4520-986e-75955b7be301?type=affidavit-section29", "name": "Test_Doc01-Hindi.pdf", "type": "affidavit_section_29", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/493f71d0-b40a-4520-986e-75955b7be301?type=affidavit-section29", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "68ae1b3b-54b9-4a0d-a026-962f4bec021b", "url": "/api/local-object/download/88f7cc2b-bdc1-420f-b703-e7449c648c94?type=undertaking-form-c", "name": "Test_Doc01-Hindi.pdf", "type": "undertaking_form_c", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/88f7cc2b-bdc1-420f-b703-e7449c648c94?type=undertaking-form-c", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "0602d0f6-989a-4a3b-9b57-8dd2afe5b005", "url": "/api/local-object/download/71908a6f-b712-48a8-94c3-bea4759bb856?type=property-photo", "name": "519109575.jpg", "type": "property_photo", "fileName": "519109575.jpg", "filePath": "/api/local-object/download/71908a6f-b712-48a8-94c3-bea4759bb856?type=property-photo", "fileSize": 96524, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "4c28e883-51c2-453d-81e8-678bd304429f", "url": "/api/local-object/download/dcb8ba3b-7b99-42ab-800a-f1b75244d56a?type=property-photo", "name": "529253340.jpg", "type": "property_photo", "fileName": "529253340.jpg", "filePath": "/api/local-object/download/dcb8ba3b-7b99-42ab-800a-f1b75244d56a?type=property-photo", "fileSize": 13584, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "f3b0313d-37de-4bd2-9907-55632b88038c", "url": "/api/local-object/download/cbcaef9e-39f1-4594-9c05-38aa2c47e725?type=property-photo", "name": "529253372.jpg", "type": "property_photo", "fileName": "529253372.jpg", "filePath": "/api/local-object/download/cbcaef9e-39f1-4594-9c05-38aa2c47e725?type=property-photo", "fileSize": 98782, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "81248476-320e-4bc5-91f8-b6e4feeb4e42", "url": "/api/local-object/download/f3b6895c-af36-4ed6-b5a8-7237ef6cfcee?type=property-photo", "name": "519109575.jpg", "type": "property_photo", "fileName": "519109575.jpg", "filePath": "/api/local-object/download/f3b6895c-af36-4ed6-b5a8-7237ef6cfcee?type=property-photo", "fileSize": 96524, "mimeType": "image/jpeg", "documentType": "property_photo"}]	HP-HST-2025-58398	2025-12-20 10:31:29.296	2026-12-20 10:31:29.296	2025-12-20 10:28:04.475	2025-12-20 10:31:29.296	2025-12-20 10:26:19.542606	2025-12-20 10:34:37.604	paid	A25L280888	1.00	2025-12-20 00:00:00	\N	\N	{"hotSprings": true, "riverStream": true, "appleOrchards": true, "campingGround": true, "historicTemple": true, "heritageVillage": true, "buddhistMonastery": true, "wildlifeSanctuary": true}	1	\N	\N	homestay
8ee8d468-e56c-406e-a7e6-fa3c5ae8b2c4	7749040a-4097-404a-bba5-b00721476da4	HP-HS-2025-CHM-000007	new_registration	\N	\N	\N	\N	\N	\N	\N	a	silver	mc	1	Chamba	\N	Bhalai	\N	\N	\N		\N	a	\N	a	ad	172322		\N	\N	\N	dfs fds	male	7777777703	a4@gmail.cpm	\N	111111111104	owned	0.00	new_project	0.00	1	1	\N	1.00	0	2	\N	0.00	0	4	\N	0.00	1		silver	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N						{"cctv": true, "fireSafety": true}	\N	8000.00	8000.00	0.00	0.00	0.00	0.00	8000.00	0.00	0.00	draft	\N	6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "ebfff0f5-a6f1-410d-b03c-98f068211c43", "url": "/api/local-object/download/2a445d51-d712-4e68-9ee3-097eeff78d3c?type=revenue-papers", "name": "basic-text.pdf", "type": "revenue_papers", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/2a445d51-d712-4e68-9ee3-097eeff78d3c?type=revenue-papers", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "6ff1a3f1-3544-49ab-afd5-f8427a6be99f", "url": "/api/local-object/download/56fbcfa7-2c56-4cde-b311-b19f7c4485db?type=affidavit-section29", "name": "basic-text.pdf", "type": "affidavit_section_29", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/56fbcfa7-2c56-4cde-b311-b19f7c4485db?type=affidavit-section29", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "4612a02a-f695-4d49-b728-6c5f2e8c18f7", "url": "/api/local-object/download/5db3541c-164b-4077-ba94-dd942a3b8610?type=undertaking-form-c", "name": "basic-text.pdf", "type": "undertaking_form_c", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/5db3541c-164b-4077-ba94-dd942a3b8610?type=undertaking-form-c", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "c0440c0f-bd4c-427e-aa09-9bd3a977b846", "url": "/api/local-object/download/d7c067ed-a666-4be9-b6c5-5ca2bd1b0fee?type=property-photo", "name": "basic-text.pdf", "type": "property_photo", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/d7c067ed-a666-4be9-b6c5-5ca2bd1b0fee?type=property-photo", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "property_photo"}, {"id": "57c43c51-b13f-4a16-a3ea-b74c12cdc0b6", "url": "/api/local-object/download/584b4d63-9948-4754-9944-6b948e768091?type=property-photo", "name": "basic-text.pdf", "type": "property_photo", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/584b4d63-9948-4754-9944-6b948e768091?type=property-photo", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "property_photo"}]	\N	\N	\N	\N	\N	2025-12-20 12:55:38.687334	2025-12-20 12:56:38.461	pending	\N	\N	\N	\N	\N	{}	0	\N	\N	homestay
977e5c74-4447-4282-bb7b-35b401b1db6f	3a61a143-319b-4b43-a591-b4e9612a8356	HP-HS-2025-SML-000014	new_registration	\N	\N	\N	\N	\N	\N	\N	Draft Homestay	silver	gp	1	Shimla	\N	Chaupal	\N	\N	\N	Village AAA	\N		\N		Test Property  \nAddress	171001	08091441005	\N	\N	\N	Test AAA	male	6666666611	microaistudio@gmail.com	\N	666666666611	owned	0.00	new_project	0.00	1	1	\N	2498.00	0	2	\N	0.00	0	4	\N	0.00	1		silver	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N						{"cctv": true, "fireSafety": true}	\N	3000.00	3000.00	0.00	0.00	0.00	0.00	3000.00	0.00	0.00	forwarded_to_dtdo	\N	6	\N	\N	\N	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 17:17:18.002	2025-12-20 17:17:18.002	Forward to DTDO\nAdd your overall scrutiny remarks before forwarding this application to the District Tourism Development Officer.\n\nOverall Scrutiny Remarks (Optional)	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "a27a1d17-c1a6-4d38-864f-1fd45230b28a", "url": "/api/local-object/download/758854ee-4e49-4fff-aa34-4ea33ef90b50?type=revenue-papers", "name": "Test_Doc01-Hindi.pdf", "type": "revenue_papers", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/758854ee-4e49-4fff-aa34-4ea33ef90b50?type=revenue-papers", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "52dc5a97-0f29-416c-afb9-300e16caf41f", "url": "/api/local-object/download/83e404fd-e9ac-459e-94d7-5c66990263b3?type=affidavit-section29", "name": "Test_Doc01-Hindi.pdf", "type": "affidavit_section_29", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/83e404fd-e9ac-459e-94d7-5c66990263b3?type=affidavit-section29", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "a079e61f-8a59-492a-99ab-8339394d4de5", "url": "/api/local-object/download/275cd3f9-73ae-47d3-8be1-e18b358d9ad5?type=undertaking-form-c", "name": "Test_Doc01-Hindi.pdf", "type": "undertaking_form_c", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/275cd3f9-73ae-47d3-8be1-e18b358d9ad5?type=undertaking-form-c", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "fa7c6e26-1363-49ca-8529-8ce108f4ed58", "url": "/api/local-object/download/384e9d8e-bba3-49b3-8c7b-af35599e01b9?type=property-photo", "name": "519109575.jpg", "type": "property_photo", "fileName": "519109575.jpg", "filePath": "/api/local-object/download/384e9d8e-bba3-49b3-8c7b-af35599e01b9?type=property-photo", "fileSize": 96524, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "507c1655-79f5-4daa-a88c-5509d0a648cd", "url": "/api/local-object/download/82764aa3-9f87-49f0-b5a0-a3d71ab5d19c?type=property-photo", "name": "529253340.jpg", "type": "property_photo", "fileName": "529253340.jpg", "filePath": "/api/local-object/download/82764aa3-9f87-49f0-b5a0-a3d71ab5d19c?type=property-photo", "fileSize": 13584, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "430bb776-edaa-42fa-aeae-df820de3b0ef", "url": "/api/local-object/download/b025cbf1-b63c-46f1-82d7-17e74ad075ad?type=property-photo", "name": "529253372.jpg", "type": "property_photo", "fileName": "529253372.jpg", "filePath": "/api/local-object/download/b025cbf1-b63c-46f1-82d7-17e74ad075ad?type=property-photo", "fileSize": 98782, "mimeType": "image/jpeg", "documentType": "property_photo"}]	\N	\N	\N	2025-12-20 17:15:22.556	\N	2025-12-20 17:12:14.248561	2025-12-20 17:17:18.002	paid	A25L283542	1.00	2025-12-20 00:00:00	\N	\N	{"riverStream": true, "historicFort": true, "appleOrchards": true, "campingGround": true, "heritageVillage": true, "buddhistMonastery": true}	0	\N	\N	homestay
a54137e0-d281-417f-a28f-ee4750f431ad	04ac9697-6f79-42ce-8c9e-a7c6e40064e8	HP-HS-2025-HMP-000008	new_registration	\N	\N	\N	\N	\N	\N	\N	sd	silver	mc	1	Hamirpur	\N	Barsar	\N	\N	\N		\N	dsfad	\N		fsda3	174264		\N	\N	\N	gh aedf	male	7777777704	a4@gmail.cpm	\N	111111111105	owned	0.00	new_project	0.00	1	1	\N	1.00	0	2	\N	0.00	0	4	\N	0.00	1		silver	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N						{"cctv": true, "fireSafety": true}	\N	8000.00	8000.00	0.00	0.00	0.00	0.00	8000.00	0.00	0.00	submitted	\N	6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "41e5945f-d5a5-4557-8ae9-6eed13315d88", "url": "/api/local-object/download/2205a088-16ac-4873-a082-c01fc3696d51?type=revenue-papers", "name": "basic-text.pdf", "type": "revenue_papers", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/2205a088-16ac-4873-a082-c01fc3696d51?type=revenue-papers", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "6e1241db-5d24-48cb-a2ad-4cf6845219a3", "url": "/api/local-object/download/b8b6e9e8-48ae-4bf1-a0dd-0d2cf630315d?type=affidavit-section29", "name": "basic-text.pdf", "type": "affidavit_section_29", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/b8b6e9e8-48ae-4bf1-a0dd-0d2cf630315d?type=affidavit-section29", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "c685acd6-3e98-4e06-bd59-df3b74c09f66", "url": "/api/local-object/download/3a79c870-7da6-47e3-af9c-2cde0e2ddbd9?type=undertaking-form-c", "name": "basic-text.pdf", "type": "undertaking_form_c", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/3a79c870-7da6-47e3-af9c-2cde0e2ddbd9?type=undertaking-form-c", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "4318ba93-84ef-4327-9851-0c9156b5675f", "url": "/api/local-object/download/02b42e85-db7b-4073-aeb0-108284deb4f1?type=property-photo", "name": "basic-text.pdf", "type": "property_photo", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/02b42e85-db7b-4073-aeb0-108284deb4f1?type=property-photo", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "property_photo"}, {"id": "41b69184-7320-4e1e-8e32-01f4838502e7", "url": "/api/local-object/download/61fb9275-1c9e-48c9-9409-f0e3029b1935?type=property-photo", "name": "basic-text.pdf", "type": "property_photo", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/61fb9275-1c9e-48c9-9409-f0e3029b1935?type=property-photo", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "property_photo"}]	\N	\N	\N	2025-12-20 13:03:45.033	\N	2025-12-20 12:59:45.668268	2025-12-20 13:03:45.033	paid	A25L282660	1.00	2025-12-20 00:00:00	\N	\N	{}	0	\N	\N	homestay
d8839c8d-2219-4fdd-89f8-aaee7681ad84	2c41a160-de2a-4141-910e-4021bdeac7c4	HP-HS-2025-SML-000015	add_rooms	9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	HP-HS-2025-SML-000003	HP-HST-2025-71713	2026-12-20 10:34:37.6	{"renewalWindow": {"end": "2026-12-20T10:34:37.600Z", "start": "2026-09-21T10:34:37.600Z"}, "requestedRooms": {"total": 3, "double": 1, "family": 0, "single": 2}, "requiresPayment": true, "requestedRoomDelta": 1, "inheritsCertificateExpiry": "2026-12-20T10:34:37.600Z"}	\N	2025-12-20 17:46:45.159	Draft Homestay	gold	gp	3	Shimla	\N	Chaupal	\N	\N	\N	Village AAA	\N		\N		Test Property  \nAddress	171001	08091441005	\N	\N	\N	Test AAA	male	6666666610	test@test.com	\N	666666666610	owned	0.00	new_project	0.00	2	1	\N	2500.00	1	2	\N	3200.00	0	4	\N	0.00	3	222222222222222	gold	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N						{"cctv": true, "fireSafety": true}	\N	6000.00	6000.00	0.00	0.00	0.00	0.00	6000.00	0.00	0.00	rejected	\N	6	\N	\N	\N	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 17:50:55.949	2025-12-20 17:50:55.949	Forward to DTDO\nAdd your overall scrutiny remarks before forwarding this application to the District Tourism Development Officer.	\N	\N	\N	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	2025-12-20 17:51:41.396	1	Revert to Applicant\nThis will send the application back to the applicant for corrections. Please provide details.	APPLICATION AUTO-REJECTED: Application was sent back twice. Original reason: Revert to Applicant\nThis will send the application back to the applicant for corrections. Please provide details.	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "cedd91c3-8026-4adf-a475-af4431fdc4b7", "url": "/api/local-object/download/996697b3-7964-4399-a70e-8c56eeebc94f?type=revenue-papers", "name": "Test_Doc01-Hindi.pdf", "type": "revenue_papers", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/996697b3-7964-4399-a70e-8c56eeebc94f?type=revenue-papers", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "34aa8647-42b8-4071-8b57-90ea69185240", "url": "/api/local-object/download/493f71d0-b40a-4520-986e-75955b7be301?type=affidavit-section29", "name": "Test_Doc01-Hindi.pdf", "type": "affidavit_section_29", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/493f71d0-b40a-4520-986e-75955b7be301?type=affidavit-section29", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "2fa5fd58-f02a-42b5-b76f-4d4243cd7d6b", "url": "/api/local-object/download/88f7cc2b-bdc1-420f-b703-e7449c648c94?type=undertaking-form-c", "name": "Test_Doc01-Hindi.pdf", "type": "undertaking_form_c", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/88f7cc2b-bdc1-420f-b703-e7449c648c94?type=undertaking-form-c", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "4c0f53be-5799-49ca-bd97-e826a06c6ccd", "url": "/api/local-object/download/6bf3f636-c399-4810-a09a-5eb7c7345d94?type=commercial-electricity-bill", "name": "Test_Doc01-Hindi.pdf", "type": "commercial_electricity_bill", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/6bf3f636-c399-4810-a09a-5eb7c7345d94?type=commercial-electricity-bill", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "commercial_electricity_bill"}, {"id": "100eaa84-412a-46d3-9805-65305371d321", "url": "/api/local-object/download/6d8872a9-09a8-4650-ad02-c0c0d35812b7?type=commercial-water-bill", "name": "Test_Doc01-Hindi.pdf", "type": "commercial_water_bill", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/6d8872a9-09a8-4650-ad02-c0c0d35812b7?type=commercial-water-bill", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "commercial_water_bill"}, {"id": "0ac9e1e3-f13e-4557-b664-cbbe36339122", "url": "/api/local-object/download/71908a6f-b712-48a8-94c3-bea4759bb856?type=property-photo", "name": "519109575.jpg", "type": "property_photo", "fileName": "519109575.jpg", "filePath": "/api/local-object/download/71908a6f-b712-48a8-94c3-bea4759bb856?type=property-photo", "fileSize": 96524, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "42cc0ada-1d89-443c-9be1-5f9866da620d", "url": "/api/local-object/download/dcb8ba3b-7b99-42ab-800a-f1b75244d56a?type=property-photo", "name": "529253340.jpg", "type": "property_photo", "fileName": "529253340.jpg", "filePath": "/api/local-object/download/dcb8ba3b-7b99-42ab-800a-f1b75244d56a?type=property-photo", "fileSize": 13584, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "0c842b71-2c27-4c7a-b707-4b7f717a79d0", "url": "/api/local-object/download/cbcaef9e-39f1-4594-9c05-38aa2c47e725?type=property-photo", "name": "529253372.jpg", "type": "property_photo", "fileName": "529253372.jpg", "filePath": "/api/local-object/download/cbcaef9e-39f1-4594-9c05-38aa2c47e725?type=property-photo", "fileSize": 98782, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "a566a6f1-30bc-4e02-bbee-025736ca4737", "url": "/api/local-object/download/f3b6895c-af36-4ed6-b5a8-7237ef6cfcee?type=property-photo", "name": "519109575.jpg", "type": "property_photo", "fileName": "519109575.jpg", "filePath": "/api/local-object/download/f3b6895c-af36-4ed6-b5a8-7237ef6cfcee?type=property-photo", "fileSize": 96524, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "72c12fcd-61b6-423d-99cc-fdc299fd91fe", "url": "/api/local-object/download/44f404ed-03b0-4f2e-9feb-38e483d90c28?type=property-photo", "name": "Test_Doc01-Hindi.pdf", "type": "property_photo", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/44f404ed-03b0-4f2e-9feb-38e483d90c28?type=property-photo", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "property_photo"}]	\N	\N	\N	2025-12-20 17:49:42.534	\N	2025-12-20 17:46:45.167668	2025-12-20 17:51:41.396	paid	A25L283579	1.00	2025-12-20 00:00:00	\N	\N	{"waterfall": true, "hotSprings": true, "riverStream": true, "appleOrchards": true, "campingGround": true, "historicTemple": true, "mountainBiking": true, "heritageVillage": true, "handicraftMarket": true, "buddhistMonastery": true, "wildlifeSanctuary": true}	2	\N	\N	homestay
9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	2c41a160-de2a-4141-910e-4021bdeac7c4	HP-HS-2025-SML-000003	delete_rooms	ad83de55-95aa-46dd-b687-b9119d0c277b	HP-HS-2025-SML-000002	HP-HST-2025-58398	2026-12-20 10:31:29.296	{"renewalWindow": {"end": "2026-12-20T10:31:29.296Z", "start": "2026-09-21T10:31:29.296Z"}, "requestedRooms": {"total": 2, "double": 0, "family": 0, "single": 2}, "requiresPayment": false, "requestedDeletions": [{"count": 1, "roomType": "single"}], "requestedRoomDelta": -1, "inheritsCertificateExpiry": "2026-12-20T10:31:29.296Z"}	\N	2025-12-20 10:32:11.291	Draft Homestay	silver	gp	2	Shimla	\N	Chaupal	\N	\N	\N	Village AAA	\N	\N	\N	\N	Test Property  \nAddress	171001	08091441005	\N	\N	\N	Test AAA	male	6666666610	test@test.com	\N	666666666610	owned	0.00	new_project	0.00	2	1	\N	2500.00	0	2	\N	0.00	0	4	\N	0.00	2	\N	silver	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"cctv": true, "fireSafety": true}	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	approved	inspection_completed	6	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	2025-12-20 10:34:37.6	Verify for Payment\n\nThe owner will be allowed to proceed with payment.\nRemarks (Optional)	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 10:32:57.281	2025-12-20 10:32:57.281	Forward to DTDO\nAdd your overall scrutiny remarks before forwarding this application to the District Tourism Development Officer.	\N	\N	\N	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	2025-12-20 10:33:23.355	1	Accept Application\n\nThis will schedule an inspection for the property.\nInspection Remarks (Required)	\N	\N	2025-12-23 04:30:00	2025-12-20 10:34:15.976	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	Log Earlier Visit\nEnable if the physical inspection happened up to 7 days before the scheduled date.	recommended	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "cedd91c3-8026-4adf-a475-af4431fdc4b7", "url": "/api/local-object/download/996697b3-7964-4399-a70e-8c56eeebc94f?type=revenue-papers", "name": "Test_Doc01-Hindi.pdf", "type": "revenue_papers", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/996697b3-7964-4399-a70e-8c56eeebc94f?type=revenue-papers", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "34aa8647-42b8-4071-8b57-90ea69185240", "url": "/api/local-object/download/493f71d0-b40a-4520-986e-75955b7be301?type=affidavit-section29", "name": "Test_Doc01-Hindi.pdf", "type": "affidavit_section_29", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/493f71d0-b40a-4520-986e-75955b7be301?type=affidavit-section29", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "2fa5fd58-f02a-42b5-b76f-4d4243cd7d6b", "url": "/api/local-object/download/88f7cc2b-bdc1-420f-b703-e7449c648c94?type=undertaking-form-c", "name": "Test_Doc01-Hindi.pdf", "type": "undertaking_form_c", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/88f7cc2b-bdc1-420f-b703-e7449c648c94?type=undertaking-form-c", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "0ac9e1e3-f13e-4557-b664-cbbe36339122", "url": "/api/local-object/download/71908a6f-b712-48a8-94c3-bea4759bb856?type=property-photo", "name": "519109575.jpg", "type": "property_photo", "fileName": "519109575.jpg", "filePath": "/api/local-object/download/71908a6f-b712-48a8-94c3-bea4759bb856?type=property-photo", "fileSize": 96524, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "42cc0ada-1d89-443c-9be1-5f9866da620d", "url": "/api/local-object/download/dcb8ba3b-7b99-42ab-800a-f1b75244d56a?type=property-photo", "name": "529253340.jpg", "type": "property_photo", "fileName": "529253340.jpg", "filePath": "/api/local-object/download/dcb8ba3b-7b99-42ab-800a-f1b75244d56a?type=property-photo", "fileSize": 13584, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "0c842b71-2c27-4c7a-b707-4b7f717a79d0", "url": "/api/local-object/download/cbcaef9e-39f1-4594-9c05-38aa2c47e725?type=property-photo", "name": "529253372.jpg", "type": "property_photo", "fileName": "529253372.jpg", "filePath": "/api/local-object/download/cbcaef9e-39f1-4594-9c05-38aa2c47e725?type=property-photo", "fileSize": 98782, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "a566a6f1-30bc-4e02-bbee-025736ca4737", "url": "/api/local-object/download/f3b6895c-af36-4ed6-b5a8-7237ef6cfcee?type=property-photo", "name": "519109575.jpg", "type": "property_photo", "fileName": "519109575.jpg", "filePath": "/api/local-object/download/f3b6895c-af36-4ed6-b5a8-7237ef6cfcee?type=property-photo", "fileSize": 96524, "mimeType": "image/jpeg", "documentType": "property_photo"}]	HP-HST-2025-71713	2025-12-20 10:34:37.6	2026-12-20 10:34:37.6	2025-12-20 10:32:25.718	2025-12-20 10:34:37.6	2025-12-20 10:32:11.296937	2025-12-20 10:34:37.6	paid	A25L280888	1.00	2025-12-20 00:00:00	\N	\N	{"hotSprings": true, "riverStream": true, "appleOrchards": true, "campingGround": true, "historicTemple": true, "heritageVillage": true, "buddhistMonastery": true, "wildlifeSanctuary": true}	1	\N	\N	homestay
79d13cf0-3180-49a0-8dd6-d1b5cddc372b	0bbe93ff-cac5-4e91-b2f2-686669d01d05	HP-HS-2025-CHM-000009	new_registration	\N	\N	\N	\N	\N	\N	\N	d	silver	mc	1	Chamba	\N	Bhalai	\N	\N	\N		\N	d	\N		fds	177676		\N	\N	\N	DSFAS FDSGE	male	7777777705	a4@gmail.cpm	\N	111111111106	owned	0.00	new_project	0.00	1	1	\N	1.00	0	2	\N	0.00	0	4	\N	0.00	1		silver	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N						{"cctv": true, "fireSafety": true}	\N	8000.00	8000.00	0.00	0.00	0.00	0.00	8000.00	0.00	0.00	submitted	\N	6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "a26a0d18-04c3-4277-969a-a209dcac1970", "url": "/api/local-object/download/37cc2615-92be-400b-ba84-c8fe4fc82673?type=revenue-papers", "name": "basic-text.pdf", "type": "revenue_papers", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/37cc2615-92be-400b-ba84-c8fe4fc82673?type=revenue-papers", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "5e04aab0-ec77-481e-9783-7cf91b7ed7f4", "url": "/api/local-object/download/58a0903b-c927-47d6-85b9-49829303ad06?type=affidavit-section29", "name": "basic-text.pdf", "type": "affidavit_section_29", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/58a0903b-c927-47d6-85b9-49829303ad06?type=affidavit-section29", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "c18fcd71-d382-4f48-8db9-7acce1305203", "url": "/api/local-object/download/aaec5845-9c76-4681-b5ea-eef038218553?type=undertaking-form-c", "name": "basic-text.pdf", "type": "undertaking_form_c", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/aaec5845-9c76-4681-b5ea-eef038218553?type=undertaking-form-c", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "f15f013c-eb25-48f9-8170-ff878edd2613", "url": "/api/local-object/download/fa91f752-9a32-4b0a-a16c-786a897c12a9?type=property-photo", "name": "basic-text.pdf", "type": "property_photo", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/fa91f752-9a32-4b0a-a16c-786a897c12a9?type=property-photo", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "property_photo"}, {"id": "dee26ed1-f55b-4104-8bf2-0fbff5726d87", "url": "/api/local-object/download/c2e506e4-6c2c-4250-94ae-275cc5db8a16?type=property-photo", "name": "basic-text.pdf", "type": "property_photo", "fileName": "basic-text.pdf", "filePath": "/api/local-object/download/c2e506e4-6c2c-4250-94ae-275cc5db8a16?type=property-photo", "fileSize": 74656, "mimeType": "application/pdf", "documentType": "property_photo"}]	\N	\N	\N	2025-12-20 13:08:04.919	\N	2025-12-20 13:05:23.653039	2025-12-20 13:08:04.919	paid	A25L282685	1.00	2025-12-20 00:00:00	\N	\N	{}	0	\N	\N	homestay
\.


--
-- Data for Name: inspection_orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inspection_orders (id, application_id, scheduled_by, scheduled_date, assigned_to, assigned_date, inspection_date, inspection_address, special_instructions, status, dtdo_notes, created_at, updated_at) FROM stdin;
16747d76-2920-40c4-a797-cd288f1bb6cf	6ba7d780-bae2-49a2-814d-e8ed785e3fd6	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	2025-12-20 10:23:29.258	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 10:23:29.258	2025-12-23 04:30:00	Test Property  \nAddress	\N	completed	\N	2025-12-20 10:23:29.258704	2025-12-20 10:24:39.441
005bacac-ebbf-4410-b2bd-4765da706724	ad83de55-95aa-46dd-b687-b9119d0c277b	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	2025-12-20 10:29:55.353	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 10:29:55.353	2025-12-22 04:30:00	Test Property  \nAddress	Message for Owner (optional)	completed	\N	2025-12-20 10:29:55.354235	2025-12-20 10:30:54.454
0c6f58c6-5c44-4d0a-9efb-61b02c667ba4	9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	2025-12-20 10:33:35.116	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 10:33:35.116	2025-12-23 04:30:00	Test Property  \nAddress	\N	completed	\N	2025-12-20 10:33:35.116606	2025-12-20 10:34:15.969
169575ee-dbdc-49da-9e28-f76521e94033	445059d3-940e-47d5-b73c-41026472af81	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	2025-12-20 18:57:34.005	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 18:57:34.005	2025-12-24 04:30:00	dfsd	dasfsdf	completed	\N	2025-12-20 18:57:34.005884	2025-12-20 18:59:15.092
\.


--
-- Data for Name: inspection_reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inspection_reports (id, inspection_order_id, application_id, submitted_by, submitted_date, actual_inspection_date, room_count_verified, actual_room_count, category_meets_standards, recommended_category, mandatory_checklist, mandatory_remarks, desirable_checklist, desirable_remarks, amenities_verified, amenities_issues, fire_safety_compliant, fire_safety_issues, structural_safety, structural_issues, overall_satisfactory, recommendation, detailed_findings, inspection_photos, report_document_url, created_at, updated_at) FROM stdin;
d79f1a7d-f5ca-485e-9e47-d8659c7aab68	16747d76-2920-40c4-a797-cd288f1bb6cf	6ba7d780-bae2-49a2-814d-e8ed785e3fd6	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 10:24:39.436	2025-12-19 00:00:00	t	\N	t	\N	{"roomSize": true, "documents": true, "cleanRooms": true, "cctvCameras": true, "visitorBook": true, "cleanKitchen": true, "doctorDetails": true, "fireEquipment": true, "guestRegister": true, "onlinePayment": true, "wasteDisposal": true, "waterFacility": true, "wellMaintained": true, "applicationForm": true, "cutleryCrockery": true, "luggageAssistance": true, "comfortableBedding": true, "energySavingLights": true}	Early inspection override: Conducted 4 days before the scheduled date (December 23rd, 2025). Reason: Reason for Early Inspection\nProvide context for DTDO on why the visit was advanced (minimum 15 characters).	{"lounge": false, "laundry": false, "parking": false, "storage": false, "wardrobe": false, "furniture": false, "diningArea": false, "luggageHelp": false, "safeStorage": false, "hotColdWater": false, "refrigerator": false, "securityGuard": false, "heatingCooling": false, "himachaliCrafts": false, "toiletAmenities": false, "attachedBathroom": false, "waterConservation": false, "rainwaterHarvesting": false}	\N	\N	\N	f	\N	f	\N	t	approve	Findings & Recommendation\nOverall Inspection Summary *\nCapture the key highlights of this visit (minimum 20 characters). This summary is stored with the RC.	\N	\N	2025-12-20 10:24:39.439671	2025-12-20 10:24:39.439671
34e0e73e-b695-4730-bd25-98caa2381272	005bacac-ebbf-4410-b2bd-4765da706724	ad83de55-95aa-46dd-b687-b9119d0c277b	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 10:30:54.446	2025-12-18 00:00:00	t	\N	t	\N	{"roomSize": true, "documents": true, "cleanRooms": true, "cctvCameras": true, "visitorBook": true, "cleanKitchen": true, "doctorDetails": true, "fireEquipment": true, "guestRegister": true, "onlinePayment": true, "wasteDisposal": true, "waterFacility": true, "wellMaintained": true, "applicationForm": true, "cutleryCrockery": true, "luggageAssistance": true, "comfortableBedding": true, "energySavingLights": true}	Early inspection override: Conducted 4 days before the scheduled date (December 22nd, 2025). Reason: Reason for Early Inspection\nProvide context for DTDO on why the visit was advanced (minimum 15 characters).	{"lounge": false, "laundry": false, "parking": false, "storage": false, "wardrobe": false, "furniture": false, "diningArea": false, "luggageHelp": false, "safeStorage": false, "hotColdWater": false, "refrigerator": false, "securityGuard": false, "heatingCooling": false, "himachaliCrafts": false, "toiletAmenities": false, "attachedBathroom": false, "waterConservation": false, "rainwaterHarvesting": false}	\N	\N	\N	f	\N	f	\N	t	approve	Findings & Recommendation\nOverall Inspection Summary *\nCapture the key highlights of this visit (minimum 20 characters). This summary is stored with the RC.	\N	\N	2025-12-20 10:30:54.451874	2025-12-20 10:30:54.451874
98f6e09c-bf54-4297-a016-f3c8a9d1856a	0c6f58c6-5c44-4d0a-9efb-61b02c667ba4	9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 10:34:15.962	2025-12-18 00:00:00	t	\N	t	\N	{"roomSize": true, "documents": true, "cleanRooms": true, "cctvCameras": true, "visitorBook": true, "cleanKitchen": true, "doctorDetails": true, "fireEquipment": true, "guestRegister": true, "onlinePayment": true, "wasteDisposal": true, "waterFacility": true, "wellMaintained": true, "applicationForm": true, "cutleryCrockery": true, "luggageAssistance": true, "comfortableBedding": true, "energySavingLights": true}	Early inspection override: Conducted 5 days before the scheduled date (December 23rd, 2025). Reason: Log Earlier Visit\nEnable if the physical inspection happened up to 7 days before the scheduled date.	{"lounge": false, "laundry": false, "parking": false, "storage": false, "wardrobe": false, "furniture": false, "diningArea": false, "luggageHelp": false, "safeStorage": false, "hotColdWater": false, "refrigerator": false, "securityGuard": false, "heatingCooling": false, "himachaliCrafts": false, "toiletAmenities": false, "attachedBathroom": false, "waterConservation": false, "rainwaterHarvesting": false}	\N	\N	\N	f	\N	f	\N	t	approve	Log Earlier Visit\nEnable if the physical inspection happened up to 7 days before the scheduled date.	\N	\N	2025-12-20 10:34:15.967151	2025-12-20 10:34:15.967151
beed689a-4bc8-41f0-81ca-d813beaf840f	169575ee-dbdc-49da-9e28-f76521e94033	445059d3-940e-47d5-b73c-41026472af81	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-20 18:59:15.086	2025-12-18 00:00:00	t	\N	t	\N	{"roomSize": true, "documents": true, "cleanRooms": true, "cctvCameras": true, "visitorBook": true, "cleanKitchen": true, "doctorDetails": true, "fireEquipment": true, "guestRegister": true, "onlinePayment": true, "wasteDisposal": true, "waterFacility": true, "wellMaintained": true, "applicationForm": true, "cutleryCrockery": true, "luggageAssistance": true, "comfortableBedding": true, "energySavingLights": true}	Early inspection override: Conducted 6 days before the scheduled date (December 24th, 2025). Reason: gcbgcbbjghg  gyjgjh	{"lounge": false, "laundry": false, "parking": false, "storage": false, "wardrobe": false, "furniture": false, "diningArea": false, "luggageHelp": false, "safeStorage": false, "hotColdWater": false, "refrigerator": false, "securityGuard": false, "heatingCooling": false, "himachaliCrafts": false, "toiletAmenities": false, "attachedBathroom": false, "waterConservation": false, "rainwaterHarvesting": false}	\N	\N	\N	f	\N	f	\N	t	approve	gcbgcbbjghg  gyjgjhasfdsf	\N	\N	2025-12-20 18:59:15.08957	2025-12-20 18:59:15.08957
\.


--
-- Data for Name: lgd_blocks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lgd_blocks (id, lgd_code, block_name, district_id, tehsil_id, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_districts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lgd_districts (id, lgd_code, district_name, division_name, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_gram_panchayats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lgd_gram_panchayats (id, lgd_code, gram_panchayat_name, district_id, block_id, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_tehsils; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lgd_tehsils (id, lgd_code, tehsil_name, district_id, tehsil_type, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_urban_bodies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lgd_urban_bodies (id, lgd_code, urban_body_name, district_id, body_type, number_of_wards, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: login_otp_challenges; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.login_otp_challenges (id, user_id, otp_hash, expires_at, consumed_at, created_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, user_id, application_id, type, title, message, channels, is_read, read_at, created_at) FROM stdin;
a1b4e0ac-8120-40ec-8ac3-fc71878e3d49	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	\N	inspection_assigned	New Inspection Assigned	You have been assigned an inspection for application HP-HS-2025-SML-000001 on 23 Dec 2025	{"inapp": true}	f	\N	2025-12-20 10:23:29.269636
17507aa4-ce7f-4a1c-b7f6-fe27a2c8739d	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	\N	inspection_assigned	New Inspection Assigned	You have been assigned an inspection for application HP-HS-2025-SML-000002 on 22 Dec 2025	{"inapp": true}	f	\N	2025-12-20 10:29:55.365168
a00d8851-c651-456d-bd7b-b29d815995d7	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	\N	inspection_assigned	New Inspection Assigned	You have been assigned an inspection for application HP-HS-2025-SML-000003 on 23 Dec 2025	{"inapp": true}	f	\N	2025-12-20 10:33:35.124505
a7c030fe-b3d4-432b-b472-6cb2074bb147	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	\N	inspection_assigned	New Inspection Assigned	You have been assigned an inspection for application HP-HS-2025-SML-000012 on 24 Dec 2025	{"inapp": true}	f	\N	2025-12-20 18:57:34.026117
\.


--
-- Data for Name: objections; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.objections (id, application_id, inspection_report_id, raised_by, raised_date, objection_type, objection_title, objection_description, severity, response_deadline, status, resolution_notes, resolved_by, resolved_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: password_reset_challenges; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.password_reset_challenges (id, user_id, channel, recipient, otp_hash, expires_at, consumed_at, created_at) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (id, application_id, payment_type, amount, payment_gateway, gateway_transaction_id, payment_method, payment_status, payment_link, qr_code_url, payment_link_expiry_date, initiated_at, completed_at, receipt_number, receipt_url) FROM stdin;
\.


--
-- Data for Name: production_stats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.production_stats (id, total_applications, approved_applications, rejected_applications, pending_applications, scraped_at, source_url) FROM stdin;
f57c36d2-908c-46d6-9cd6-6b26fd9a3129	4	4	4	4	2025-12-11 11:35:28.622262	https://eservices.himachaltourism.gov.in/
a9734bfc-adb2-432c-8b0d-a020d0f46b94	4	4	4	4	2025-12-11 12:35:28.639809	https://eservices.himachaltourism.gov.in/
6fd7f768-8eda-4155-b09a-fc229e52f7c6	4	4	4	4	2025-12-11 13:35:28.615156	https://eservices.himachaltourism.gov.in/
5ded5b32-ca6b-4a92-b4fe-413b59ce6d9f	4	4	4	4	2025-12-11 14:35:28.636386	https://eservices.himachaltourism.gov.in/
1d70279b-d8fc-46a1-8a6c-a193531d09fd	4	4	4	4	2025-12-11 15:35:28.595179	https://eservices.himachaltourism.gov.in/
426a11d3-281b-452d-8a3a-9433c40475af	4	4	4	4	2025-12-11 16:35:28.610253	https://eservices.himachaltourism.gov.in/
68eac4da-daf9-42e8-ae8c-55e7d04913ba	4	4	4	4	2025-12-11 17:35:28.614239	https://eservices.himachaltourism.gov.in/
8a9e8542-62bf-4223-976f-166c5a1f3329	4	4	4	4	2025-12-11 18:35:28.616999	https://eservices.himachaltourism.gov.in/
dad4d2ea-f9b3-4710-b527-78a7892ab185	4	4	4	4	2025-12-11 19:35:28.596146	https://eservices.himachaltourism.gov.in/
98f3428a-a345-4cb3-b9ea-1d9c4b24ce9d	4	4	4	4	2025-12-11 20:00:14.901908	https://eservices.himachaltourism.gov.in/
6d439101-a930-4d41-bf58-0fb49893a11a	4	4	4	4	2025-12-11 21:00:14.837613	https://eservices.himachaltourism.gov.in/
377c036f-aa6f-42c9-b75b-1acf9e584dd5	4	4	4	4	2025-12-11 22:00:14.837728	https://eservices.himachaltourism.gov.in/
eb40dcf9-8f75-4bb6-88f7-cab5cfde4776	4	4	4	4	2025-12-11 23:00:14.831331	https://eservices.himachaltourism.gov.in/
13d62295-9de2-4c21-9af0-9199088aa10a	4	4	4	4	2025-12-12 00:00:14.891522	https://eservices.himachaltourism.gov.in/
ad1bf456-7b8b-408f-a6b7-6b315c668f5b	4	4	4	4	2025-12-12 01:00:14.870015	https://eservices.himachaltourism.gov.in/
fe31ae44-6303-4566-86b3-ed90210cb068	4	4	4	4	2025-12-12 02:00:14.86043	https://eservices.himachaltourism.gov.in/
2a2eaf72-15fa-45a4-8e37-4894e00a7d7a	4	4	4	4	2025-12-12 03:00:14.845569	https://eservices.himachaltourism.gov.in/
5da2dafd-0727-456a-8871-a754439946d9	4	4	4	4	2025-12-12 03:21:36.783435	https://eservices.himachaltourism.gov.in/
2dd67f6b-ffe8-4738-a1e3-7110ec13315e	4	4	4	4	2025-12-12 03:21:55.197582	https://eservices.himachaltourism.gov.in/
1e792475-24f4-4b31-b619-13558fee2384	4	4	4	4	2025-12-12 03:24:27.905315	https://eservices.himachaltourism.gov.in/
19ce2576-4c4c-46a7-9100-1e0d4b4ece84	4	4	4	4	2025-12-12 03:26:39.02943	https://eservices.himachaltourism.gov.in/
544bf8c6-edc1-49d6-b521-30d4abf847ec	4	4	4	4	2025-12-12 03:26:41.637849	https://eservices.himachaltourism.gov.in/
a197a26a-c2dc-4c14-8db9-e04183191d70	4	4	4	4	2025-12-12 03:26:45.571155	https://eservices.himachaltourism.gov.in/
3188a6e7-6009-4e9c-875c-cee0b22e14b2	4	4	4	4	2025-12-12 03:26:48.504676	https://eservices.himachaltourism.gov.in/
26ab6205-41f2-4420-b30b-1257912b8ee2	4	4	4	4	2025-12-12 03:28:32.562989	https://eservices.himachaltourism.gov.in/
128f4010-452d-4545-8c48-576a29ef59a8	4	4	4	4	2025-12-12 03:28:46.512692	https://eservices.himachaltourism.gov.in/
3d5369a7-403a-4739-971d-2cac695d7d60	4	4	4	4	2025-12-12 03:28:50.218291	https://eservices.himachaltourism.gov.in/
a12d6dc8-3530-41d7-91d9-074b653f1768	4	4	4	4	2025-12-12 03:29:02.235177	https://eservices.himachaltourism.gov.in/
8d032faf-9a89-4592-9deb-9ae90a948c67	4	4	4	4	2025-12-12 03:29:04.495149	https://eservices.himachaltourism.gov.in/
c462e98b-4310-4d9c-8483-2ac6f7ebcd4d	4	4	4	4	2025-12-12 03:29:15.571199	https://eservices.himachaltourism.gov.in/
f318a9e2-4b11-47d8-a758-251a18cde190	4	4	4	4	2025-12-12 03:30:38.834029	https://eservices.himachaltourism.gov.in/
44a4fd8e-2423-42f1-a9fa-63cf2191edf4	4	4	4	4	2025-12-12 03:30:40.816869	https://eservices.himachaltourism.gov.in/
b0f66976-7a3b-4724-8a21-416bfba09533	4	4	4	4	2025-12-12 03:30:50.304486	https://eservices.himachaltourism.gov.in/
de110b26-4df6-4339-9879-684fc74f8832	4	4	4	4	2025-12-12 03:30:55.199878	https://eservices.himachaltourism.gov.in/
597f4fa4-22d4-4080-9de7-37e0582e3ae1	4	4	4	4	2025-12-12 03:30:59.155563	https://eservices.himachaltourism.gov.in/
04dc6efd-f676-4eaa-9a78-a8fbfcb2022f	4	4	4	4	2025-12-12 03:31:01.033138	https://eservices.himachaltourism.gov.in/
2fbf5566-e28d-4d85-8bf0-a0ad7cbdb63d	4	4	4	4	2025-12-12 03:31:06.474581	https://eservices.himachaltourism.gov.in/
b3fa0f2b-84e0-481e-ba4c-c6073b1e16d9	4	4	4	4	2025-12-12 03:31:14.189927	https://eservices.himachaltourism.gov.in/
63545717-22b2-4c47-8b0e-6cb37de81536	4	4	4	4	2025-12-12 03:31:18.013268	https://eservices.himachaltourism.gov.in/
4ddc475a-0fc4-4bc9-b494-422cc5a52cf7	4	4	4	4	2025-12-12 03:31:35.614223	https://eservices.himachaltourism.gov.in/
9d68df5f-11bc-4394-a1d3-088008f63fef	4	4	4	4	2025-12-12 03:32:25.897124	https://eservices.himachaltourism.gov.in/
fdb2bdad-4ecd-4d98-b07d-d9dacc8ea9c1	4	4	4	4	2025-12-12 03:32:27.75184	https://eservices.himachaltourism.gov.in/
0826c5b1-1958-48c0-b592-18618482a46f	4	4	4	4	2025-12-12 03:33:59.57813	https://eservices.himachaltourism.gov.in/
6cd17cd6-c7c9-46fb-9213-82248530669c	4	4	4	4	2025-12-12 03:39:59.036458	https://eservices.himachaltourism.gov.in/
d3a5603f-9bdd-49a2-95f3-e91521faae44	4	4	4	4	2025-12-12 04:39:59.046464	https://eservices.himachaltourism.gov.in/
80343f77-ecf1-4ba2-afa3-54e71e80e5ce	4	4	4	4	2025-12-12 04:46:34.322882	https://eservices.himachaltourism.gov.in/
3a132f86-5846-4796-83ec-0979263ebdf6	4	4	4	4	2025-12-12 04:51:39.123795	https://eservices.himachaltourism.gov.in/
390471f9-87a1-40d6-8821-46174b953a23	4	4	4	4	2025-12-12 04:59:54.740988	https://eservices.himachaltourism.gov.in/
047e6c3d-b242-4894-a0cf-82338c7da5bf	4	4	4	4	2025-12-12 05:59:55.434898	https://eservices.himachaltourism.gov.in/
b34aa6c4-0473-4e7f-a91c-c2561526e9dd	4	4	4	4	2025-12-12 06:59:54.735174	https://eservices.himachaltourism.gov.in/
a813dc1d-c8ac-4b5e-8d53-1df927664933	4	4	4	4	2025-12-12 07:59:25.596244	https://eservices.himachaltourism.gov.in/
881cbde8-74ab-4d07-a19b-006a326bac20	4	4	4	4	2025-12-12 08:18:59.697284	https://eservices.himachaltourism.gov.in/
63127c41-76bb-4df8-8590-1267899a09ab	4	4	4	4	2025-12-12 09:18:59.786867	https://eservices.himachaltourism.gov.in/
ce4609ac-6912-4ddd-af8f-e18e81ebdc37	4	4	4	4	2025-12-12 09:24:20.109746	https://eservices.himachaltourism.gov.in/
3553e539-5ea1-4264-a573-071b135eb507	4	4	4	4	2025-12-12 09:36:53.613523	https://eservices.himachaltourism.gov.in/
c1b6b4cb-5078-43d1-ba58-b4ded9194ab4	4	4	4	4	2025-12-12 09:56:26.98512	https://eservices.himachaltourism.gov.in/
148e66b5-7db1-452d-8186-4d4f37e29597	4	4	4	4	2025-12-12 10:17:09.286244	https://eservices.himachaltourism.gov.in/
7f387501-3b63-4083-b995-2cb89f92d205	4	4	4	4	2025-12-12 10:58:07.936729	https://eservices.himachaltourism.gov.in/
11781a1b-8141-48c6-8b5a-51f8dd42a5ff	4	4	4	4	2025-12-12 11:07:07.845709	https://eservices.himachaltourism.gov.in/
a8832ff0-167c-4f83-a0b0-919b657af86b	4	4	4	4	2025-12-12 11:29:23.911432	https://eservices.himachaltourism.gov.in/
26ccc113-daf1-4ec9-995c-2379511cc516	4	4	4	4	2025-12-12 12:29:23.904694	https://eservices.himachaltourism.gov.in/
88d219fd-e9ea-48d6-a539-bc1a5c3a7b24	4	4	4	4	2025-12-12 13:29:23.916131	https://eservices.himachaltourism.gov.in/
1fa17449-3875-430b-a127-91870d83bed2	4	4	4	4	2025-12-12 14:29:23.950738	https://eservices.himachaltourism.gov.in/
93d31ed7-14e6-4379-af8e-cacea0987e3d	4	4	4	4	2025-12-12 15:29:23.942504	https://eservices.himachaltourism.gov.in/
7cdfd333-ca87-40f0-8d0e-e623fff2dc56	4	4	4	4	2025-12-12 16:01:59.611172	https://eservices.himachaltourism.gov.in/
055917bd-3658-46e2-bcf4-d0bbba8e1cb6	4	4	4	4	2025-12-12 17:01:59.640972	https://eservices.himachaltourism.gov.in/
4ed2e4e7-6284-4e57-bbf4-fd07236ff8eb	4	4	4	4	2025-12-12 18:01:59.580047	https://eservices.himachaltourism.gov.in/
1712fd01-445b-4b55-9f34-d80adb210d8f	4	4	4	4	2025-12-12 19:01:59.670871	https://eservices.himachaltourism.gov.in/
70c060f5-9f30-4cae-bc4b-d0ac7968f3bd	4	4	4	4	2025-12-12 19:21:15.343379	https://eservices.himachaltourism.gov.in/
6cba0cab-4cfe-4d8a-8ebf-e6c050aecb79	4	4	4	4	2025-12-12 19:28:07.497946	https://eservices.himachaltourism.gov.in/
965637ee-767b-4e96-b0d8-e2c80baadcf5	4	4	4	4	2025-12-12 19:31:38.679296	https://eservices.himachaltourism.gov.in/
7e8c0ce8-d262-441c-8f58-137f4c7ddefe	4	4	4	4	2025-12-12 20:08:23.809908	https://eservices.himachaltourism.gov.in/
79663d1d-30c9-4693-a599-862225226bf4	4	4	4	4	2025-12-12 20:15:37.529301	https://eservices.himachaltourism.gov.in/
6734957d-7801-4d67-8363-2c37bfc531b7	4	4	4	4	2025-12-12 21:15:37.481415	https://eservices.himachaltourism.gov.in/
128ecd39-87bf-4383-81f2-cc89c2b74481	4	4	4	4	2025-12-12 22:15:37.500282	https://eservices.himachaltourism.gov.in/
c5f7bf3a-c0ff-4c80-80c6-e281084504db	4	4	4	4	2025-12-12 23:15:37.543584	https://eservices.himachaltourism.gov.in/
814905e0-a574-46bb-9b31-26a07dac3f7d	4	4	4	4	2025-12-13 00:15:37.504034	https://eservices.himachaltourism.gov.in/
0a83c44b-10a5-44d1-bbaf-0349251684a7	4	4	4	4	2025-12-13 01:15:37.516511	https://eservices.himachaltourism.gov.in/
d535a5d6-c5fd-4ddb-b4bf-3be28aa7f8d6	4	4	4	4	2025-12-13 02:15:37.527626	https://eservices.himachaltourism.gov.in/
7b9cc2bd-dd16-44f7-ae57-6c51123dd701	4	4	4	4	2025-12-13 04:15:41.708831	https://eservices.himachaltourism.gov.in/
0885f040-308b-456b-9a75-c07720cf0843	4	4	4	4	2025-12-13 04:29:13.975032	https://eservices.himachaltourism.gov.in/
380c41c9-6e1c-4207-9a4a-aa74e1e86b14	4	4	4	4	2025-12-13 04:38:35.212077	https://eservices.himachaltourism.gov.in/
6c515659-f6b3-4146-9d11-a4cabaa446af	4	4	4	4	2025-12-13 04:50:18.655666	https://eservices.himachaltourism.gov.in/
94d8945b-a91e-4996-8267-7b722214f335	4	4	4	4	2025-12-13 05:05:29.460519	https://eservices.himachaltourism.gov.in/
6f6dce6c-50a2-4199-8b68-909f4f1d57f2	4	4	4	4	2025-12-13 05:23:55.168369	https://eservices.himachaltourism.gov.in/
af48c283-e8f3-4bbb-8a8f-e6f6e0b24780	4	4	4	4	2025-12-13 06:23:55.141798	https://eservices.himachaltourism.gov.in/
373b2250-b044-4535-8d6b-f0ecfb7e5b6f	4	4	4	4	2025-12-13 07:23:55.186018	https://eservices.himachaltourism.gov.in/
67644b02-69c0-46dc-a9b6-cb34e9339459	4	4	4	4	2025-12-13 08:23:55.145976	https://eservices.himachaltourism.gov.in/
1a6dd574-54e4-4b43-b23c-d48c28e793c6	4	4	4	4	2025-12-13 09:23:55.18029	https://eservices.himachaltourism.gov.in/
ac17bcf2-73aa-45ea-9e02-60398b0c8292	4	4	4	4	2025-12-13 10:23:55.168807	https://eservices.himachaltourism.gov.in/
678a464e-f121-4fa0-b763-95e62d28d579	4	4	4	4	2025-12-13 11:23:55.181344	https://eservices.himachaltourism.gov.in/
bbbb0a42-0f28-4889-b5c2-b251708fc9a2	4	4	4	4	2025-12-13 12:23:55.210362	https://eservices.himachaltourism.gov.in/
0f698a5c-3bde-4434-8930-eed898db51c4	4	4	4	4	2025-12-13 13:23:55.177093	https://eservices.himachaltourism.gov.in/
1f157e20-cd54-4f45-a0d5-dd455c5ebdb4	4	4	4	4	2025-12-13 14:23:55.147841	https://eservices.himachaltourism.gov.in/
bf624d71-245f-4e10-874a-684e8824fd88	4	4	4	4	2025-12-13 15:23:55.149165	https://eservices.himachaltourism.gov.in/
3eb223e3-9487-41a1-8c03-e3b1d9364292	4	4	4	4	2025-12-13 16:23:55.207555	https://eservices.himachaltourism.gov.in/
b2ce09a0-3a00-44b6-a27f-21e684f74511	4	4	4	4	2025-12-13 17:23:55.163917	https://eservices.himachaltourism.gov.in/
e5b26bc9-6d6f-425b-9ea9-6d436e877b03	4	4	4	4	2025-12-13 18:23:55.163227	https://eservices.himachaltourism.gov.in/
eaf81de8-121b-4176-bb40-4592f1f0f4db	4	4	4	4	2025-12-13 19:23:55.152457	https://eservices.himachaltourism.gov.in/
93ed1848-aaa6-4cd3-b053-15899e8aa347	4	4	4	4	2025-12-13 20:23:55.172897	https://eservices.himachaltourism.gov.in/
93549e99-909e-4c62-b332-c1263812b083	4	4	4	4	2025-12-13 21:23:55.170682	https://eservices.himachaltourism.gov.in/
02a5c734-5efe-4e54-9e55-2616bd652c15	4	4	4	4	2025-12-13 22:23:55.162757	https://eservices.himachaltourism.gov.in/
09f4789d-0de5-48c1-baf0-1e271458cea8	4	4	4	4	2025-12-13 23:23:55.204357	https://eservices.himachaltourism.gov.in/
43f39c43-acf5-4997-be2f-c13338892742	4	4	4	4	2025-12-14 00:23:55.171384	https://eservices.himachaltourism.gov.in/
a9b4a33f-8d06-4690-a0a4-e2746a70f4d2	4	4	4	4	2025-12-14 01:23:55.138716	https://eservices.himachaltourism.gov.in/
fd122a5e-51e7-420a-9321-bdc3848acea9	4	4	4	4	2025-12-14 02:23:55.151018	https://eservices.himachaltourism.gov.in/
0d5ff80e-1a9b-4e90-9c39-43027298092b	4	4	4	4	2025-12-14 03:23:55.159514	https://eservices.himachaltourism.gov.in/
420f49eb-e466-4c1e-afc8-f0b1ca8ec362	4	4	4	4	2025-12-14 04:23:55.152387	https://eservices.himachaltourism.gov.in/
d2f94444-00a5-4854-9ed5-ee079e66689c	4	4	4	4	2025-12-14 05:23:55.161533	https://eservices.himachaltourism.gov.in/
a34bee53-5ba1-4a91-8d4d-be6bc48cca31	4	4	4	4	2025-12-14 06:23:55.168858	https://eservices.himachaltourism.gov.in/
e53c912d-27d6-4f41-b372-7644f84ade26	4	4	4	4	2025-12-14 07:23:55.151147	https://eservices.himachaltourism.gov.in/
10c72076-e229-4d3e-b78c-6dccbf694b09	4	4	4	4	2025-12-14 08:23:55.158665	https://eservices.himachaltourism.gov.in/
187385b5-e3b9-4568-959e-431226cf6c21	4	4	4	4	2025-12-14 09:23:55.200837	https://eservices.himachaltourism.gov.in/
8f7735a8-f004-422a-89d3-a0eba6902dd1	4	4	4	4	2025-12-14 10:23:55.17202	https://eservices.himachaltourism.gov.in/
191a6e8d-1b11-4d00-aeb3-51e4fffeb351	4	4	4	4	2025-12-14 11:23:55.154613	https://eservices.himachaltourism.gov.in/
a5314622-94b6-42b0-83d1-cf721c17e08e	4	4	4	4	2025-12-14 12:23:55.142569	https://eservices.himachaltourism.gov.in/
46fdb2d8-9989-4f56-bc4a-8d7d9afc7950	4	4	4	4	2025-12-14 13:23:55.169369	https://eservices.himachaltourism.gov.in/
19cd6a6a-4ca1-4188-acde-99f5519bb79e	4	4	4	4	2025-12-14 14:23:55.15411	https://eservices.himachaltourism.gov.in/
2bca3841-21ee-4cfd-890e-3d478d92bdff	4	4	4	4	2025-12-14 15:23:55.153973	https://eservices.himachaltourism.gov.in/
3b8eeab5-5f13-489f-8185-786a4b7e79b3	4	4	4	4	2025-12-14 16:23:55.15166	https://eservices.himachaltourism.gov.in/
9dd8adf2-1922-4b29-b74d-e34671ef7138	4	4	4	4	2025-12-14 16:55:32.186422	https://eservices.himachaltourism.gov.in/
a664ea78-357f-40fb-94e6-4109d17757e6	4	4	4	4	2025-12-14 16:56:30.343075	https://eservices.himachaltourism.gov.in/
fb26a0ab-5d83-4f31-88fe-587499008c7d	4	4	4	4	2025-12-14 17:03:13.049794	https://eservices.himachaltourism.gov.in/
062b09e3-c59b-4e21-98e2-47943ff5ddc2	4	4	4	4	2025-12-14 17:06:33.019441	https://eservices.himachaltourism.gov.in/
0abeaaa1-2266-466a-997b-3ab7eb0f57be	4	4	4	4	2025-12-14 17:56:07.889443	https://eservices.himachaltourism.gov.in/
e130faa8-7699-4017-965e-6383f02570ea	4	4	4	4	2025-12-14 18:06:33.806582	https://eservices.himachaltourism.gov.in/
1c38f8c6-b081-4e08-a0a7-010d8440bcbe	4	4	4	4	2025-12-14 18:07:17.480179	https://eservices.himachaltourism.gov.in/
3867909a-5c07-4d5d-9f11-843faa4235e9	4	4	4	4	2025-12-14 18:10:26.818894	https://eservices.himachaltourism.gov.in/
dcff327a-37f1-4d78-88d0-8cec79d1e5b0	4	4	4	4	2025-12-14 18:17:09.876037	https://eservices.himachaltourism.gov.in/
4ddd9e01-b4c2-4cb2-b5bb-5c964fd9ea19	4	4	4	4	2025-12-14 18:23:01.327374	https://eservices.himachaltourism.gov.in/
c810eb1b-bc56-4c3d-9902-0f7ff2fa59c8	4	4	4	4	2025-12-14 18:39:17.557324	https://eservices.himachaltourism.gov.in/
b7c5fef0-21c1-4b44-b1f8-b32c9803538e	4	4	4	4	2025-12-14 18:51:51.821358	https://eservices.himachaltourism.gov.in/
fa44b5fa-f700-4c7f-9b93-4aa7b98c13c1	4	4	4	4	2025-12-14 19:03:16.850307	https://eservices.himachaltourism.gov.in/
be2248ac-8273-4cc8-8a94-8627af358b80	4	4	4	4	2025-12-14 19:10:07.28543	https://eservices.himachaltourism.gov.in/
2ed4ec68-48af-4639-8d65-dcdb60f809ad	4	4	4	4	2025-12-14 19:18:07.36768	https://eservices.himachaltourism.gov.in/
2ae47e5a-2292-4ba6-89fe-5d57136bbd6f	4	4	4	4	2025-12-14 19:30:28.805352	https://eservices.himachaltourism.gov.in/
4cceeb61-69ab-4a2a-9641-5e729961adf2	4	4	4	4	2025-12-14 19:36:04.848544	https://eservices.himachaltourism.gov.in/
044562f1-1af7-44ac-a9c3-ee3dd864e625	4	4	4	4	2025-12-14 19:58:18.730745	https://eservices.himachaltourism.gov.in/
dce45b27-8337-4420-bad5-e4e7bfe95da0	4	4	4	4	2025-12-14 20:01:23.506146	https://eservices.himachaltourism.gov.in/
ba8ffc0e-b261-40c6-a367-0a58ab07e32d	4	4	4	4	2025-12-14 20:05:32.530771	https://eservices.himachaltourism.gov.in/
e07c43bc-67ac-41ea-b298-ca5ac6d3274c	4	4	4	4	2025-12-14 21:05:32.564448	https://eservices.himachaltourism.gov.in/
366bb173-3496-48c1-b66f-db62e072e1fc	4	4	4	4	2025-12-14 22:05:32.573233	https://eservices.himachaltourism.gov.in/
cd931e5e-dd44-4afc-9ef8-e4aea3dd74a0	4	4	4	4	2025-12-14 23:05:32.580387	https://eservices.himachaltourism.gov.in/
c87b85e8-cd5b-4b86-9972-f885441fa312	4	4	4	4	2025-12-15 00:05:32.631345	https://eservices.himachaltourism.gov.in/
11318c65-e252-44c6-96d9-58744fab0579	4	4	4	4	2025-12-15 01:05:32.578219	https://eservices.himachaltourism.gov.in/
ae98b3be-1b21-4ae3-b803-0f07adc43e0a	4	4	4	4	2025-12-15 02:05:32.584101	https://eservices.himachaltourism.gov.in/
ed3d4562-5a36-4417-bf4e-2c78f8c16ef1	4	4	4	4	2025-12-15 03:05:32.58305	https://eservices.himachaltourism.gov.in/
7935431e-516b-4caf-ae71-f03c8ad9e54a	4	4	4	4	2025-12-15 04:05:32.598209	https://eservices.himachaltourism.gov.in/
bd2950d6-4da7-40a3-8ff4-86f50e6e5758	4	4	4	4	2025-12-15 05:05:32.587951	https://eservices.himachaltourism.gov.in/
ea56918c-d4ba-4b86-ad65-69ce0cfb9c14	4	4	4	4	2025-12-15 06:05:32.582327	https://eservices.himachaltourism.gov.in/
50df79ea-970f-4a93-87a0-131f4e49775d	4	4	4	4	2025-12-15 07:05:32.577757	https://eservices.himachaltourism.gov.in/
6f915674-cb03-43e3-a146-16f5f139418f	4	4	4	4	2025-12-15 08:05:32.62855	https://eservices.himachaltourism.gov.in/
22f418fd-d41c-4f3d-ac1a-75b62f12433d	4	4	4	4	2025-12-15 09:05:32.554043	https://eservices.himachaltourism.gov.in/
c6e9dac6-a4de-4bb7-9235-9a9fbd8fc874	4	4	4	4	2025-12-15 10:05:32.608848	https://eservices.himachaltourism.gov.in/
4d098b51-5168-4448-9401-1d3a301817d2	4	4	4	4	2025-12-15 11:05:32.629919	https://eservices.himachaltourism.gov.in/
a3aecdf0-3a67-49f5-991f-cbd74dacbc3f	4	4	4	4	2025-12-15 12:05:32.596463	https://eservices.himachaltourism.gov.in/
c267d10d-2330-4b08-96a9-c52b9ec5e48a	4	4	4	4	2025-12-15 13:05:32.656078	https://eservices.himachaltourism.gov.in/
b1a06e46-d377-4f3e-9e78-fb54bfca92a9	4	4	4	4	2025-12-15 14:05:32.610863	https://eservices.himachaltourism.gov.in/
2125f633-dd60-4d20-bfb6-ce84f4ff2376	4	4	4	4	2025-12-15 15:05:32.600567	https://eservices.himachaltourism.gov.in/
32b32d8c-c2ba-4b50-9631-7ba0338925ed	4	4	4	4	2025-12-15 16:05:32.568885	https://eservices.himachaltourism.gov.in/
39376260-6fb0-460d-9bfe-357ab178ff0b	4	4	4	4	2025-12-15 17:05:32.61185	https://eservices.himachaltourism.gov.in/
f3830b15-e9d4-43d9-89cb-f3f50e0bb8cf	4	4	4	4	2025-12-15 18:05:32.607145	https://eservices.himachaltourism.gov.in/
755db46d-7974-46ec-aa16-7534487be48f	4	4	4	4	2025-12-15 19:05:32.593349	https://eservices.himachaltourism.gov.in/
5dc933ce-7219-41ff-966e-5b0b8fadb737	4	4	4	4	2025-12-15 20:05:32.609729	https://eservices.himachaltourism.gov.in/
4f47bd37-af6e-471b-a711-080d34cd3d3d	4	4	4	4	2025-12-15 21:05:32.65432	https://eservices.himachaltourism.gov.in/
4fcd1acc-6a38-4806-9a50-2394bb258c93	4	4	4	4	2025-12-15 22:05:32.60708	https://eservices.himachaltourism.gov.in/
8ff0cda5-6b2b-4ee7-8f1d-87ee4f9848e1	4	4	4	4	2025-12-15 23:05:32.628408	https://eservices.himachaltourism.gov.in/
b02a9d2c-396c-45f7-a6b7-16cbd857c85a	4	4	4	4	2025-12-16 00:05:32.683291	https://eservices.himachaltourism.gov.in/
7d151849-2f59-4d14-b2b2-f2f13534518a	4	4	4	4	2025-12-16 01:05:32.624499	https://eservices.himachaltourism.gov.in/
ba850e73-b0e8-427c-9db5-da1f87801f2b	4	4	4	4	2025-12-16 02:05:32.67701	https://eservices.himachaltourism.gov.in/
d2c38bb9-0749-4cbb-80c0-14ebc01995db	4	4	4	4	2025-12-16 03:05:32.658636	https://eservices.himachaltourism.gov.in/
31dd46bc-8294-42ae-a74b-211b32a6349c	4	4	4	4	2025-12-16 04:05:32.636733	https://eservices.himachaltourism.gov.in/
93219bad-4409-408f-adb6-2a580e3c27c5	4	4	4	4	2025-12-16 05:05:32.650879	https://eservices.himachaltourism.gov.in/
640b45ca-e4e8-40f5-889b-0ae2988b1fcb	4	4	4	4	2025-12-16 06:05:32.648016	https://eservices.himachaltourism.gov.in/
2f020da4-efa6-4ddf-8e99-bb41a812766a	4	4	4	4	2025-12-16 07:05:32.646868	https://eservices.himachaltourism.gov.in/
863615d9-fb62-48f8-b1b2-6629aa04000a	4	4	4	4	2025-12-16 08:05:32.636145	https://eservices.himachaltourism.gov.in/
b27e8ca3-33c0-497c-a42d-cae54825d8ad	4	4	4	4	2025-12-16 09:05:32.651002	https://eservices.himachaltourism.gov.in/
18c4297d-afd0-41d7-87eb-5f0e644cc187	4	4	4	4	2025-12-16 10:05:32.651969	https://eservices.himachaltourism.gov.in/
8d8979bf-94c0-45f2-b32d-ef5da5611419	4	4	4	4	2025-12-16 11:05:32.690977	https://eservices.himachaltourism.gov.in/
d4687f49-cf00-4eff-817c-12b3040f1d4c	4	4	4	4	2025-12-16 12:05:32.687704	https://eservices.himachaltourism.gov.in/
ef2ccf28-c3b7-46f1-9a19-cf84dd5d8afc	4	4	4	4	2025-12-16 13:05:32.656964	https://eservices.himachaltourism.gov.in/
c83a86c6-5a6d-4439-9ad4-25dfe567b801	4	4	4	4	2025-12-16 14:05:32.635977	https://eservices.himachaltourism.gov.in/
a20cc66b-77ec-40b6-b0a2-64b6e4d09149	4	4	4	4	2025-12-16 15:05:32.649054	https://eservices.himachaltourism.gov.in/
6fdca649-d5e7-46f7-a605-037f63b72393	4	4	4	4	2025-12-16 16:05:32.678059	https://eservices.himachaltourism.gov.in/
80423d2f-001c-407f-b86b-dc1868dea381	4	4	4	4	2025-12-16 17:05:32.655003	https://eservices.himachaltourism.gov.in/
87594267-ed08-4e95-8e65-189357f0de27	4	4	4	4	2025-12-16 18:05:33.708696	https://eservices.himachaltourism.gov.in/
01dcfebe-65d8-444c-b9ac-38cd6b7668e1	4	4	4	4	2025-12-16 19:05:32.668075	https://eservices.himachaltourism.gov.in/
44076e48-0c1b-4f8d-9d47-3f6de4c6c567	4	4	4	4	2025-12-16 20:05:32.704579	https://eservices.himachaltourism.gov.in/
f36d2781-74e4-4352-b61f-8b5b7a7704dc	4	4	4	4	2025-12-16 21:05:32.643995	https://eservices.himachaltourism.gov.in/
f38d9439-9000-4eec-bdcc-1f4dc1a0f93d	4	4	4	4	2025-12-16 22:05:32.6586	https://eservices.himachaltourism.gov.in/
d793739d-d6fa-4da9-b815-97e9250130da	4	4	4	4	2025-12-16 23:05:32.682449	https://eservices.himachaltourism.gov.in/
ba572db5-c26a-4d9c-921c-d290268ac493	4	4	4	4	2025-12-17 00:05:32.669496	https://eservices.himachaltourism.gov.in/
76532c3b-855d-451b-9ad5-b59fd6c27fa7	4	4	4	4	2025-12-17 01:05:32.644097	https://eservices.himachaltourism.gov.in/
66f054be-52ff-44e3-9fcc-bfbffa6646f6	4	4	4	4	2025-12-17 02:05:32.688859	https://eservices.himachaltourism.gov.in/
849fe029-adeb-4ea5-81a6-d8a7ea113631	4	4	4	4	2025-12-17 03:05:32.633809	https://eservices.himachaltourism.gov.in/
85e96db3-1381-4ebc-8e8b-45837a10fd34	4	4	4	4	2025-12-17 03:55:45.487231	https://eservices.himachaltourism.gov.in/
2daf1b21-b11d-4add-9377-a71c268fc52c	4	4	4	4	2025-12-17 04:01:26.513083	https://eservices.himachaltourism.gov.in/
5ed53ba7-a050-4506-8128-7c8d20ef669a	4	4	4	4	2025-12-17 04:49:18.580191	https://eservices.himachaltourism.gov.in/
d80dc450-7dec-4125-9ddc-137ee6f975e1	4	4	4	4	2025-12-17 05:01:26.494528	https://eservices.himachaltourism.gov.in/
0fc2cb4c-bb77-42d1-a8ac-d8f5c15fcc0f	4	4	4	4	2025-12-17 05:49:18.3327	https://eservices.himachaltourism.gov.in/
fa8f744c-18f0-4b66-8bf5-857531eeb65a	4	4	4	4	2025-12-17 06:01:53.825395	https://eservices.himachaltourism.gov.in/
5198e269-7e25-4117-8a4f-4462f5b4b6fd	4	4	4	4	2025-12-17 06:35:01.48112	https://eservices.himachaltourism.gov.in/
d0951551-33a3-4f18-b51f-fe015e3d1840	4	4	4	4	2025-12-17 06:39:18.059367	https://eservices.himachaltourism.gov.in/
0f4f1385-9f28-4ac3-bdfe-8f07655b46a9	4	4	4	4	2025-12-17 07:01:26.502956	https://eservices.himachaltourism.gov.in/
16c44cc6-5a92-42ca-b76b-6eff2dd8d5be	4	4	4	4	2025-12-17 07:30:55.8635	https://eservices.himachaltourism.gov.in/
8cd1a860-5310-4dff-9718-f864a98a8b87	4	4	4	4	2025-12-17 08:00:01.103003	https://eservices.himachaltourism.gov.in/
067007ba-d1fa-4d44-b4bf-bc48734a9285	4	4	4	4	2025-12-17 08:01:26.541816	https://eservices.himachaltourism.gov.in/
7bc5f7bb-6506-4980-9093-b24cca7765d7	4	4	4	4	2025-12-17 08:26:50.098065	https://eservices.himachaltourism.gov.in/
317eb282-5dbd-4040-b0ab-1915b2ee9e60	4	4	4	4	2025-12-17 09:00:17.514506	https://eservices.himachaltourism.gov.in/
d46ec525-9fbb-49c7-b3fc-fb6dd2c6fa2a	4	4	4	4	2025-12-17 09:26:49.973206	https://eservices.himachaltourism.gov.in/
bc2dab49-83c7-46f6-bdb9-6f9f5f5aa4e6	4	4	4	4	2025-12-17 09:28:47.973049	https://eservices.himachaltourism.gov.in/
3324a7da-f66c-4e49-a46e-d8c54497c6fd	4	4	4	4	2025-12-17 10:12:58.558827	https://eservices.himachaltourism.gov.in/
05e03596-dc41-4415-bbb6-0a3c0620d866	4	4	4	4	2025-12-17 10:15:44.332764	https://eservices.himachaltourism.gov.in/
a9cd6bcf-d658-42f6-bfac-72869b558c22	4	4	4	4	2025-12-17 15:11:13.448483	https://eservices.himachaltourism.gov.in/
b80c76bc-04d2-4013-b380-24807773bf98	4	4	4	4	2025-12-17 15:11:54.708456	https://eservices.himachaltourism.gov.in/
d6235b37-31fe-41d8-b9f9-822971edb526	4	4	4	4	2025-12-17 15:16:22.114515	https://eservices.himachaltourism.gov.in/
ed6e37c5-a2f8-424f-9705-db3b4c8b73d8	4	4	4	4	2025-12-17 15:17:30.294893	https://eservices.himachaltourism.gov.in/
f2eaa348-9d55-4425-8318-166ecc1ae454	4	4	4	4	2025-12-17 15:17:39.0564	https://eservices.himachaltourism.gov.in/
d7590693-2b84-4ba8-9ff7-be091c4879ac	4	4	4	4	2025-12-17 15:17:48.302803	https://eservices.himachaltourism.gov.in/
f9dd0c2d-a6bd-4be1-8988-0cc77b7219de	4	4	4	4	2025-12-17 15:19:01.939976	https://eservices.himachaltourism.gov.in/
a5f23744-0416-406c-865f-0d4d96c27dd8	4	4	4	4	2025-12-17 15:25:50.486349	https://eservices.himachaltourism.gov.in/
42a62949-8f5e-4960-8e0d-d03216eeb821	4	4	4	4	2025-12-17 15:27:46.964885	https://eservices.himachaltourism.gov.in/
c6636155-0237-48b6-90a2-5d3949dd2f7e	4	4	4	4	2025-12-17 15:32:51.533405	https://eservices.himachaltourism.gov.in/
455ee62b-54dc-4a1e-b6af-440d0fcccaa3	4	4	4	4	2025-12-17 15:58:13.685099	https://eservices.himachaltourism.gov.in/
4e54c562-40ee-471b-a1df-7c0fcfa68eb8	4	4	4	4	2025-12-17 16:00:45.082573	https://eservices.himachaltourism.gov.in/
0b1796f9-6d06-4b93-9ba0-1deebe23e556	4	4	4	4	2025-12-17 16:04:29.048036	https://eservices.himachaltourism.gov.in/
c34aab3d-e03e-461b-b469-71bf9d2d9bf3	4	4	4	4	2025-12-17 16:18:00.228293	https://eservices.himachaltourism.gov.in/
97388d05-8818-4dc2-aa65-cd36db7daa54	4	4	4	4	2025-12-17 16:18:50.084293	https://eservices.himachaltourism.gov.in/
9a15a50f-19bb-4c3f-96b8-ec72a4ecef49	4	4	4	4	2025-12-17 16:19:01.655308	https://eservices.himachaltourism.gov.in/
f1385332-bd76-4be4-946c-588cc8d04301	4	4	4	4	2025-12-17 16:21:04.442292	https://eservices.himachaltourism.gov.in/
d990bf5a-06af-45fc-a166-f477fac20d6b	4	4	4	4	2025-12-17 16:24:48.92127	https://eservices.himachaltourism.gov.in/
d82e3520-7242-4e38-8da5-6b936e1422d9	4	4	4	4	2025-12-17 16:34:50.32123	https://eservices.himachaltourism.gov.in/
55e5bb98-17cc-40a4-89b6-998ef2426fe0	4	4	4	4	2025-12-17 16:38:07.351656	https://eservices.himachaltourism.gov.in/
c7cde134-0f96-4851-9380-809fafb4915b	4	4	4	4	2025-12-17 16:40:55.927464	https://eservices.himachaltourism.gov.in/
6e3521d8-246b-4477-b3e8-21a67440d0be	4	4	4	4	2025-12-17 16:41:13.553974	https://eservices.himachaltourism.gov.in/
b7ecca03-af27-44bf-9567-12895adaccb1	4	4	4	4	2025-12-17 16:41:22.230228	https://eservices.himachaltourism.gov.in/
43f69506-9f89-4d8a-aa80-730321558554	4	4	4	4	2025-12-17 16:41:31.416895	https://eservices.himachaltourism.gov.in/
90f2f2c9-a0c0-4bd1-8b90-ad471a512060	4	4	4	4	2025-12-17 16:41:40.824901	https://eservices.himachaltourism.gov.in/
a0080b03-bd16-4cec-ae74-04731da7e9d6	4	4	4	4	2025-12-17 16:41:48.221024	https://eservices.himachaltourism.gov.in/
f749e787-e86a-4255-9d9b-9557e0c7289a	4	4	4	4	2025-12-17 16:43:32.759295	https://eservices.himachaltourism.gov.in/
c45d1b73-049e-4542-9e62-0b0e5cb21112	4	4	4	4	2025-12-17 16:47:23.286992	https://eservices.himachaltourism.gov.in/
a8afa90a-cacb-4a75-b2db-cc17afa00d17	4	4	4	4	2025-12-17 16:48:52.689902	https://eservices.himachaltourism.gov.in/
156284ef-b003-4b3c-8603-34a4e4d57705	4	4	4	4	2025-12-17 17:21:32.40501	https://eservices.himachaltourism.gov.in/
a712848f-fe4a-432a-91aa-00d9e61caad6	4	4	4	4	2025-12-17 17:21:54.992531	https://eservices.himachaltourism.gov.in/
fcf0ba53-41d6-4df0-b20a-b350a4feaca7	4	4	4	4	2025-12-17 17:22:05.518006	https://eservices.himachaltourism.gov.in/
27294da5-ef55-4f11-810c-4616abccd118	4	4	4	4	2025-12-17 17:22:17.087295	https://eservices.himachaltourism.gov.in/
d7df5027-a153-4031-8278-3ccea8153a87	4	4	4	4	2025-12-17 17:22:25.550964	https://eservices.himachaltourism.gov.in/
a09ec557-e918-4856-b76c-6129691724a5	4	4	4	4	2025-12-17 17:22:33.981311	https://eservices.himachaltourism.gov.in/
f27c44d0-949b-41e7-a8dd-4f46f2579267	4	4	4	4	2025-12-17 17:22:53.636363	https://eservices.himachaltourism.gov.in/
50edaf5b-52d9-41e8-9a95-d8edd6251458	4	4	4	4	2025-12-17 17:23:13.698127	https://eservices.himachaltourism.gov.in/
18652c68-39b7-465e-82fc-c6b83555d0e3	4	4	4	4	2025-12-17 17:23:51.198738	https://eservices.himachaltourism.gov.in/
43cf0631-57bc-46ec-8216-e2e81ad7deee	4	4	4	4	2025-12-17 17:23:57.897964	https://eservices.himachaltourism.gov.in/
7b88613c-d702-4e8c-8051-d081238f7938	4	4	4	4	2025-12-17 17:24:10.271334	https://eservices.himachaltourism.gov.in/
30a93260-ec34-4bdc-826b-eb805172bc98	4	4	4	4	2025-12-17 17:24:17.940634	https://eservices.himachaltourism.gov.in/
1072a0d4-ce14-4dd8-9a1b-b46d644fd460	4	4	4	4	2025-12-17 17:24:25.058911	https://eservices.himachaltourism.gov.in/
edf9914b-48a3-490c-a6ab-89e8b07ca644	4	4	4	4	2025-12-17 17:24:34.727502	https://eservices.himachaltourism.gov.in/
14add0fc-0f60-4501-a7a6-7ef4abf5c665	4	4	4	4	2025-12-17 17:24:43.046053	https://eservices.himachaltourism.gov.in/
08c52a07-921c-4f3f-b746-b40794011882	4	4	4	4	2025-12-17 17:24:50.805817	https://eservices.himachaltourism.gov.in/
edf45c12-3a5c-477d-b909-f989fe13e65a	4	4	4	4	2025-12-17 17:24:58.362675	https://eservices.himachaltourism.gov.in/
c689384e-7584-423b-a83c-603fa0c39d30	4	4	4	4	2025-12-17 17:25:15.212691	https://eservices.himachaltourism.gov.in/
f9307f72-d052-4426-acb3-44776baac45e	4	4	4	4	2025-12-17 17:36:31.712913	https://eservices.himachaltourism.gov.in/
a56e9af5-b797-4944-883a-01e4e37cf3e9	4	4	4	4	2025-12-17 17:41:55.460034	https://eservices.himachaltourism.gov.in/
f51f674d-2441-4f84-aabb-0f85053a1e9f	4	4	4	4	2025-12-17 18:04:50.304933	https://eservices.himachaltourism.gov.in/
68b85e97-62a3-494a-870d-0cfe04bf75b7	4	4	4	4	2025-12-17 18:06:20.710337	https://eservices.himachaltourism.gov.in/
4f1513a7-81e5-466a-8d5f-7017b55f6147	4	4	4	4	2025-12-17 18:07:17.983295	https://eservices.himachaltourism.gov.in/
dbe9fdbc-aa14-48ee-9623-4ac9b0f31ad7	4	4	4	4	2025-12-17 18:07:41.87008	https://eservices.himachaltourism.gov.in/
e16a30e9-e2f7-4b57-940b-20228e122cee	4	4	4	4	2025-12-17 18:10:25.986332	https://eservices.himachaltourism.gov.in/
adab64cf-e381-4602-b57e-03b6311e79a4	4	4	4	4	2025-12-17 18:42:32.23753	https://eservices.himachaltourism.gov.in/
c918c853-36cf-4701-b5f4-1467e7a6b5e3	4	4	4	4	2025-12-17 19:42:31.830149	https://eservices.himachaltourism.gov.in/
2084a413-6bd5-449c-a2a0-b3695e7947f2	4	4	4	4	2025-12-17 20:42:31.816523	https://eservices.himachaltourism.gov.in/
0ec64238-852d-4216-bb83-d821b5df1efa	4	4	4	4	2025-12-17 21:42:31.831783	https://eservices.himachaltourism.gov.in/
1ac99251-1790-40ba-b7ca-50a613da948d	4	4	4	4	2025-12-17 22:42:31.824579	https://eservices.himachaltourism.gov.in/
838c6c8d-c9d5-4e2c-9e8d-f739d5bc0c89	4	4	4	4	2025-12-17 23:42:31.91507	https://eservices.himachaltourism.gov.in/
f648e7c3-fb7e-477f-87fe-c000f2dc54eb	4	4	4	4	2025-12-18 00:42:31.905171	https://eservices.himachaltourism.gov.in/
95afb10e-e6ad-49dd-a541-5ea70c390a09	4	4	4	4	2025-12-18 01:42:31.825967	https://eservices.himachaltourism.gov.in/
4b23c446-1a66-44a0-8585-dcd18d8476e8	4	4	4	4	2025-12-18 02:42:31.889639	https://eservices.himachaltourism.gov.in/
831be63e-6ce1-4b90-b547-ebe69d13fc34	4	4	4	4	2025-12-18 03:03:49.576387	https://eservices.himachaltourism.gov.in/
ab76c89f-df31-4be3-bb38-ea0885605234	4	4	4	4	2025-12-18 03:03:54.08229	https://eservices.himachaltourism.gov.in/
00d69f98-128f-4208-ae4b-a92e274fed34	4	4	4	4	2025-12-18 04:03:53.755994	https://eservices.himachaltourism.gov.in/
ca3a69a1-c72c-4b0b-804f-c357dfd5bb75	4	4	4	4	2025-12-18 05:03:53.754034	https://eservices.himachaltourism.gov.in/
26b15e0f-792a-42f6-a435-d74d15553003	4	4	4	4	2025-12-18 06:03:53.744146	https://eservices.himachaltourism.gov.in/
67cb6d51-3cd1-4250-85d6-cc17a3d42e37	4	4	4	4	2025-12-18 07:03:53.713406	https://eservices.himachaltourism.gov.in/
836ad47d-c75f-4763-a22c-f5cf65245d49	4	4	4	4	2025-12-18 08:03:53.758064	https://eservices.himachaltourism.gov.in/
b0f35699-060d-4155-9f18-31b184c0a973	4	4	4	4	2025-12-18 09:03:53.776566	https://eservices.himachaltourism.gov.in/
cdb871d5-c51f-487d-a0c7-656916c079cb	4	4	4	4	2025-12-18 10:04:00.476177	https://eservices.himachaltourism.gov.in/
f5c08e32-89c1-4fe5-8ea2-353fddf74141	4	4	4	4	2025-12-18 11:03:53.819334	https://eservices.himachaltourism.gov.in/
570139df-d37f-481e-bf78-24fde393ed3c	4	4	4	4	2025-12-18 12:03:53.757203	https://eservices.himachaltourism.gov.in/
91694113-df91-4648-8bbd-04f7b860d3b5	4	4	4	4	2025-12-18 13:03:53.770786	https://eservices.himachaltourism.gov.in/
1916f290-fbdc-402e-9753-bc65ee7aa248	4	4	4	4	2025-12-18 14:03:53.774286	https://eservices.himachaltourism.gov.in/
9bdd2faf-d04f-492c-9cb5-6584094bf5e9	4	4	4	4	2025-12-18 15:03:53.771202	https://eservices.himachaltourism.gov.in/
a0097b12-cc38-459f-a567-fe91b3efdefa	4	4	4	4	2025-12-18 16:03:53.786441	https://eservices.himachaltourism.gov.in/
80de7519-60e3-470a-b741-bdafc9e6da43	4	4	4	4	2025-12-18 17:03:53.811015	https://eservices.himachaltourism.gov.in/
bdd4b1cd-ce2c-40f5-96b2-75af2f0f8363	4	4	4	4	2025-12-18 18:03:53.853128	https://eservices.himachaltourism.gov.in/
5e205949-12d3-4593-be3e-f4c3280180f6	4	4	4	4	2025-12-18 19:03:53.826631	https://eservices.himachaltourism.gov.in/
fa3c69e3-5586-43f1-a843-35cbe1b5c470	4	4	4	4	2025-12-18 20:03:53.857607	https://eservices.himachaltourism.gov.in/
68fd2fbc-a2e3-4ea6-802b-3e5eb83695f2	4	4	4	4	2025-12-18 21:03:53.821416	https://eservices.himachaltourism.gov.in/
efafec30-e727-4537-9a89-a002310952c7	4	4	4	4	2025-12-18 22:03:53.805588	https://eservices.himachaltourism.gov.in/
816b7543-7cef-4361-9948-0f53505c3e46	4	4	4	4	2025-12-18 23:03:53.83985	https://eservices.himachaltourism.gov.in/
1019e2f1-6d98-4d67-9322-184e985ac8fd	4	4	4	4	2025-12-19 00:03:53.824678	https://eservices.himachaltourism.gov.in/
f9584e96-7d73-4b91-a3d6-5ad97b42a85e	4	4	4	4	2025-12-19 01:03:53.8284	https://eservices.himachaltourism.gov.in/
66b9d496-e649-4d2e-bde1-d83a1efc8796	4	4	4	4	2025-12-19 02:03:53.786713	https://eservices.himachaltourism.gov.in/
b2e4453b-634f-4d5d-b196-e610ffe4d620	4	4	4	4	2025-12-19 03:03:53.828797	https://eservices.himachaltourism.gov.in/
ef4d21d0-7f9a-4e1d-ba28-f37cac08c8e4	4	4	4	4	2025-12-19 04:03:53.813091	https://eservices.himachaltourism.gov.in/
1c3896ae-153d-4d5e-ba30-9b0daa3cf591	4	4	4	4	2025-12-19 04:53:13.879273	https://eservices.himachaltourism.gov.in/
abdd127a-95ed-4dfd-88cc-20ca665c66b2	4	4	4	4	2025-12-19 05:05:24.432914	https://eservices.himachaltourism.gov.in/
c230a33f-423c-46be-9133-65ff502cb2a3	4	4	4	4	2025-12-19 05:05:33.123407	https://eservices.himachaltourism.gov.in/
b56baa3b-7057-4b58-b625-641cd27e8693	4	4	4	4	2025-12-19 05:05:38.290242	https://eservices.himachaltourism.gov.in/
6977d5ab-c3ca-412d-9aac-021b0bbaea4c	4	4	4	4	2025-12-19 05:24:58.136698	https://eservices.himachaltourism.gov.in/
1c597003-e78c-4efc-a806-4885a9bf067f	4	4	4	4	2025-12-19 05:25:48.691828	https://eservices.himachaltourism.gov.in/
c3f3d707-32d4-40b1-b975-aaaf571e78b2	4	4	4	4	2025-12-19 05:59:10.552544	https://eservices.himachaltourism.gov.in/
baed97c5-34d3-4e05-9547-576c5d01b680	4	4	4	4	2025-12-19 06:59:10.239326	https://eservices.himachaltourism.gov.in/
ac44b191-4090-4d38-b0da-309b019265a2	4	4	4	4	2025-12-19 07:35:38.107566	https://eservices.himachaltourism.gov.in/
a99fdfea-2d1f-40fb-ae54-59310a1f29ee	4	4	4	4	2025-12-19 07:51:44.509949	https://eservices.himachaltourism.gov.in/
56844e3f-32bc-4cfe-97cb-1b3fb945bedb	4	4	4	4	2025-12-19 07:58:42.571912	https://eservices.himachaltourism.gov.in/
b5b437d0-3d80-4180-9f0f-a3ecda274408	4	4	4	4	2025-12-19 07:58:46.986496	https://eservices.himachaltourism.gov.in/
d277b96a-699c-4c03-a4da-efe3202c77d7	4	4	4	4	2025-12-19 07:58:52.303553	https://eservices.himachaltourism.gov.in/
a00152b0-003d-478e-91df-26d38086129d	4	4	4	4	2025-12-19 07:58:58.424564	https://eservices.himachaltourism.gov.in/
57f399c3-9808-454e-847f-b2e58ddd8e27	4	4	4	4	2025-12-19 07:59:03.746738	https://eservices.himachaltourism.gov.in/
815b9c2c-b488-4ca2-ba5e-f3bbdd5b5f2a	4	4	4	4	2025-12-19 07:59:12.316454	https://eservices.himachaltourism.gov.in/
e8be374e-9fd9-47ec-9cf0-7299e3588a42	4	4	4	4	2025-12-19 07:59:25.06267	https://eservices.himachaltourism.gov.in/
e11b91ac-6267-423e-a09d-c0c194e35919	4	4	4	4	2025-12-19 07:59:32.785699	https://eservices.himachaltourism.gov.in/
48bcffe1-3f31-4611-84f8-3f14386a79dc	4	4	4	4	2025-12-19 07:59:50.478716	https://eservices.himachaltourism.gov.in/
f642636f-7bfb-41a9-8331-1a236f29347d	4	4	4	4	2025-12-19 07:59:59.149202	https://eservices.himachaltourism.gov.in/
24c90ceb-7b95-45ee-892f-bb0b8bb23745	4	4	4	4	2025-12-19 08:00:05.803419	https://eservices.himachaltourism.gov.in/
136e88e7-1905-4584-806b-13a426736afb	4	4	4	4	2025-12-19 08:00:12.138171	https://eservices.himachaltourism.gov.in/
6b94a7b6-aefa-4dcb-8240-be0c75d11fd7	4	4	4	4	2025-12-19 08:00:17.46901	https://eservices.himachaltourism.gov.in/
31e9f57c-254c-4884-89b6-e303c3526d5d	4	4	4	4	2025-12-19 08:00:22.125215	https://eservices.himachaltourism.gov.in/
98151f8d-2ae7-404f-bac6-c88132eade39	4	4	4	4	2025-12-19 08:00:26.921653	https://eservices.himachaltourism.gov.in/
311d9e05-3c46-4c23-902b-6201d6312410	4	4	4	4	2025-12-19 08:00:31.294464	https://eservices.himachaltourism.gov.in/
16f5464e-ac52-4077-be44-d404d1d13010	4	4	4	4	2025-12-19 08:00:36.999501	https://eservices.himachaltourism.gov.in/
aeca13a3-d705-4844-8cfe-861e8a484cce	4	4	4	4	2025-12-19 08:00:42.216808	https://eservices.himachaltourism.gov.in/
56dfe34a-5f51-4de4-9865-900a9634a6a3	4	4	4	4	2025-12-19 08:00:49.943589	https://eservices.himachaltourism.gov.in/
d7dacdcd-1455-4ca8-a901-b5f3fd2c68c2	4	4	4	4	2025-12-19 08:01:48.581258	https://eservices.himachaltourism.gov.in/
da246fe1-3baa-4ae4-929d-31bac976983e	4	4	4	4	2025-12-19 08:02:06.493276	https://eservices.himachaltourism.gov.in/
9c4cfef3-ce99-49e3-ae0d-1e2738ba223b	4	4	4	4	2025-12-19 08:02:12.605812	https://eservices.himachaltourism.gov.in/
caff8311-2b11-4c8c-98e8-2c8cfde27efa	4	4	4	4	2025-12-19 08:02:38.742769	https://eservices.himachaltourism.gov.in/
501b2974-9476-4a36-9718-659382ccba7a	4	4	4	4	2025-12-19 08:02:45.161941	https://eservices.himachaltourism.gov.in/
901e37ee-f7d1-4f45-8a63-90f5c57c2b17	4	4	4	4	2025-12-19 08:04:59.933491	https://eservices.himachaltourism.gov.in/
9b436d6f-15e2-4339-b251-18eacae8057d	4	4	4	4	2025-12-19 09:04:59.804122	https://eservices.himachaltourism.gov.in/
efd7e3ab-60c1-4b3f-b5b4-e91c2f7dcc9b	4	4	4	4	2025-12-19 10:04:59.807589	https://eservices.himachaltourism.gov.in/
44f3a70a-2011-4df9-a40c-815bf7db405e	4	4	4	4	2025-12-19 11:04:59.871313	https://eservices.himachaltourism.gov.in/
8b8c3550-93e3-4690-a7a6-d4aad489b8d7	4	4	4	4	2025-12-19 12:04:59.798473	https://eservices.himachaltourism.gov.in/
2f5f7f68-c8a3-4a78-9608-a7c3d7dcb8f8	4	4	4	4	2025-12-19 13:04:59.85967	https://eservices.himachaltourism.gov.in/
745dad20-4854-4bcc-b7fe-5f9d219b49e7	4	4	4	4	2025-12-19 14:04:59.837195	https://eservices.himachaltourism.gov.in/
55399dd2-74a3-4a3c-88b8-eabe996e553a	4	4	4	4	2025-12-19 15:04:59.827834	https://eservices.himachaltourism.gov.in/
f10de33a-69a4-439c-bbe4-da56dd113f30	4	4	4	4	2025-12-19 16:04:59.861712	https://eservices.himachaltourism.gov.in/
0446a572-a85b-49dd-bfdb-5287286c937d	4	4	4	4	2025-12-19 17:04:59.834552	https://eservices.himachaltourism.gov.in/
09bd0f1b-a5bb-4fe3-9810-ae16c3751530	4	4	4	4	2025-12-19 18:04:59.814543	https://eservices.himachaltourism.gov.in/
30897aa2-e50b-40f0-8960-216a7dc3ba64	4	4	4	4	2025-12-19 19:04:59.837141	https://eservices.himachaltourism.gov.in/
b15e58e9-05ae-4119-ae5e-8285e29f6baf	4	4	4	4	2025-12-19 20:04:59.801144	https://eservices.himachaltourism.gov.in/
f9c41ba1-be03-4fa6-9275-ceb46adba7f4	4	4	4	4	2025-12-19 21:04:59.801779	https://eservices.himachaltourism.gov.in/
e4321b1b-f711-4fa9-bcd3-8635f5e680a3	4	4	4	4	2025-12-19 21:27:23.071677	https://eservices.himachaltourism.gov.in/
e9123c57-9621-4191-af23-4cf36bab17b5	4	4	4	4	2025-12-19 21:53:20.15061	https://eservices.himachaltourism.gov.in/
e57c4af0-3310-47c3-ab1a-3934976d14eb	4	4	4	4	2025-12-19 22:36:27.474958	https://eservices.himachaltourism.gov.in/
ec84e5ea-c989-435b-99ad-fd33f7e47d60	4	4	4	4	2025-12-19 22:42:49.246551	https://eservices.himachaltourism.gov.in/
4a3aef4b-133c-497d-bb80-d697b4749358	4	4	4	4	2025-12-19 22:45:07.83831	https://eservices.himachaltourism.gov.in/
b6ae8f2f-1686-4fa0-8d4c-59a4026220a4	4	4	4	4	2025-12-19 23:45:07.730898	https://eservices.himachaltourism.gov.in/
de88975d-e7c2-40ce-9785-13905fa9c8da	4	4	4	4	2025-12-20 00:45:07.750346	https://eservices.himachaltourism.gov.in/
fcbfd338-7c90-495c-8ab2-f5840b6e5451	4	4	4	4	2025-12-20 01:45:07.705541	https://eservices.himachaltourism.gov.in/
9c37b35d-4937-4ea4-b2ca-29d12ad41e6b	4	4	4	4	2025-12-20 02:45:07.650939	https://eservices.himachaltourism.gov.in/
7a7f1f56-8727-4a70-bfdb-328bb9377f0b	4	4	4	4	2025-12-20 03:45:07.654398	https://eservices.himachaltourism.gov.in/
d6348c81-db4f-49a7-9e9b-6446ca5eaa12	4	4	4	4	2025-12-20 03:59:59.235924	https://eservices.himachaltourism.gov.in/
dd21e0f7-f637-4297-ab9b-37a0c0ef71ce	4	4	4	4	2025-12-20 04:06:03.242864	https://eservices.himachaltourism.gov.in/
10d01932-e8b2-45c7-b6e5-b8710a4aca9c	4	4	4	4	2025-12-20 04:33:20.104414	https://eservices.himachaltourism.gov.in/
22fac5e8-ce02-4bf6-b4e4-20f15236977d	4	4	4	4	2025-12-20 04:46:55.286861	https://eservices.himachaltourism.gov.in/
1e5c4a99-82b1-4e49-9e73-29d1758bd204	4	4	4	4	2025-12-20 05:03:55.698986	https://eservices.himachaltourism.gov.in/
828f5285-6339-4a65-bade-d17de76c7253	4	4	4	4	2025-12-20 06:03:55.400998	https://eservices.himachaltourism.gov.in/
97357811-d6db-40df-9a08-73a51ffd3aee	4	4	4	4	2025-12-20 07:03:55.393212	https://eservices.himachaltourism.gov.in/
da266bd4-1485-4552-a635-9631f38d3706	4	4	4	4	2025-12-20 07:45:25.518156	https://eservices.himachaltourism.gov.in/
06de821c-9ddf-49e9-a8d4-1f9462cab0a9	4	4	4	4	2025-12-20 08:45:25.070616	https://eservices.himachaltourism.gov.in/
b280ed1e-c39c-49d0-8608-fb08a699d967	4	4	4	4	2025-12-20 09:45:25.102133	https://eservices.himachaltourism.gov.in/
53500367-d259-4f2c-b78a-6968b98dc7b5	4	4	4	4	2025-12-20 10:45:26.706437	https://eservices.himachaltourism.gov.in/
ecc05dc2-e0d1-4859-9dd6-e0bebe1af202	4	4	4	4	2025-12-20 10:45:32.60211	https://eservices.himachaltourism.gov.in/
df68fa6c-aa99-4797-baa4-9612ce8e7f31	4	4	4	4	2025-12-20 11:45:32.424548	https://eservices.himachaltourism.gov.in/
5d2c35f8-679b-4415-853b-91b3fa824f37	4	4	4	4	2025-12-20 12:45:32.404679	https://eservices.himachaltourism.gov.in/
7e8e38a2-a2f4-48cb-ada6-1d60d67a63c8	4	4	4	4	2025-12-20 13:45:32.458295	https://eservices.himachaltourism.gov.in/
93e3b294-05e2-4bde-ab86-ff89d067a489	4	4	4	4	2025-12-20 14:45:32.383576	https://eservices.himachaltourism.gov.in/
7b20da2e-48a1-4abf-bbfe-791c2aab4812	4	4	4	4	2025-12-20 15:45:32.350733	https://eservices.himachaltourism.gov.in/
d53a9213-3b2f-43f7-8976-e83d31e1cf36	4	4	4	4	2025-12-20 16:45:32.414838	https://eservices.himachaltourism.gov.in/
365c432e-c006-4a27-a8af-3b0f8e2b327a	4	4	4	4	2025-12-20 17:45:32.356558	https://eservices.himachaltourism.gov.in/
079a5dff-fdf3-4d1e-ae42-77794941c2f1	4	4	4	4	2025-12-20 18:45:32.420161	https://eservices.himachaltourism.gov.in/
11944bee-a212-4347-b58c-0f768c4ab24e	4	4	4	4	2025-12-20 19:11:33.386849	https://eservices.himachaltourism.gov.in/
f145e5c0-1afa-4664-9f64-68cb10cf7f10	4	4	4	4	2025-12-20 19:35:21.959715	https://eservices.himachaltourism.gov.in/
e0912b6f-4a1a-492d-a0db-2a4a888233dd	4	4	4	4	2025-12-20 20:20:23.97015	https://eservices.himachaltourism.gov.in/
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reviews (id, application_id, user_id, rating, review_text, is_verified_stay, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.session (sid, sess, expire) FROM stdin;
GS2BpxQXG9dxGc7uuPfD3L8c1XF231fR	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-27T10:20:59.425Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97"}	2025-12-27 10:45:28
_iHXBYc_TDFBtJI-yapRqOQ5FqDh88Gv	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:43:21.073Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:43:22
gzbBenmASPNcb-Sz8QkWQZiHVd_rbEjy	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-27T18:53:18.210Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97"}	2025-12-27 18:59:16
UkW3ShKgNQKTcRqjRB0wlhud42Yeq-Ww	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-27T17:11:41.493Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"3a61a143-319b-4b43-a591-b4e9612a8356"}	2025-12-27 18:22:52
pgp-mShRXGAOEyrTwmlaws9YzEocIKOK	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T21:23:48.112Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 21:23:50
gzZK0Xvi6Fzegv00Rn3BUk5g2SXg67PP	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T21:23:48.178Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 21:23:50
b_YBrrSVxmBWtQPsBKEEJmeUT13kD8vL	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T21:23:48.044Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"f4863c83-6aa5-48ff-bfd8-1f33a787d14f","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 21:23:52
1WBn0FfDY4kRnf1psVgWkWF93gvgm43R	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T21:25:43.673Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"f4863c83-6aa5-48ff-bfd8-1f33a787d14f","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 21:25:44
gtxr0iyK5EmlGRBb8NqD2y76zjGOu2sG	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T21:26:08.164Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"f4863c83-6aa5-48ff-bfd8-1f33a787d14f","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 21:26:09
kOmuAzSB09V357iDe5EIUpxZxEc4pWPC	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T21:26:33.086Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"f4863c83-6aa5-48ff-bfd8-1f33a787d14f","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 21:26:34
KfD0gM_gxGUXqpVKDeKMvxL1f6s7lVGt	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T21:26:49.227Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"f4863c83-6aa5-48ff-bfd8-1f33a787d14f","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 21:26:50
usTHJwJeiNCAhMoXQEMLuRo__k1DlG3R	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T21:26:49.370Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 21:26:50
XgB7kYRvG0qpA4hq8IGunWpVdYvR5EYF	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-27T10:21:47.071Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842"}	2025-12-27 10:44:57
UJTwK40g-PU-SRbeEkyjjuyjmPk1hzCY	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-27T18:55:38.214Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842"}	2025-12-27 18:59:44
Ep9rtfTzdj4O2lpxiZObKskVxNy9f4Vr	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-27T13:23:47.538Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"033bb139-19cf-45a0-a191-01986b65449f"}	2025-12-27 19:00:49
F9C4CwIsv9JHPg-6-zAly0CPkBhQMS8a	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T21:27:25.377Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"f4863c83-6aa5-48ff-bfd8-1f33a787d14f","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 21:27:31
RK05CMD8H6DQ-oWBYTPt1EIM50AL3LPQ	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-27T10:18:50.101Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"2c41a160-de2a-4141-910e-4021bdeac7c4"}	2025-12-27 10:44:57
FKK-BXIhIDhboOOeLggPuoZKox2g4QhK	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-27T18:00:15.148Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"2c41a160-de2a-4141-910e-4021bdeac7c4"}	2025-12-27 20:27:24
oXQ79v6h94iO3GV-Ff5p4pf13c5sFShG	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:43:21.142Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:43:22
c13x0KQXWol37Bxj_IamI0DnBO1jDJ6-	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T07:20:10.005Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"f4863c83-6aa5-48ff-bfd8-1f33a787d14f"}	2025-12-26 08:13:07
MN2E7JaJgKRzsfbjBLvpkW5fpY5ScE7m	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:35:51.427Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:35:52
zjJkPquIMce8s5f5uzBs2JWNA4GX8g_t	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:35:51.494Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:35:52
7qH2v8-PUxBM--2ginGvdIMiOA2ONy57	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:35:51.354Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"f4863c83-6aa5-48ff-bfd8-1f33a787d14f","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:35:52
SdUOcLhIM3C6VFniH-diV9tDz67NQsWd	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-24T04:53:53.214Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"3e2499ee-8bf4-4dd8-9fcc-01a1bc075668"}	2025-12-24 06:03:51
lmZFOD3qZA0zBZhPi07BhefaLhVWXYFk	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T05:32:14.387Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"4dfac021-134f-40d6-878b-d88c12212607"}	2025-12-26 05:40:54
wmYrgM5MR_pM_KBeGB0wx5E97EdykUpv	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-25T07:06:48.710Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null}	2025-12-25 07:07:02
6l5dPeAKcQ2aY2u-RUfR-Xu7V1_OKkZc	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:43:21.000Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"f4863c83-6aa5-48ff-bfd8-1f33a787d14f","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:43:22
VP6vgWY8tW8knUxmJCKY8-Nigbv7vdrs	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T21:27:30.088Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 21:27:31
WIcqzp9Sp8HzOSRL-KI1jE4HE24-zro1	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:43:59.912Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:44:00
_keVV27qPPcEf-zxHhb1SITyd1J6qebs	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:43:59.846Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:44:01
zBkWpmNTz3OmEx45jSwnnV5M15fSUGTo	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:38:21.158Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"f4863c83-6aa5-48ff-bfd8-1f33a787d14f","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:38:22
K5ydJh-C70QP1gWSH31nXOjeM-m7v8qF	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:43:59.775Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"f4863c83-6aa5-48ff-bfd8-1f33a787d14f","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:44:01
gYSog4QKS-Jc6Ak7VfDCesFOQzBMDc9F	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:45:17.137Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:45:18
XrW38Rma3-6UlI7UMl_JGchwVL7TuYRG	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:45:17.204Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:45:18
ygPe-_pyM1a1tC4ZxWOk_RuBl4ngQhy9	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:48:09.324Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"f4863c83-6aa5-48ff-bfd8-1f33a787d14f","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:48:12
p3cbuB8d-9qLXmO5X_F-XIE1uuUic1NZ	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:45:17.065Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"f4863c83-6aa5-48ff-bfd8-1f33a787d14f","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:45:18
Y7MsygQpMMPAx37Ia544svHp5_i0Asxc	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:45:49.686Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:45:50
K5pNovZUQKhOKvjWDAe6O4q7VIAA-XZY	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:45:49.621Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:45:51
vnhFAlj8ZNHszIV77NNqFlVbkMlfxFaL	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:45:49.550Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"f4863c83-6aa5-48ff-bfd8-1f33a787d14f","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:45:51
6f2WMs-DRRMq05m2J6Rzf5h1TomJsFyp	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:46:34.216Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:46:35
eT0GgV2OITbK2FUrlawnKNsgnjOvVU6D	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:46:34.281Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:46:35
O99MpdsylVaNadaOdrIYtCUtUBI2egN2	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:46:34.144Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"f4863c83-6aa5-48ff-bfd8-1f33a787d14f","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:46:35
7599eqSLLAEiRTT25_ouo8vAvTzJ-Ghk	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:48:09.397Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:48:11
ZQJzdzHZQ2k5KKasDc27lAWKy0EveL9g	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:36:19.077Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:36:20
sWgIgIiJP42OFE8ZH4YwMFS8b0ee-n6R	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:36:19.011Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:36:20
UtyhOAbBOcAgwN_Ed1NaylVQRfou678p	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:36:18.938Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"f4863c83-6aa5-48ff-bfd8-1f33a787d14f","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:36:20
m6KGHheM47I7lEADTAqZhb7RLJHbS5Zy	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:38:21.230Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:38:22
oIfCe1KwoefqVGCCyMrcSM2ZqqnGR0wh	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:38:21.297Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:38:22
Q4zmttrnCMITOyB2HlYL6gwKXqc986Wx	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:48:09.463Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:48:12
M1O8zd1g_MU40jiJgSxJLNkznAOHBule	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:49:07.570Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:49:09
_qiYQ1Rm8OdvWByv_wkoEDU2yFSuAp72	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:49:07.635Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:49:10
bLagr8nY3LbBNRnxtCDiyQ57V9TxpwNx	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T20:49:07.498Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":"f4863c83-6aa5-48ff-bfd8-1f33a787d14f","captchaAnswer":null,"captchaIssuedAt":null}	2025-12-26 20:49:11
IgeXdYH3va3uOCLN-Bd_feoLxyOaO3Bx	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-26T19:58:13.442Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"f4863c83-6aa5-48ff-bfd8-1f33a787d14f"}	2025-12-26 20:54:35
\.


--
-- Data for Name: storage_objects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.storage_objects (id, object_key, storage_provider, file_type, category, mime_type, size_bytes, checksum_sha256, uploaded_by, application_id, document_id, created_at, last_accessed_at) FROM stdin;
93533f5d-4d4a-4fb7-8d52-f4630faf5543	revenue-paperss/996697b3-7964-4399-a70e-8c56eeebc94f	local	revenue-papers	revenue_papers	application/pdf	61398	\N	\N	9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	dd4c5072-4e67-4583-aef2-84dec22fdcfa	2025-12-20 10:08:56.728436	\N
916825d2-bebd-437b-b09d-823c1c8388d8	affidavit-section29s/493f71d0-b40a-4520-986e-75955b7be301	local	affidavit-section29	affidavit_section_29	application/pdf	61398	\N	\N	9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	ce8363f1-962e-4784-8b49-12a3b3764398	2025-12-20 10:09:02.191081	\N
69c4a402-ce94-487f-9163-c7b69912e429	undertaking-form-cs/88f7cc2b-bdc1-420f-b703-e7449c648c94	local	undertaking-form-c	undertaking_form_c	application/pdf	61398	\N	\N	9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	e80395ed-a521-4caf-ba82-c2a613da96a6	2025-12-20 10:09:07.1705	\N
d9856d4c-047d-4440-bb1b-b173d96bb786	property-photos/71908a6f-b712-48a8-94c3-bea4759bb856	local	property-photo	property_photo	image/jpeg	96524	\N	\N	9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	91d46c90-3bf1-40c5-99f4-c42a79ebc160	2025-12-20 10:09:14.395608	\N
ba26c4b0-d027-4d80-9611-6aa605a5678b	property-photos/dcb8ba3b-7b99-42ab-800a-f1b75244d56a	local	property-photo	property_photo	image/jpeg	13584	\N	\N	9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	64777f3b-9e22-48cb-8efd-664392553389	2025-12-20 10:09:14.52399	\N
ecd97507-20d5-4c72-90d6-be93280eb28a	property-photos/cbcaef9e-39f1-4594-9c05-38aa2c47e725	local	property-photo	property_photo	image/jpeg	98782	\N	\N	9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	ce22db37-110f-453e-8723-edaa85bd7ec7	2025-12-20 10:09:14.814648	\N
02102b25-56c8-45c4-9d27-e8def3722a87	property-photos/f3b6895c-af36-4ed6-b5a8-7237ef6cfcee	local	property-photo	property_photo	image/jpeg	96524	\N	\N	9b558a08-8c3d-46ab-a240-2f4c7d6f48b3	ffb96859-ac7e-427c-9094-54ee397a763b	2025-12-20 10:22:22.777054	\N
f2a0dd20-d45c-44a3-a875-31fa9c775606	revenue-paperss/dfacd531-dad0-4ebf-8a92-98a716077302	local	revenue-papers	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	587e43ed-d70b-4184-aac9-0aa54c657bfb	\N	\N	2025-12-20 11:31:03.245767	\N
90c8de09-6bb6-460a-a09b-4be84e5a34de	affidavit-section29s/b2fabce1-86c9-4dd8-993a-0e01000370a7	local	affidavit-section29	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	587e43ed-d70b-4184-aac9-0aa54c657bfb	\N	\N	2025-12-20 11:31:06.678595	\N
6652cdb4-7388-4c2e-914c-863d1aaa187f	undertaking-form-cs/81a96eec-e3c5-41ce-9768-31f1df11de1b	local	undertaking-form-c	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	587e43ed-d70b-4184-aac9-0aa54c657bfb	\N	\N	2025-12-20 11:31:11.108149	\N
e083241d-d0c6-45c9-8b3e-b54d398da823	property-photos/88c04f3c-6337-4aea-8b27-b59e6dd47bae	local	property-photo	photos	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	587e43ed-d70b-4184-aac9-0aa54c657bfb	\N	\N	2025-12-20 11:31:14.110677	\N
16cba7de-d72e-4298-939a-a7abf21a5935	additional-documents/b497afa7-6634-4155-bf75-8fc19fbf21b4	local	additional-document	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	587e43ed-d70b-4184-aac9-0aa54c657bfb	\N	\N	2025-12-20 11:31:25.252483	\N
bf81c8d9-31fc-4e71-b0af-ce27a57b23ca	property-photos/4e7732a1-5abb-46d2-8eb5-faed3e1e7484	local	property-photo	photos	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	587e43ed-d70b-4184-aac9-0aa54c657bfb	\N	\N	2025-12-20 11:31:34.980916	\N
cc1665f3-cf14-4231-a756-32bdcaffdae6	revenue-paperss/2c61cdfa-6edf-432e-8a71-e4fe24ec5d73	local	revenue-papers	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	6ee216be-e615-4730-96ec-776f7a244776	\N	\N	2025-12-20 11:41:24.550653	\N
acd95000-9f0c-4882-81a6-c025098529a0	affidavit-section29s/49ddf5ee-7c6e-47da-9110-73132b1f2816	local	affidavit-section29	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	6ee216be-e615-4730-96ec-776f7a244776	\N	\N	2025-12-20 11:41:28.110888	\N
0d437e4d-bcfe-4f25-991a-f8630f84f39b	undertaking-form-cs/21da7f3c-ed3f-4bad-80ea-b6135342ad87	local	undertaking-form-c	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	6ee216be-e615-4730-96ec-776f7a244776	\N	\N	2025-12-20 11:41:31.390133	\N
b587ac20-872f-4329-b724-f73f1052cc56	property-photos/fd5a6f9b-649a-47ba-b5d8-14567a2e4409	local	property-photo	photos	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	6ee216be-e615-4730-96ec-776f7a244776	\N	\N	2025-12-20 11:41:35.375913	\N
c63d132d-5df5-4886-b4e0-d0d8dae9d3a6	property-photos/62b77ba5-feb3-4877-b51d-757c04873772	local	property-photo	photos	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	6ee216be-e615-4730-96ec-776f7a244776	\N	\N	2025-12-20 11:41:38.313355	\N
aec24a9f-34f0-4724-a9bb-0d93a9296ff5	revenue-paperss/f58e0a00-cd22-4fcd-82f3-6fe2de2744de	local	revenue-papers	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	6e592576-d816-4354-8455-0ddb22fd8e79	\N	\N	2025-12-20 12:52:47.918179	\N
f49c3837-51d8-4cb5-9b8b-5fa1fe03e444	affidavit-section29s/f2dbdd3c-2a5a-4202-a426-7ffbdc465f54	local	affidavit-section29	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	6e592576-d816-4354-8455-0ddb22fd8e79	\N	\N	2025-12-20 12:52:50.864515	\N
03c5bcb5-6473-420f-b563-7e5f98218866	undertaking-form-cs/80f70218-e8ae-4aa8-a424-f55de3d40075	local	undertaking-form-c	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	6e592576-d816-4354-8455-0ddb22fd8e79	\N	\N	2025-12-20 12:52:54.727958	\N
f709ecc6-09ee-449d-a5d8-06f84360fced	property-photos/b8355a3a-2cbe-4d2f-9a70-2222a77c3f62	local	property-photo	photos	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	6e592576-d816-4354-8455-0ddb22fd8e79	\N	\N	2025-12-20 12:53:05.957175	\N
5390d01e-35ba-49d5-a94c-9f2542d49079	property-photos/b6357610-135b-493e-8a11-dd05ec22c6ee	local	property-photo	photos	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	6e592576-d816-4354-8455-0ddb22fd8e79	\N	\N	2025-12-20 12:53:08.707453	\N
7062249e-1a16-4ae2-9a68-7e2cda7debc5	additional-documents/94d74cba-9592-446a-986f-4cb57ecc1024	local	additional-document	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	6e592576-d816-4354-8455-0ddb22fd8e79	\N	\N	2025-12-20 12:53:11.874279	\N
59cbc7b8-da64-4f7e-9dcb-37768a9c1651	revenue-paperss/2a445d51-d712-4e68-9ee3-097eeff78d3c	local	revenue-papers	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	7749040a-4097-404a-bba5-b00721476da4	\N	\N	2025-12-20 12:56:23.628926	\N
ca651539-a094-4eff-b7b4-148a9dc2dbb7	affidavit-section29s/56fbcfa7-2c56-4cde-b311-b19f7c4485db	local	affidavit-section29	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	7749040a-4097-404a-bba5-b00721476da4	\N	\N	2025-12-20 12:56:26.139531	\N
f3a56f07-6c8b-4561-8a89-0c6bb5aa34c2	undertaking-form-cs/5db3541c-164b-4077-ba94-dd942a3b8610	local	undertaking-form-c	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	7749040a-4097-404a-bba5-b00721476da4	\N	\N	2025-12-20 12:56:29.172036	\N
b884b057-4a79-4a25-9083-6ab3c29cef1c	property-photos/d7c067ed-a666-4be9-b6c5-5ca2bd1b0fee	local	property-photo	photos	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	7749040a-4097-404a-bba5-b00721476da4	\N	\N	2025-12-20 12:56:32.07044	\N
ed429e0a-735f-4bdc-ac16-882b6d326c76	property-photos/584b4d63-9948-4754-9944-6b948e768091	local	property-photo	photos	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	7749040a-4097-404a-bba5-b00721476da4	\N	\N	2025-12-20 12:56:34.893594	\N
fc327c77-ac87-4880-8cc0-80816b800e4e	revenue-paperss/2205a088-16ac-4873-a082-c01fc3696d51	local	revenue-papers	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	04ac9697-6f79-42ce-8c9e-a7c6e40064e8	\N	\N	2025-12-20 13:00:15.069789	\N
42615d86-e647-4ff3-973d-59914ec8df31	affidavit-section29s/b8b6e9e8-48ae-4bf1-a0dd-0d2cf630315d	local	affidavit-section29	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	04ac9697-6f79-42ce-8c9e-a7c6e40064e8	\N	\N	2025-12-20 13:00:24.65169	\N
fdc7e381-d2e0-4247-801b-466c515a8173	undertaking-form-cs/3a79c870-7da6-47e3-af9c-2cde0e2ddbd9	local	undertaking-form-c	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	04ac9697-6f79-42ce-8c9e-a7c6e40064e8	\N	\N	2025-12-20 13:01:15.145	\N
b5c10ab0-4cca-4e4e-a0ce-091a72448a59	property-photos/02b42e85-db7b-4073-aeb0-108284deb4f1	local	property-photo	photos	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	04ac9697-6f79-42ce-8c9e-a7c6e40064e8	\N	\N	2025-12-20 13:01:18.287182	\N
e5bf4ac0-7ede-4b9a-a144-7e47e28f3af1	property-photos/61fb9275-1c9e-48c9-9409-f0e3029b1935	local	property-photo	photos	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	04ac9697-6f79-42ce-8c9e-a7c6e40064e8	\N	\N	2025-12-20 13:01:21.111134	\N
f0713084-53d4-40f6-bbfa-d755db4b3d6e	revenue-paperss/37cc2615-92be-400b-ba84-c8fe4fc82673	local	revenue-papers	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	0bbe93ff-cac5-4e91-b2f2-686669d01d05	\N	\N	2025-12-20 13:06:09.134612	\N
056f3d46-6d45-491e-8749-19c8ca369a57	affidavit-section29s/58a0903b-c927-47d6-85b9-49829303ad06	local	affidavit-section29	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	0bbe93ff-cac5-4e91-b2f2-686669d01d05	\N	\N	2025-12-20 13:06:11.347701	\N
04229c26-80ef-4d10-884b-6554b069be9f	undertaking-form-cs/aaec5845-9c76-4681-b5ea-eef038218553	local	undertaking-form-c	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	0bbe93ff-cac5-4e91-b2f2-686669d01d05	\N	\N	2025-12-20 13:06:13.811962	\N
e1ebda61-95e0-48c0-9c8d-8dcda6e4fe12	property-photos/fa91f752-9a32-4b0a-a16c-786a897c12a9	local	property-photo	photos	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	0bbe93ff-cac5-4e91-b2f2-686669d01d05	\N	\N	2025-12-20 13:06:17.677124	\N
0502a5af-8637-4da9-8638-d23c08a0e5a7	property-photos/c2e506e4-6c2c-4250-94ae-275cc5db8a16	local	property-photo	photos	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	0bbe93ff-cac5-4e91-b2f2-686669d01d05	\N	\N	2025-12-20 13:06:20.15631	\N
7bc0932e-3f42-413f-a257-fb30ad3980d2	revenue-paperss/8b645a94-fa62-4376-a8fe-c9d33ea6aeba	local	revenue-papers	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	b1f5eca1-f3d7-4df2-914b-f3d67010a00b	\N	\N	2025-12-20 13:10:05.208393	\N
24b523de-08fe-48e6-acfd-f87f22ae5f4f	affidavit-section29s/b1222556-afc2-4ff3-b1da-67e632b79f92	local	affidavit-section29	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	b1f5eca1-f3d7-4df2-914b-f3d67010a00b	\N	\N	2025-12-20 13:10:07.99967	\N
092f88c4-5798-4b4e-8832-c3620da40a80	undertaking-form-cs/4725ac10-7b3d-4151-a639-d47e84108e03	local	undertaking-form-c	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	b1f5eca1-f3d7-4df2-914b-f3d67010a00b	\N	\N	2025-12-20 13:10:13.754555	\N
ea38ac9d-2436-4166-9119-4811dcea741c	property-photos/4015d88f-26aa-4921-a598-43e7ab5c9b3c	local	property-photo	photos	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	b1f5eca1-f3d7-4df2-914b-f3d67010a00b	\N	\N	2025-12-20 13:10:16.554006	\N
0b1085d8-8b62-4101-bb86-756248d01c71	property-photos/a203ab8b-be71-42f8-ab84-5f3d18350e5d	local	property-photo	photos	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	b1f5eca1-f3d7-4df2-914b-f3d67010a00b	\N	\N	2025-12-20 13:10:19.617327	\N
4ced1b04-74d1-4cd6-a83b-d7e2305787c9	revenue-paperss/2a100282-67f8-4ff0-95bb-bfffd438f35a	local	revenue-papers	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	bdebfe2d-dc2f-4968-a4fd-b4329227d92d	\N	\N	2025-12-20 13:13:06.112584	\N
53fc6e56-2e78-4f98-931f-c589b34be818	affidavit-section29s/d9970c55-7c34-419f-8bf5-8e97a9b10de9	local	affidavit-section29	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	bdebfe2d-dc2f-4968-a4fd-b4329227d92d	\N	\N	2025-12-20 13:13:08.486975	\N
c72db767-a966-4d5d-b48e-068814f07223	undertaking-form-cs/696464d0-5a19-48bf-8920-363d9de53219	local	undertaking-form-c	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	bdebfe2d-dc2f-4968-a4fd-b4329227d92d	\N	\N	2025-12-20 13:13:13.074842	\N
3572a272-597b-46e9-9f9e-35d4e44343aa	property-photos/cc682cbe-d9f4-4f8c-a0d8-d1f922ae573f	local	property-photo	photos	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	bdebfe2d-dc2f-4968-a4fd-b4329227d92d	\N	\N	2025-12-20 13:13:16.163932	\N
528e736f-a95a-4d0b-9bf3-830de5ba170d	property-photos/d7c8d090-8d80-4344-a779-6fe801d37c5f	local	property-photo	photos	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	bdebfe2d-dc2f-4968-a4fd-b4329227d92d	\N	\N	2025-12-20 13:13:19.980111	\N
301eac6b-f71b-41ee-81be-42c4145f2719	revenue-paperss/758854ee-4e49-4fff-aa34-4ea33ef90b50	local	revenue-papers	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	3a61a143-319b-4b43-a591-b4e9612a8356	\N	\N	2025-12-20 17:13:24.531113	\N
7cf9a673-60a6-4940-bac7-1ed4dbab4d31	affidavit-section29s/83e404fd-e9ac-459e-94d7-5c66990263b3	local	affidavit-section29	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	3a61a143-319b-4b43-a591-b4e9612a8356	\N	\N	2025-12-20 17:13:30.541784	\N
c513b4c1-67f8-4086-90e1-3b26ddf28878	undertaking-form-cs/275cd3f9-73ae-47d3-8be1-e18b358d9ad5	local	undertaking-form-c	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	3a61a143-319b-4b43-a591-b4e9612a8356	\N	\N	2025-12-20 17:13:37.282566	\N
d0e26268-a6e6-478c-8b5c-e4abc7c52b78	property-photos/384e9d8e-bba3-49b3-8c7b-af35599e01b9	local	property-photo	photos	image/jpeg	96524	02f226a52cfa9b5054adcfe008a6b8885b9a5f56adc2d53ad3382d9502cbd6dd	3a61a143-319b-4b43-a591-b4e9612a8356	\N	\N	2025-12-20 17:13:48.931898	\N
0771644c-62a5-4d6b-afc3-9a232901ddf7	property-photos/82764aa3-9f87-49f0-b5a0-a3d71ab5d19c	local	property-photo	photos	image/jpeg	13584	12434b6deb0704e02e9f467b990ca3498923894c9c205a1ab3acff0f3eb8a846	3a61a143-319b-4b43-a591-b4e9612a8356	\N	\N	2025-12-20 17:13:49.022515	\N
5c7a8aeb-5d22-46d6-be0b-e20898430bc8	property-photos/b025cbf1-b63c-46f1-82d7-17e74ad075ad	local	property-photo	photos	image/jpeg	98782	52f471ee0bc0cc8de607df7bab4787266c5b4ead1cf339e7a0316bae2f1a4cee	3a61a143-319b-4b43-a591-b4e9612a8356	\N	\N	2025-12-20 17:13:49.134113	\N
cc9581be-536e-4ac5-ac0a-7763453c40b6	additional-documents/c2a9aa05-d1f4-4e08-8a02-c0cea0cbea20	local	additional-document	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	2c41a160-de2a-4141-910e-4021bdeac7c4	\N	\N	2025-12-20 17:47:24.04016	\N
dcfb3054-dd91-44f1-9aa0-4d5fa5e933a5	additional-documents/9eacc85b-95c5-4a7f-aeba-b7d5a2c227e7	local	additional-document	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	2c41a160-de2a-4141-910e-4021bdeac7c4	\N	\N	2025-12-20 17:47:42.897013	\N
be59baec-3394-4043-916f-c896756c41d6	property-photos/44f404ed-03b0-4f2e-9feb-38e483d90c28	local	property-photo	photos	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	2c41a160-de2a-4141-910e-4021bdeac7c4	\N	\N	2025-12-20 17:47:52.134571	\N
468fdf8c-508e-46fe-9c9a-471835d402c1	commercial-electricity-bills/6bf3f636-c399-4810-a09a-5eb7c7345d94	local	commercial-electricity-bill	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	2c41a160-de2a-4141-910e-4021bdeac7c4	\N	\N	2025-12-20 17:48:03.895579	\N
dcc66be6-04d0-45ab-b5e7-8b617f4a3ea9	commercial-water-bills/6d8872a9-09a8-4650-ad02-c0c0d35812b7	local	commercial-water-bill	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	2c41a160-de2a-4141-910e-4021bdeac7c4	\N	\N	2025-12-20 17:48:07.688116	\N
b2f56892-b2e1-476b-8e02-46857d07002b	revenue-paperss/c0973134-d7b5-49ec-befb-149cfa1a8351	local	revenue-papers	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	033bb139-19cf-45a0-a191-01986b65449f	\N	\N	2025-12-20 18:50:06.489714	\N
980dcdc8-90fc-4798-b0b0-5ca735eabc90	affidavit-section29s/26a47646-276a-465b-8e21-a81f95236e95	local	affidavit-section29	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	033bb139-19cf-45a0-a191-01986b65449f	\N	\N	2025-12-20 18:50:10.152503	\N
92ba9cb7-788b-407f-b735-5ae1c09ef030	undertaking-form-cs/bceb06ae-6227-4719-a086-d030510dab8b	local	undertaking-form-c	documents	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	033bb139-19cf-45a0-a191-01986b65449f	\N	\N	2025-12-20 18:50:13.533841	\N
4c4d660f-3abb-46a3-980c-a99e362baeab	property-photos/7e244c9d-9158-4dab-9f13-a439c7d07432	local	property-photo	photos	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	033bb139-19cf-45a0-a191-01986b65449f	\N	\N	2025-12-20 18:50:16.937309	\N
320023f7-a140-4e24-9dcb-3ce8e0210bf1	property-photos/76d5edc4-c43f-4b8c-a0df-394f09daeecd	local	property-photo	photos	application/pdf	74656	382ac9ea60bb0ba40c9eb0815f4ec7f60e248fc136d3055c411d09709e1b9b31	033bb139-19cf-45a0-a191-01986b65449f	\N	\N	2025-12-20 18:50:20.113485	\N
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_settings (id, setting_key, setting_value, description, category, updated_by, created_at, updated_at) FROM stdin;
ff98916f-d942-44c7-a11f-1a9d9ab1a34b	comm_sms_gateway	{"nic": {"postUrl": "https://msdgweb.mgov.gov.in/esms/sendsmsrequestDLT", "password": "Tour@sml352", "senderId": "hpgovt", "username": "hpgovt-TACA", "templateId": "1007739248479536901", "departmentKey": "a63f7853-6297-44c7-820b-392541a47fc1"}, "provider": "nic"}	SMS gateway configuration	communications	9def5322-010c-43a4-9712-10977499b1da	2025-12-11 20:18:31.087509	2025-12-11 20:18:31.087509
0917cbdc-ec1a-4eab-825c-9edbe7ab1f46	comm_email_gateway	{"custom": {"host": "mail.smtp2go.com", "port": 2525, "password": "osipl@2025", "username": "osipl.dev", "fromEmail": "hptourism@osipl.dev"}, "provider": "custom"}	Email gateway configuration	communications	9def5322-010c-43a4-9712-10977499b1da	2025-12-11 20:18:52.906864	2025-12-11 20:18:52.906864
d15a5f03-9be2-4006-8830-c0aa5324b19e	auth_captcha_enabled	{"enabled": false}	Toggle captcha requirement	auth	9def5322-010c-43a4-9712-10977499b1da	2025-12-13 02:02:37.005108	2025-12-13 02:02:37.005108
724eabea-395e-4a59-ac3e-02423d187944	admin_super_console_enabled	{"enabled": true}	Enable/disable super console	admin	9def5322-010c-43a4-9712-10977499b1da	2025-12-11 20:10:31.766081	2025-12-14 18:09:34.173
cad7c7ff-deec-4ea8-a40f-0ab7bf501757	payment_test_mode	{"enabled": true}	When enabled, payment requests send ₹1 to gateway instead of actual amount (for testing)	payment	9def5322-010c-43a4-9712-10977499b1da	2025-12-14 18:42:23.259102	2025-12-14 18:42:23.259102
94a8eb4b-2374-4a9a-a87d-98e81f066230	payment_workflow	{"workflow": "upfront", "upfrontSubmitMode": "auto"}	Payment workflow: 'upfront' = pay before submission, 'on_approval' = pay after approval	payment	9def5322-010c-43a4-9712-10977499b1da	2025-12-12 02:48:22.295042	2025-12-14 18:44:15.351
63888f6d-f607-4790-b627-67435ba4b756	backup_configuration	{"enabled": true, "schedule": "0 2 * * *", "includeFiles": true, "lastBackupAt": "2025-12-19T20:30:00.021Z", "retentionDays": 30, "backupDirectory": "/home/subhash.thakur.india/Projects/hptourism-rc5dev/backups", "includeDatabase": true, "lastBackupStatus": "success"}	\N	general	\N	2025-12-11 20:30:01.849248	2025-12-19 20:30:04.03
4beb436b-de6b-4ae5-ae20-a358b31768eb	multi_service_hub_enabled	{"enabled": false}	\N	general	9def5322-010c-43a4-9712-10977499b1da	2025-12-14 18:59:04.0206	2025-12-20 10:06:47.398
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_profiles (id, user_id, full_name, gender, aadhaar_number, mobile, email, district, tehsil, block, gram_panchayat, urban_body, ward, address, pincode, telephone, fax, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, mobile, full_name, first_name, last_name, username, email, alternate_phone, designation, department, employee_id, office_address, office_phone, role, aadhaar_number, district, password, is_active, created_at, updated_at, sso_id) FROM stdin;
9def5322-010c-43a4-9712-10977499b1da	9999999998	Super Admin	Super	Admin	superadmin	superadmin@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	super_admin	\N	\N	$2b$10$RahzsVePrPgYeTfb3.giXOLQf8CC5ndpcJVAYvS2UPiIGmFLmpz52	t	2025-12-11 10:57:28.226419	2025-12-11 10:57:28.226419	\N
ce14f7d4-6232-4185-bacf-600afbf5aa7a	7900001001	DTDO Chamba	DTDO	Chamba	dtdo_chamba	dtdo.chamba@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Chamba HQ	$2b$10$RdrhSA7xtmRL/WaX5cokjeF.cwFaQ4rD6rX19f5yk9fT2Q66oSFBW	t	2025-12-11 10:57:28.356315	2025-12-11 10:57:28.356315	\N
7d133c62-f506-45a9-b6f7-88897210ccb5	7800001002	DA Bharmour	DA	Bharmour	da_bharmour	da.bharmour@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Bharmour Sub-Division	$2b$10$C4qDd1q75FgXpRXVWU5dzO0sbwVa1LSCkaWcNqkV.51tYWE4JG3by	t	2025-12-11 10:57:28.420115	2025-12-11 10:57:28.420115	\N
f887aa41-650c-478d-aeca-e54c1ade64fe	7900001002	DTDO Bharmour	DTDO	Bharmour	dtdo_bharmour	dtdo.bharmour@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Bharmour Sub-Division	$2b$10$rnVrv7GMkq3O6e4brlXFxuYMA.jLnJsEe75nwiZIXULwBjyReWbyq	t	2025-12-11 10:57:28.484735	2025-12-11 10:57:28.484735	\N
86e9a1bf-b1e6-4009-a796-5230b29a238b	7800001003	DA Shimla Hq	DA	Shimla Hq	da_shimla_hq	da.shimla-hq@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Shimla HQ (AC Tourism)	$2b$10$DpuVq1TzYnyUdzyz3eeYpeIcNXGWLr0dorL9VUk5DdPBTaBV21Fw.	t	2025-12-11 10:57:28.549707	2025-12-11 10:57:28.549707	\N
d9667ab6-056c-4933-9959-5516661b0c43	7900001003	DTDO Shimla Hq	DTDO	Shimla Hq	dtdo_shimla_hq	dtdo.shimla-hq@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Shimla HQ (AC Tourism)	$2b$10$9A10tgzX26vfVBXXKKASqOCT1ZABZQlDJvYKi6Y2VJT23vgxQ1V8.	t	2025-12-11 10:57:28.614474	2025-12-11 10:57:28.614474	\N
e618e427-7635-4319-b33b-b4f7c450bac8	7800001004	DA Hamirpur	DA	Hamirpur	da_hamirpur	da.hamirpur@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Hamirpur (serving Una)	$2b$10$Zzv3fdFLZj5rD8m83SlQ5uhMi/8bPVNJAZFflDTyjzCZuo32rd7Ma	t	2025-12-11 10:57:28.679604	2025-12-11 10:57:28.679604	\N
71a0d808-c635-4212-ac93-bd72b772ef6d	7900001004	DTDO Hamirpur	DTDO	Hamirpur	dtdo_hamirpur	dtdo.hamirpur@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Hamirpur (serving Una)	$2b$10$GL4XjXQHoGoawDtwp61va.Y.XHl7kAbidAaTX3PaxVge/vrM2FiR6	t	2025-12-11 10:57:28.745268	2025-12-11 10:57:28.745268	\N
1e92acf4-d2f8-4dc4-842e-2277be44ea2b	7800001005	DA Kullu Manali	DA	Kullu Manali	da_kullu_manali	da.kullu-manali@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Kullu (Bhuntar/Manali)	$2b$10$wBCdWTXE2g0IIOZWDvaU8er43QK7YaF3r61qWNX55r8ebYNfZ7Sgq	t	2025-12-11 10:57:28.811465	2025-12-11 10:57:28.811465	\N
94a9a69c-38b4-4e83-90bd-7820cc413958	7900001005	DTDO Kullu Manali	DTDO	Kullu Manali	dtdo_kullu_manali	dtdo.kullu-manali@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Kullu (Bhuntar/Manali)	$2b$10$SOKVHm9Rso6Ve0W2YYDBM.XYrKmrhPMyOouNDp1SB2OPV2HAI0Er2	t	2025-12-11 10:57:28.880845	2025-12-11 10:57:28.880845	\N
53672c24-b63b-43a8-818d-88c0967eaee2	7800001006	DA Kullu Dhalpur	DA	Kullu Dhalpur	da_kullu_dhalpur	da.kullu-dhalpur@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Kullu Dhalpur	$2b$10$CtBoDNAk4NWKOsDbpnVT8OHZy63L59NwTJCCTFJ/loXstlGTipxy6	t	2025-12-11 10:57:28.946984	2025-12-11 10:57:28.946984	\N
b49484b5-5833-49c9-a238-3b53fb27e6c2	7900001006	DTDO Kullu Dhalpur	DTDO	Kullu Dhalpur	dtdo_kullu_dhalpur	dtdo.kullu-dhalpur@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Kullu Dhalpur	$2b$10$pD6gmwiw69H7vmbum9N5TO5cyLHa7vWwIVMlGWOg9y4f5G/8Nvxre	t	2025-12-11 10:57:29.012314	2025-12-11 10:57:29.012314	\N
77d45a12-3d6f-4985-adf5-6991b154b70d	7800001007	DA Dharamsala	DA	Dharamsala	da_dharamsala	da.dharamsala@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Dharamsala (Kangra)	$2b$10$qhyZkFZbOIhNGORuMMd/yu.7W58GhWc4.Lga7cfACutOuZNO0KUWq	t	2025-12-11 10:57:29.077171	2025-12-11 10:57:29.077171	\N
0713100b-5a61-4bc8-b7f2-941d5ca3d97f	7900001007	DTDO Dharamsala	DTDO	Dharamsala	dtdo_dharamsala	dtdo.dharamsala@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Dharamsala (Kangra)	$2b$10$vnhhi6voNRuBDUnZ6hAw6ej0jxhIMZcUujt4RffwFwY4gw6CIHzqC	t	2025-12-11 10:57:29.142867	2025-12-11 10:57:29.142867	\N
a6496ab6-d7af-40f4-81b2-0018d4ac99e0	7800001008	DA Kinnaur	DA	Kinnaur	da_kinnaur	da.kinnaur@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Kinnaur (Reckong Peo)	$2b$10$uWsSiBM9RJJ.PLK66u58s.WupA0WWPqRQHtRVG0y1Pc3xQT/zukZ6	t	2025-12-11 10:57:29.207842	2025-12-11 10:57:29.207842	\N
32ad65d2-21c8-4a12-ac73-e9230a4ac437	7900001008	DTDO Kinnaur	DTDO	Kinnaur	dtdo_kinnaur	dtdo.kinnaur@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Kinnaur (Reckong Peo)	$2b$10$OeBlbbHb0AsgqPLh2fbiTes0ASFc0Cp.iDLQPRae0SQ.zaerUr0Xu	t	2025-12-11 10:57:29.272639	2025-12-11 10:57:29.272639	\N
1779be4e-4dfd-4e3d-b735-0f8f79c13a7b	7800001009	DA Kaza	DA	Kaza	da_kaza	da.kaza@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Kaza (Spiti ITDP)	$2b$10$YveBOS2WYvDzGB1R7UFhKeBuwjmhEVd9fVK7dWcMsWFj04Ry/sJwq	t	2025-12-11 10:57:29.338431	2025-12-11 10:57:29.338431	\N
323109fd-0f71-4440-ace7-e72c58083f17	7900001009	DTDO Kaza	DTDO	Kaza	dtdo_kaza	dtdo.kaza@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Kaza (Spiti ITDP)	$2b$10$oron8HIIxbMOO5B6EdwPYuGYB2aqsq/uEGnWupgD9nQ1h.LBDx3Ku	t	2025-12-11 10:57:29.40419	2025-12-11 10:57:29.40419	\N
cc9dee09-fa3f-450a-9b7a-57422aee9654	7800001010	DA Lahaul	DA	Lahaul	da_lahaul	da.lahaul@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Lahaul (Keylong)	$2b$10$KjlCMI75I2timCeK.YNQxeAWr3zEHiDyTaJuveUmMFfowG5hQOSlm	t	2025-12-11 10:57:29.469047	2025-12-11 10:57:29.469047	\N
ff06075b-a496-4556-8899-d0f855595cd8	7900001010	DTDO Lahaul	DTDO	Lahaul	dtdo_lahaul	dtdo.lahaul@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Lahaul (Keylong)	$2b$10$CfL35I.nAX2Djjp/Af5VCuwhdLvvglwos8k9G6g9Em6SZE/tKAB/y	t	2025-12-11 10:57:29.533531	2025-12-11 10:57:29.533531	\N
ec07c1a6-5120-4947-ae02-de9c93012613	7800001011	DA Mandi	DA	Mandi	da_mandi	da.mandi@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Mandi Division	$2b$10$nhcvHvkaohpcbspYjN6VDehlmYUQgsrSc1E.E6jqq3KIWwGCkhjaC	t	2025-12-11 10:57:29.598946	2025-12-11 10:57:29.598946	\N
813c56af-d7e8-47af-a014-43817214b853	7900001011	DTDO Mandi	DTDO	Mandi	dtdo_mandi	dtdo.mandi@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Mandi Division	$2b$10$Iu57Lvlik3LPSWAtg1pB/uPSHX3dax9lFMwXAHFEdRpDaUshVBjom	t	2025-12-11 10:57:29.663946	2025-12-11 10:57:29.663946	\N
6c101e40-2e70-4c47-adee-bde3b7644710	7800001012	DA Pangi	DA	Pangi	da_pangi	da.pangi@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Pangi (ITDP)	$2b$10$6o1qTN3ZQFuC9XcMKqYYEOqLGTmjJ5OLyZAS7bhQKQWM93gDp30GW	t	2025-12-11 10:57:29.729057	2025-12-11 10:57:29.729057	\N
5e0a634e-a2c9-4836-b738-f23938ef0a19	7900001012	DTDO Pangi	DTDO	Pangi	dtdo_pangi	dtdo.pangi@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Pangi (ITDP)	$2b$10$4JBhuaIOdBShczehYn5gIuAPzj2w9br4L8MlI1vWiIXoS9i7a8I.y	t	2025-12-11 10:57:29.794094	2025-12-11 10:57:29.794094	\N
5dffdaad-0838-4c27-b4ab-b3b8e455f3a1	7800001001	DA Chamba	DA	Chamba	da_chamba	da.chamba@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Chamba HQ	$2b$10$EdAWgs.IKowVdfGI7u.BReoq6IDc5fem3mzykShub197QdwFLGWPG	t	2025-12-11 10:57:28.292761	2025-12-11 10:57:28.292761	\N
486a4663-dcc8-49fb-8c4c-9aeafef4bb97	7800001013	DA Shimla	DA	Shimla	da_shimla	da.shimla@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Shimla Division	$2b$10$TUZaRPcSmUi8J96B/3uOEOUwTvPdMQKliWS2n6g3IRgABAMHpe/cm	t	2025-12-11 10:57:29.858697	2025-12-11 10:57:29.858697	\N
3b2fa85b-806a-44b8-93ce-07ad7aa8a842	7900001013	DTDO Shimla	DTDO	Shimla	dtdo_shimla	dtdo.shimla@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Shimla Division	$2b$10$Js.idd/l4UNdhvNif5WzYe3rEWhEChwx4xropOhAqCUu8R29fzHKC	t	2025-12-11 10:57:29.924036	2025-12-11 10:57:29.924036	\N
cb5552a8-4bb2-4b6f-818b-609aaad2073e	7800001014	DA Sirmaur	DA	Sirmaur	da_sirmaur	da.sirmaur@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Sirmaur (Nahan)	$2b$10$qUBaY8.4jaPZ0CH3zU/DCOST8DST8GsFhr4pfd/L9/bdGKL7VQv4m	t	2025-12-11 10:57:29.990139	2025-12-11 10:57:29.990139	\N
2f56774b-a9e3-4578-badd-9a9c5fa794c2	7900001014	DTDO Sirmaur	DTDO	Sirmaur	dtdo_sirmaur	dtdo.sirmaur@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Sirmaur (Nahan)	$2b$10$lb2/0vjD8wyENCfFBS5zyOtS2ofIIrcl.kuIZ1./Kr9HdpTHNlpla	t	2025-12-11 10:57:30.055262	2025-12-11 10:57:30.055262	\N
7fe7f335-48ac-497f-9043-3ff1f258ae59	7800001015	DA Solan	DA	Solan	da_solan	da.solan@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Solan Division	$2b$10$vDClsxeefycExBqAAePcBe.C84Y0MkpODdVERKJ8RjTAPZ0wt4Z7q	t	2025-12-11 10:57:30.120711	2025-12-11 10:57:30.120711	\N
287368b2-eb02-475c-9859-f53667a38332	7900001015	DTDO Solan	DTDO	Solan	dtdo_solan	dtdo.solan@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Solan Division	$2b$10$0hxe0W0bldfJFCIdoJoOLOE1.v6lTBCl8mneYVtUBunJEzBME0Fe2	t	2025-12-11 10:57:30.186022	2025-12-11 10:57:30.186022	\N
410f3061-4b5e-4c4a-b049-633b3071989c	9999999992	District Officer Shimla	\N	\N	\N	district@hptourism.gov.in	\N	\N	\N	\N	\N	\N	district_officer	123456789002	Shimla	$2b$10$dPdCtvLMknWSHxh7.kS.7./EEq.254ZBhD7FzPHVZU5WydGneCeiy	t	2025-12-19 03:50:16.904067	2025-12-19 03:50:16.904067	\N
21d0dc7f-333a-4061-b2f0-02725d0b08af	9999999993	State Tourism Officer	\N	\N	\N	state@hptourism.gov.in	\N	\N	\N	\N	\N	\N	state_officer	123456789003	Shimla	$2b$10$dPdCtvLMknWSHxh7.kS.7./EEq.254ZBhD7FzPHVZU5WydGneCeiy	t	2025-12-19 03:50:16.904067	2025-12-19 03:50:16.904067	\N
2c41a160-de2a-4141-910e-4021bdeac7c4	6666666610	Test  AAA	Test 	AAA	\N	test@test.com	\N	\N	\N	\N	\N	\N	property_owner	666666666610	\N	$2b$10$rz1WpmjPCjIgYUhG9KrxaeAVpIN6wE3ZzXVv47zChS/FlHlzF6kjS	t	2025-12-20 10:02:29.306313	2025-12-20 10:02:29.306313	\N
587e43ed-d70b-4184-aac9-0aa54c657bfb	7777777700	Avi THaakur	Avi	THaakur	\N	a@gmail.cpm	\N	\N	\N	\N	\N	\N	property_owner	111111111100	\N	$2b$10$RFdX699nDlPMnJ1jZm2WR.ptu0Iqk1WVu0Vkhunbm3mYuoDVJcKLO	t	2025-12-20 11:23:03.429208	2025-12-20 11:25:05.205	\N
6ee216be-e615-4730-96ec-776f7a244776	7777777701	fafsd adsfds	fafsd	adsfds	\N	b@gmail.com	\N	\N	\N	\N	\N	\N	property_owner	111111111101	\N	$2b$10$DeICoHHxteZL0THNREL2OunCDDT2zDb9PAo6MrnwE9o93ytclu1He	t	2025-12-20 11:38:46.411271	2025-12-20 11:38:46.411271	\N
6e592576-d816-4354-8455-0ddb22fd8e79	7777777702	Avi THaakur	Avi	THaakur	\N	a4@gmail.cpm	\N	\N	\N	\N	\N	\N	property_owner	111111111103	\N	$2b$10$EFMY1X2cip06sbck/vzqI.F/.Y6IZAMUtgwhTPpsFkIACZTGpt4h6	t	2025-12-20 12:50:36.366132	2025-12-20 12:50:36.366132	\N
7749040a-4097-404a-bba5-b00721476da4	7777777703	dfs fds	dfs	fds	\N	a4@gmail.cpm	\N	\N	\N	\N	\N	\N	property_owner	111111111104	\N	$2b$10$QKRTlKMq/ClNMaYNCDnIJ.vE978llwNEbF0fDyY7lKsDcd6.z8OUG	t	2025-12-20 12:55:23.092423	2025-12-20 12:55:23.092423	\N
04ac9697-6f79-42ce-8c9e-a7c6e40064e8	7777777704	gh aedf	gh	aedf	\N	a4@gmail.cpm	\N	\N	\N	\N	\N	\N	property_owner	111111111105	\N	$2b$10$dDAjhtzGXNqqPSI2cGg5judfS2lH.wpYkK6p3Hh1YWlsQ0zZOVccu	t	2025-12-20 12:59:03.765289	2025-12-20 12:59:03.765289	\N
0bbe93ff-cac5-4e91-b2f2-686669d01d05	7777777705	DSFAS FDSGE	DSFAS	FDSGE	\N	a4@gmail.cpm	\N	\N	\N	\N	\N	\N	property_owner	111111111106	\N	$2b$10$LoKiShyxuThukfRSKpj0BuKLNO9yczUcwnDJTiNpKuFYQz/0fPG16	t	2025-12-20 13:04:35.038364	2025-12-20 13:04:35.038364	\N
b1f5eca1-f3d7-4df2-914b-f3d67010a00b	7777777707	DS DFD	DS	DFD	\N	a4@gmail.cpm	\N	\N	\N	\N	\N	\N	property_owner	111111111108	\N	$2b$10$AFtLRllhQRei4ihnXArAC.nUQa77uPcDE2Pa9QPDK3gBg4aGcR8eq	t	2025-12-20 13:08:43.624755	2025-12-20 13:08:43.624755	\N
bdebfe2d-dc2f-4968-a4fd-b4329227d92d	7777777709	HHJ JKKJ	HHJ	JKKJ	\N	a4@gmail.cpm	\N	\N	\N	\N	\N	\N	property_owner	111111111109	\N	$2b$10$HnuSHJ0lq/Fx10kJ36UoJ.yzEFsjtQAyDhqYGuRWOaHY.03ZrO6.O	t	2025-12-20 13:12:07.209727	2025-12-20 13:12:07.209727	\N
033bb139-19cf-45a0-a191-01986b65449f	7777777710	DSF fvb	DSF	fvb	\N	a4@gmail.cpm	\N	\N	\N	\N	\N	\N	property_owner	111111111110	\N	$2b$10$Mm0mo4gEfT0JtmfvKmhdK.SDzK.W.JPDpZAiAa4cUiKUIkMuSB6X2	t	2025-12-20 13:23:47.535087	2025-12-20 13:23:47.535087	\N
08ee781b-8d0f-44d4-8c0f-218b70984ee8	7777777711	dsf sdf	dsf	sdf	\N	\N	\N	\N	\N	\N	\N	\N	property_owner	666666666690	\N	$2b$10$Vc87e6ObgrFjmyySBDEszOGJQd2rO3MXqic0NHmgAjdV4Wk4MEoai	t	2025-12-20 13:33:45.516778	2025-12-20 13:33:45.516778	\N
3a61a143-319b-4b43-a591-b4e9612a8356	6666666611	Test AAA	Test	AAA	\N	microaistudio@gmail.com	\N	\N	\N	\N	\N	\N	property_owner	666666666611	\N	$2b$10$tAPGW/mrFpVeJePOJFEnaONruPRZuDY7LxLSUi9dB.JUijo97XbPq	t	2025-12-20 17:11:41.489515	2025-12-20 17:11:41.489515	\N
b7e7f5f4-7aa2-4e06-9d7f-00b3fb419d12	6666666612	Test BBB	Test	BBB	\N	subhash.thakur.india@gmail.com	\N	\N	\N	\N	\N	\N	property_owner	666666666612	\N	$2b$10$JciQPApDVzvU46DZj/XPUeVMGu.X1.V0jpWZrNmNq8fBqAjhKGno6	t	2025-12-20 17:55:20.310391	2025-12-20 17:55:20.310391	\N
\.


--
-- Name: application_actions application_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_actions
    ADD CONSTRAINT application_actions_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: certificates certificates_application_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_application_id_unique UNIQUE (application_id);


--
-- Name: certificates certificates_certificate_number_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_certificate_number_unique UNIQUE (certificate_number);


--
-- Name: certificates certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_pkey PRIMARY KEY (id);


--
-- Name: clarifications clarifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_pkey PRIMARY KEY (id);


--
-- Name: ddo_codes ddo_codes_district_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ddo_codes
    ADD CONSTRAINT ddo_codes_district_unique UNIQUE (district);


--
-- Name: ddo_codes ddo_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ddo_codes
    ADD CONSTRAINT ddo_codes_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: himkosh_transactions himkosh_transactions_app_ref_no_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.himkosh_transactions
    ADD CONSTRAINT himkosh_transactions_app_ref_no_unique UNIQUE (app_ref_no);


--
-- Name: himkosh_transactions himkosh_transactions_ech_txn_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.himkosh_transactions
    ADD CONSTRAINT himkosh_transactions_ech_txn_id_unique UNIQUE (ech_txn_id);


--
-- Name: himkosh_transactions himkosh_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.himkosh_transactions
    ADD CONSTRAINT himkosh_transactions_pkey PRIMARY KEY (id);


--
-- Name: homestay_applications homestay_applications_application_number_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_application_number_unique UNIQUE (application_number);


--
-- Name: homestay_applications homestay_applications_certificate_number_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_certificate_number_unique UNIQUE (certificate_number);


--
-- Name: homestay_applications homestay_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_pkey PRIMARY KEY (id);


--
-- Name: inspection_orders inspection_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_orders
    ADD CONSTRAINT inspection_orders_pkey PRIMARY KEY (id);


--
-- Name: inspection_reports inspection_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_reports
    ADD CONSTRAINT inspection_reports_pkey PRIMARY KEY (id);


--
-- Name: lgd_blocks lgd_blocks_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_blocks
    ADD CONSTRAINT lgd_blocks_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_blocks lgd_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_blocks
    ADD CONSTRAINT lgd_blocks_pkey PRIMARY KEY (id);


--
-- Name: lgd_districts lgd_districts_district_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_districts
    ADD CONSTRAINT lgd_districts_district_name_unique UNIQUE (district_name);


--
-- Name: lgd_districts lgd_districts_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_districts
    ADD CONSTRAINT lgd_districts_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_districts lgd_districts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_districts
    ADD CONSTRAINT lgd_districts_pkey PRIMARY KEY (id);


--
-- Name: lgd_gram_panchayats lgd_gram_panchayats_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_gram_panchayats
    ADD CONSTRAINT lgd_gram_panchayats_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_gram_panchayats lgd_gram_panchayats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_gram_panchayats
    ADD CONSTRAINT lgd_gram_panchayats_pkey PRIMARY KEY (id);


--
-- Name: lgd_tehsils lgd_tehsils_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_tehsils
    ADD CONSTRAINT lgd_tehsils_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_tehsils lgd_tehsils_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_tehsils
    ADD CONSTRAINT lgd_tehsils_pkey PRIMARY KEY (id);


--
-- Name: lgd_urban_bodies lgd_urban_bodies_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_urban_bodies
    ADD CONSTRAINT lgd_urban_bodies_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_urban_bodies lgd_urban_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_urban_bodies
    ADD CONSTRAINT lgd_urban_bodies_pkey PRIMARY KEY (id);


--
-- Name: login_otp_challenges login_otp_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_otp_challenges
    ADD CONSTRAINT login_otp_challenges_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: objections objections_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_pkey PRIMARY KEY (id);


--
-- Name: password_reset_challenges password_reset_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_reset_challenges
    ADD CONSTRAINT password_reset_challenges_pkey PRIMARY KEY (id);


--
-- Name: payments payments_gateway_transaction_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_gateway_transaction_id_unique UNIQUE (gateway_transaction_id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: payments payments_receipt_number_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_receipt_number_unique UNIQUE (receipt_number);


--
-- Name: production_stats production_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_stats
    ADD CONSTRAINT production_stats_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: storage_objects storage_objects_object_key_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_object_key_unique UNIQUE (object_key);


--
-- Name: storage_objects storage_objects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_setting_key_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_setting_key_unique UNIQUE (setting_key);


--
-- Name: user_profiles user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (id);


--
-- Name: user_profiles user_profiles_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_user_id_unique UNIQUE (user_id);


--
-- Name: users users_aadhaar_number_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_aadhaar_number_unique UNIQUE (aadhaar_number);


--
-- Name: users users_mobile_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_mobile_unique UNIQUE (mobile);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_sso_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_sso_id_key UNIQUE (sso_id);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_session_expire" ON public.session USING btree (expire);


--
-- Name: application_actions application_actions_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_actions
    ADD CONSTRAINT application_actions_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: application_actions application_actions_officer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_actions
    ADD CONSTRAINT application_actions_officer_id_users_id_fk FOREIGN KEY (officer_id) REFERENCES public.users(id);


--
-- Name: audit_logs audit_logs_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: certificates certificates_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: certificates certificates_issued_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_issued_by_users_id_fk FOREIGN KEY (issued_by) REFERENCES public.users(id);


--
-- Name: certificates certificates_renewal_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_renewal_application_id_homestay_applications_id_fk FOREIGN KEY (renewal_application_id) REFERENCES public.homestay_applications(id);


--
-- Name: certificates certificates_revoked_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_revoked_by_users_id_fk FOREIGN KEY (revoked_by) REFERENCES public.users(id);


--
-- Name: clarifications clarifications_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: clarifications clarifications_objection_id_objections_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_objection_id_objections_id_fk FOREIGN KEY (objection_id) REFERENCES public.objections(id) ON DELETE CASCADE;


--
-- Name: clarifications clarifications_reviewed_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_reviewed_by_users_id_fk FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: clarifications clarifications_submitted_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_submitted_by_users_id_fk FOREIGN KEY (submitted_by) REFERENCES public.users(id);


--
-- Name: documents documents_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: documents documents_verified_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_verified_by_users_id_fk FOREIGN KEY (verified_by) REFERENCES public.users(id);


--
-- Name: himkosh_transactions himkosh_transactions_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.himkosh_transactions
    ADD CONSTRAINT himkosh_transactions_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: homestay_applications homestay_applications_da_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_da_id_users_id_fk FOREIGN KEY (da_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_district_officer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_district_officer_id_users_id_fk FOREIGN KEY (district_officer_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_dtdo_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_dtdo_id_users_id_fk FOREIGN KEY (dtdo_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_site_inspection_officer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_site_inspection_officer_id_users_id_fk FOREIGN KEY (site_inspection_officer_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_state_officer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_state_officer_id_users_id_fk FOREIGN KEY (state_officer_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: inspection_orders inspection_orders_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_orders
    ADD CONSTRAINT inspection_orders_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: inspection_orders inspection_orders_assigned_to_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_orders
    ADD CONSTRAINT inspection_orders_assigned_to_users_id_fk FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: inspection_orders inspection_orders_scheduled_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_orders
    ADD CONSTRAINT inspection_orders_scheduled_by_users_id_fk FOREIGN KEY (scheduled_by) REFERENCES public.users(id);


--
-- Name: inspection_reports inspection_reports_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_reports
    ADD CONSTRAINT inspection_reports_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: inspection_reports inspection_reports_inspection_order_id_inspection_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_reports
    ADD CONSTRAINT inspection_reports_inspection_order_id_inspection_orders_id_fk FOREIGN KEY (inspection_order_id) REFERENCES public.inspection_orders(id) ON DELETE CASCADE;


--
-- Name: inspection_reports inspection_reports_submitted_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_reports
    ADD CONSTRAINT inspection_reports_submitted_by_users_id_fk FOREIGN KEY (submitted_by) REFERENCES public.users(id);


--
-- Name: lgd_blocks lgd_blocks_district_id_lgd_districts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_blocks
    ADD CONSTRAINT lgd_blocks_district_id_lgd_districts_id_fk FOREIGN KEY (district_id) REFERENCES public.lgd_districts(id) ON DELETE CASCADE;


--
-- Name: lgd_blocks lgd_blocks_tehsil_id_lgd_tehsils_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_blocks
    ADD CONSTRAINT lgd_blocks_tehsil_id_lgd_tehsils_id_fk FOREIGN KEY (tehsil_id) REFERENCES public.lgd_tehsils(id) ON DELETE SET NULL;


--
-- Name: lgd_gram_panchayats lgd_gram_panchayats_block_id_lgd_blocks_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_gram_panchayats
    ADD CONSTRAINT lgd_gram_panchayats_block_id_lgd_blocks_id_fk FOREIGN KEY (block_id) REFERENCES public.lgd_blocks(id) ON DELETE CASCADE;


--
-- Name: lgd_gram_panchayats lgd_gram_panchayats_district_id_lgd_districts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_gram_panchayats
    ADD CONSTRAINT lgd_gram_panchayats_district_id_lgd_districts_id_fk FOREIGN KEY (district_id) REFERENCES public.lgd_districts(id) ON DELETE CASCADE;


--
-- Name: lgd_tehsils lgd_tehsils_district_id_lgd_districts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_tehsils
    ADD CONSTRAINT lgd_tehsils_district_id_lgd_districts_id_fk FOREIGN KEY (district_id) REFERENCES public.lgd_districts(id) ON DELETE CASCADE;


--
-- Name: lgd_urban_bodies lgd_urban_bodies_district_id_lgd_districts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_urban_bodies
    ADD CONSTRAINT lgd_urban_bodies_district_id_lgd_districts_id_fk FOREIGN KEY (district_id) REFERENCES public.lgd_districts(id) ON DELETE CASCADE;


--
-- Name: login_otp_challenges login_otp_challenges_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_otp_challenges
    ADD CONSTRAINT login_otp_challenges_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: notifications notifications_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: objections objections_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: objections objections_inspection_report_id_inspection_reports_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_inspection_report_id_inspection_reports_id_fk FOREIGN KEY (inspection_report_id) REFERENCES public.inspection_reports(id);


--
-- Name: objections objections_raised_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_raised_by_users_id_fk FOREIGN KEY (raised_by) REFERENCES public.users(id);


--
-- Name: objections objections_resolved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_resolved_by_users_id_fk FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: password_reset_challenges password_reset_challenges_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_reset_challenges
    ADD CONSTRAINT password_reset_challenges_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payments payments_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: reviews reviews_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: reviews reviews_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: storage_objects storage_objects_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE SET NULL;


--
-- Name: storage_objects storage_objects_document_id_documents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_document_id_documents_id_fk FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: storage_objects storage_objects_uploaded_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_uploaded_by_users_id_fk FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: system_settings system_settings_updated_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_updated_by_users_id_fk FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: user_profiles user_profiles_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict GMqOo6N1wC7EXNaFn6mDHtTG0Md5xqsz9qVahfst47a5mFHUJznZD9TajJmFPXp

